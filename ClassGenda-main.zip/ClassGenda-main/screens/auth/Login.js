//Pantalla de login.
// ----------------------------------------- DEPENDENCIAS -------------------
import React, { useState, useEffect } from 'react';
import { View,
  TextInput,
  StyleSheet,
  Text,
  TouchableOpacity,
  ScrollView,
 } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
// ----------------------- COMPONENTES --------------------------------
import  {ROUTES, PALETADECOLORES} from '../../components';
import BackgroundLogin from '../../components/BackgroundLogin';
import { useUserCode } from './UserCodeProvider';
//------------------------SUPABASE------------------------------------
import { supabase } from '../../lib/supabase';
import Code_Query from '../../backend/Querys/Code_Query';

const Login = (props) => {
  
  //Importar navigation, dado que este permite que la app se desplace entre pantallas correctamente.
  const navigation = useNavigation();
  const { login } = useUserCode();

  // Utiliza una variable de estado para controlar si el código se ha ejecutado.
  const [codeExecuted, setCodeExecuted] = useState(false);
  const [Validacion, setValidacion] = useState(false);

  useEffect(() => {
    supabase.auth.onAuthStateChange(async (event, session) => {
      if (session && !codeExecuted) {
        try {
          const data = session.user;
          const userUserId = data.id;
          const Codigos = await fetchCodeQuery(userUserId);
          login(Codigos);
          navigation.navigate(ROUTES.DRAWER);

          // Marca la variable de estado para indicar que el código se ha ejecutado
          setCodeExecuted(true);
        } catch (error) {
          console.error('Error al obtener los códigos:', error);
        }
      }
    });
    }, [navigation, login, codeExecuted]);

  // Resto del componente...
  async function fetchCodeQuery(uuid) {
    try {
      const { data, error } = await supabase
        .from('Users')
        .select('User_Id')
        .eq('log_id', uuid);

      if (error) {
        throw new Error(error.message);
      }

      return data;
    } catch (error) {
      throw error;
    }
  };

  // Valores del ingreso o inicio de sesión.
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  // Gesto para sincronizar y recibir los datos de ingreso.
  const handleLogin = async(username, password) => {
    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email: username,
        password: password,
      })
    }catch (error){
      console.error(error);
    }
  };

  return (
    <ScrollView>
      <BackgroundLogin>
        <View 
          style={styles.maincontainer}>
            <Text 
              style={styles.title}>
                Login
            </Text>
            <Text 
              style={styles.normalText}>
                Email
            </Text>
            <View 
              style={styles.inputBackground}>
              <TextInput
                placeholder="Hey@alumnos.udg.mx"
                onChangeText={text => setUsername(text)}
                value={username}

                style={{
                  width: '93.5%',
                  height: "-20%",
                  fontSize: 15,
                  marginVertical: 13,
                  paddingHorizontal: 4, 
                  marginLeft: "3.7%",
                  fontFamily: "Riot-Regular",
                }}
              >
              </TextInput>
            </View>
            <Text 
              style={styles.normalText}>
                Password
            </Text>
            <View 
              style={styles.inputBackground}>
              <TextInput
                placeholder="Mojojojo21"
                onChangeText={text => setPassword(text)}
                value={password}
                secureTextEntry={true}

                  style={{
                    width: '93.5%',
                    height: "-20%",
                    fontSize: 15,
                    marginVertical: 13,
                    paddingHorizontal: 6, 
                    marginLeft: "3.7%",
                    fontFamily: "Riot-Regular",
                  }}
              >
              </TextInput>
            </View>
            <TouchableOpacity 
              onPress={() => handleLogin(username, password)}
              activeOpacity={0.7}
              style={styles.button}>
                <Text 
                  style={styles.buttonText}>
                    Sign in
                </Text>
                <Ionicons 
                  style={styles.arrow}
                  name="arrow-forward-outline" 
                  size={50} 
                  color="white" 
                />
            </TouchableOpacity>
            <TouchableOpacity
              onPress={() => navigation.navigate(ROUTES.FORGOTPASSWORD)}>        
              <Text 
                style={styles.forgotBtnText}>
                  Forgot password?
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              onPress={() =>
                navigation.navigate(ROUTES.SIGNUP)}>         
              <Text 
                style={styles.SignUpBtnText}>
                  Sign Up
              </Text>
            </TouchableOpacity>
        </View>
      </BackgroundLogin>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  maincontainer:{
    height: "100%",
    width: "100%",
  },
  title: {
    fontSize: 50,
    fontFamily: "Riot-Regular",
    width: "80%",
    marginLeft: "38%",
    marginBottom: "5%",
    marginTop: "63%",
  },
  inputBackground: {
    width: '77%',
    height: "8%",
    borderWidth: 3,
    borderRadius: 30,
    marginLeft: "13%",
    //fontFamily: "Kod-Bold",
  },
  normalText: {
    fontSize: 20,
    width: "80%",
    marginVertical: "5%", 
    marginBottom: "0%",
    marginLeft: "18%",
    fontFamily: "Inter-Bold",
  },
  buttonText:{
    color: "white",
    fontSize: 22,
    marginTop: "14%",
    marginLeft: "2%",
    fontFamily: "Lilita",
  },
  button: {
    flexDirection: 'row',
    justifyContent: 'center',
    backgroundColor: PALETADECOLORES.AmarilloPatito,
    borderRadius: 40,
    marginVertical: "10%",
    marginRight: "12%",
    marginLeft: "50%",
    height: "10%",
    width: "45%",
  },
  arrow: {
    justifyContent: "center",
    marginTop: "7%",
    marginLeft: "4.6%",
  },
  forgotBtnText: {
    color: PALETADECOLORES.RojoMamey,
    bottom: -50,
    marginLeft: "10%",
    fontSize: 18,
    fontFamily: "Inter-Bold",
  },
  SignUpBtnText: {
    color: PALETADECOLORES.Azul,
    bottom: -28,
    marginLeft: "70%",
    fontSize: 18,
    fontFamily: "Inter-Bold",
  },
});

export default Login;