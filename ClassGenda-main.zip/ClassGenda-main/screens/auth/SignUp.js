// Pantalla de registrar usuario - app.
// -------------------------- DEPENDENCIAS -------------------------------
import React, { useState, useEffect } from 'react';
import { View,
  TextInput,
  StyleSheet,
  Text,
  TouchableOpacity,
  ScrollView,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
// ----------------------- COMPONENTES --------------------------------
import  {ROUTES, PALETADECOLORES} from '../../components';
import BackgroundLogin from '../../components/BackgroundOptionsLogin';
//------------------------SUPABASE------------------------------------
import { supabase } from '../../lib/supabase';
// ----------------------- BACKEND ------------------------------------
import User_Insert from '../../backend/Inserts/User_Insert';
import { useUserCode } from './UserCodeProvider';

const SignUp = props => {

  //Importar navigation, dado que este permite que la app se desplace entre pantallas correctamente.
  const navigation = useNavigation();
  const { login } = useUserCode();

  //Valores para el registro.
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [confirmpassword, setConfirmPassword] = useState('');
  const [codigo, setCodigo] = useState('');
  const [nombre, setNombre] = useState('');
  const [apellido, setApellido] = useState('');
  const [rol, setRol] = useState('');

  //Gesto para el registro/sincronización.
  const handleLogin = async (username, password,codigo,rol,apellido,nombre) => {
    try {
      const { user, error } = await supabase.auth.signUp({
        email: username,
        password: password,
      });
      if (error) {
        console.log(error);
      } else {
        const { data, error } = await supabase.auth.signInWithPassword({
          email: username,
          password: password,
        })
        const UID = data.session.user.id;
        console.log("Informacion de inicio de sesion");
        login(codigo);
        User_Insert(codigo,rol,UID,apellido,nombre,username, password);
        navigation.navigate(ROUTES.DRAWER);
      }
    } catch (error) {
      console.error("Error en handleLogin:", error);
    }
  };
  
  return (
    <ScrollView>
      <BackgroundLogin>
        <View 
          style={styles.maincontainer}>
            <Text 
              style={styles.title}>
                Sign-up
            </Text>
            <Text 
              style={styles.normalText}>
                Nombre
            </Text>
            <View style={styles.inputBackground}>
              <TextInput
                placeholder="Constanza"
                onChangeText={text => setNombre(text)}

                style={{
                  width: '73.5%',
                  height: "50%",
                  fontSize: 15,
                  marginVertical: 12,
                  paddingHorizontal: 4, 
                  marginLeft: "3.7%",
                  fontFamily: "Riot-Regular",
                }}
              >
              </TextInput>
            </View>
            <Text 
              style={styles.normalText}>
                Apellido
            </Text>
            <View style={styles.inputBackground}>
              <TextInput
                placeholder="Mandujano"
                onChangeText={text => setApellido(text)}

                style={{
                  width: '73.5%',
                  height: "50%",
                  fontSize: 15,
                  marginVertical: 12,
                  paddingHorizontal: 4, 
                  marginLeft: "3.7%",
                  fontFamily: "Riot-Regular",
                }}
              >
              </TextInput>
            </View>
            <Text 
              style={styles.normalText}>
                Email
            </Text>
            <View style={styles.inputBackground}>
              <TextInput
                placeholder="Hey@alumnos.udg.mx"
                onChangeText={text => setUsername(text)}
                value={username}

                style={{
                  width: '73.5%',
                  height: "50%",
                  fontSize: 15,
                  marginVertical: 12,
                  paddingHorizontal: 4, 
                  marginLeft: "3.7%",
                  fontFamily: "Riot-Regular",
                }}
              >
              </TextInput>
            </View>
            <Text 
              style={{
                fontSize: 18,
                width: "80%",
                marginVertical: "4%", 
                marginBottom: ".3%",
                marginLeft: "21%",
                fontFamily: "Inter-Bold",
                }}
            >
              Código
            </Text>
            <View style={{
              width: '34%',
              height: "5%",
              borderWidth: 3,
              borderRadius: 30,
              marginLeft: "11%",
              fontFamily: "Kod-Bold",
            }}>
              <TextInput
                placeholder="     763876789"
                onChangeText={text => setCodigo(text)}
                value={codigo}

                style={{
                  width: '93.5%',
                  height: "50%",
                  fontSize: 15,
                  marginVertical: 10,
                  paddingHorizontal: 4, 
                  marginLeft: "3.7%",
                  fontFamily: "Riot-Regular",
                }}
              >
              </TextInput>
            </View>
            <Text 
              style={{
                fontSize: 18,
                width: "70%",
                flexDirection: "row",
                marginVertical: "-17.9%", 
                marginBottom: ".3%",
                marginLeft: "65%",
                fontFamily: "Inter-Bold",
                }}
            >
              Rol
            </Text>
            <View style={{
              width: '37%',
              height: "5%",
              borderWidth: 3,
              borderRadius: 30,
              marginLeft: "50%",
              fontFamily: "Kod-Bold",
            }}>
              <TextInput
                placeholder="  Alumno/Profesor"
                onChangeText={text => setRol(text)}

                style={{
                  width: '93.5%',
                  height: "50%",
                  fontSize: 15,
                  marginVertical: 11,
                  paddingHorizontal: 4, 
                  marginLeft: "3.7%",
                  fontFamily: "Riot-Regular",
                }}
              >
              </TextInput>
            </View>
            <Text 
              style={{
                fontSize: 18,
                width: "80%",
                marginVertical: "4%", 
                marginBottom: ".3%",
                marginLeft: "38%",
                fontFamily: "Inter-Bold",
              }}
            >
                Password
            </Text>
            <View 
              style={{
                width: '55%',
                height: "5%",
                borderWidth: 3,
                borderRadius: 30,
                marginLeft: "22%",
                fontFamily: "Riot-Regular",
              }}
            >
              <TextInput
                placeholder="                Mojojojo21"
                onChangeText={text => setPassword(text)}
                value={password}
                secureTextEntry={true}

                  style={{
                    width: '100%',
                    height: "50%",
                    fontSize: 15,
                    marginVertical: 12,
                    paddingHorizontal: 4, 
                    marginLeft: "3.7%",
                    fontFamily: "Riot-Regular",
                  }}
              >
              </TextInput>
            </View>
            <Text 
              style={{
                fontSize: 18,
                width: "80%",
                marginVertical: "4%", 
                marginBottom: ".3%",
                marginLeft: "28%",
                fontFamily: "Inter-Bold",
              }}
            >
              Confirmar password
            </Text>
            <View 
              style={{
                width: '58%',
                height: "5%",
                borderWidth: 3,
                borderRadius: 30,
                marginLeft: "22%",
                fontFamily: "Riot-Regular",
              }}
            >
              <TextInput
                placeholder="               **********"
                onChangeText={text => setConfirmPassword(text)}
                value={confirmpassword}
                secureTextEntry={true}

                  style={{
                    width: '90%',
                    height: "50%",
                    fontSize: 15,
                    marginVertical: 12,
                    paddingHorizontal: 4, 
                    marginLeft: "3.7%",
                    fontFamily: "Riot-Regular",
                  }}
              >
              </TextInput>
            </View>
            <TouchableOpacity 
              onPress={() => handleLogin(username, password, codigo, rol, apellido, nombre)}
              activeOpacity={0.7}
              style={styles.button}>
                <Text 
                  style={styles.buttonText}>
                    Sign up
                </Text>
                <Ionicons 
                  style={styles.arrow}
                  name="arrow-forward-outline" 
                  size={50} 
                  color="white" 
                />
            </TouchableOpacity>
          </View>
      </BackgroundLogin>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  maincontainer:{
    height: "100%",
    width: "100%",
  },
  title: {
    fontSize: 50,
    fontFamily: "Riot-Regular",
    width: "80%",
    marginLeft: "30%",
    marginBottom: "3%",
    marginTop: "18%",
  },
  normalText: {
    fontSize: 18,
    width: "80%",
    marginVertical: "4%", 
    marginBottom: ".3%",
    marginLeft: "15%",
    fontFamily: "Inter-Bold",
  },
  inputBackground: {
    width: '79%',
    height: "5%",
    borderWidth: 3,
    borderRadius: 30,
    marginLeft: "10%",
  },
  buttonText:{
    color: "white",
    fontSize: 22,
    marginTop: "14%",
    marginLeft: "2%",
    fontFamily: "Lilita",
  },
  button: {
    flexDirection: 'row',
    justifyContent: 'center',
    backgroundColor: PALETADECOLORES.Azul,
    borderRadius: 40,
    marginVertical: "10%",
    marginRight: "12%",
    marginLeft: "50%",
    height: "8%",
    width: "40%",
  },
  arrow: {
    justifyContent: "center",
    marginTop: "7%",
    marginLeft: "4%",
  },
});

export default SignUp;