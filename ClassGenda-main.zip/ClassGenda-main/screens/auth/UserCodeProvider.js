// --------------------- DEPENDENCIAS ------------------------------
import React, { createContext, useContext, useState } from 'react';

// Crea un contexto para el código de usuario
const UserCodeContext = createContext();

// Crea un proveedor de contexto que contendrá el código de usuario
export function UserCodeProvider({ children }) {
  const [userCode, setUserCode] = useState(null);

  // Función para iniciar sesión
  const login = (code) => {
    setUserCode(code);
  };

  // Función para cerrar sesión
  const logout = () => {
    setUserCode(null);
  };

  return (
    <UserCodeContext.Provider value={{ userCode, login, logout }}>
      {children}
    </UserCodeContext.Provider>
  );
}

// Hook personalizado para acceder al contexto del código de usuario
export function useUserCode() {
  const context = useContext(UserCodeContext);
  if (!context) {
    throw new Error('useUserCode debe usarse dentro de un UserCodeProvider');
  }
  return context;
}
