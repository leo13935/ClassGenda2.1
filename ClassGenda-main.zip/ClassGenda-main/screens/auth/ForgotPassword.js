// Pantalla de recuperación de contraseña.
// ----------------------- DEPENDENCIAS ------------------------------------
import React, { useState, useEffect } from 'react';
import { View,
  TextInput,
  StyleSheet,
  Text,
  TouchableOpacity,
  KeyboardAvoidingView,
  ScrollView,
  Platform,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
// ----------------------- COMPONENTES --------------------------------
import  {ROUTES, PALETADECOLORES} from '../../components';
import BackgroundLogin from '../../components/BackgroundOptionsLogin';

const ForgotPassword = props => {

    //Importar navigation, dado que este permite que la app se desplace entre pantallas correctamente.
    const navigation = useNavigation();

    //Valores para recuperar la contraseña (valores de entrada).
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
  
    const handleLogin = () => {
      //Autentificacion de los valores para recuperar contraseña.
      console.log('Username:', username);
      console.log('Password:', password);
    };
  
    return (
      <KeyboardAvoidingView
          behavior={Platform.OS == "ios" ? "padding" : "height"}
          style={{flex:1}}
      >
        <BackgroundLogin>
          <ScrollView> 
            <View 
              style={styles.maincontainer}>
                <Text 
                  style={styles.title}>
                    Forgot Password?
                </Text>
                <Text 
                  style={styles.normalText}>
                    Email
                </Text>
                <View 
                  style={styles.inputBackground}>
                  <TextInput
                    placeholder="Hey@gmail.com"
                    onChangeText={text => setUsername(text)}
                    value={username}

                    style={{
                      width: '93.5%',
                      height: "-20%",
                      fontSize: 15,
                      marginVertical: 12,
                      paddingHorizontal: 4, 
                      marginLeft: "3.7%",
                      fontFamily: "Riot-Regular",
                    }}
                  >
                  </TextInput>
                </View>
                <TouchableOpacity     //Botón para solicitar la contraseña.
                  onPress={() => navigation.navigate(ROUTES.DRAWER)}
                  activeOpacity={0.7}
                  style={styles.button}>
                    <Text style={styles.buttonText}>Submit</Text>
                    <Ionicons style={styles.arrow}
                    name="arrow-forward-outline" size={50} color="white" />
                </TouchableOpacity>
            </View>
          </ScrollView> 
        </BackgroundLogin>
      </KeyboardAvoidingView>
    );
  };
  
  const styles = StyleSheet.create({
    maincontainer:{
      height: "100%",
      width: "100%",
    },
    title: {
      fontSize: 40,
      fontFamily: "Riot-Regular",
      width: "80%",
      marginLeft: "14%",
      marginBottom: "10%",
      marginTop: "50%",
    },
    inputBackground: {
      width: '77%',
      height: "10%",
      borderWidth: 3,
      borderRadius: 30,
      marginLeft: "13%",
      fontFamily: "Kod-Bold",
    },
    normalText: {
      fontSize: 20,
      width: "80%",
      marginVertical: "5%", 
      marginBottom: "0%",
      marginLeft: "20%",
      fontFamily: "Inter-Bold",
    },
    buttonText:{
      color: "white",
      fontFamily: "Lilita",
      fontSize: 22,
      marginTop: "13%",
      marginLeft: "2%",
    },
    button: {
      flexDirection: 'row',
      justifyContent: 'center',
      backgroundColor: PALETADECOLORES.RojoMamey,
      borderRadius: 40,
      marginVertical: "15%",
      marginRight: "10%",
      marginLeft: "50%",
      height: "12%",
      width: "45%",
    },
    arrow: {
      justifyContent: "center",
      marginTop: "6%",
      marginLeft: "5%",
    },
  });
  
  export default ForgotPassword;