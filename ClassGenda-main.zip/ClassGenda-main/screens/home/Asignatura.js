// Pagina del dashboard del administrador.
// ----------------------------------------- DEPENDENCIAS -------------------
import { useState, useEffect } from 'react';
import React from "react";
import { View,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  FlatList,
} from 'react-native';
import { useNavigation, useRoute } from '@react-navigation/native';
// ---------------------------- COMPONENTES ---------------------------------
import Inscritos from "../../components/Inscritos";
import  {PALETADECOLORES} from '../../components';
// ---------------------------- BACK ----------------------------------------
import Subjects_Query from '../../backend/Querys/Subject_Query';
import Class_Query from '../../backend/Querys/Class_Query';
import { useUserCode, login } from '../auth/UserCodeProvider';
import NRC_Query from '../../backend/Querys/NRC_Query';
import Subject_Student_Query from '../../backend/Querys/Subject_Student_Query';

const Students = [
  {
    id: 1,
    code: "1",
  },
  {
    id: 2,
    code: "2",
  },
  {
    id: 3,
    code: "3",
  },
  {
    id: 4,
    code: "4",
  },
  {
    id: 5,
    code: "5",
  },
  {
    id: 6,
    code: "6",
  },
  {
    id: 7,
    code: "7",
  },
  {
    id: 8,
    code: "8",
  },
  {
    id: 9,
    code: "9",
  },
  {
    id: 10,
    code: "10",
  },
  {
    id: 11,
    code: "1",
  },
  {
    id: 12,
    code: "2",
  },
  {
    id: 13,
    code: "3",
  },
  {
    id: 14,
    code: "4",
  },
  {
    id: 15,
    code: "5",
  },
  {
    id: 16,
    code: "6",
  },
  {
    id: 17,
    code: "7",
  },
  {
    id: 18,
    code: "8",
  },
  {
    id: 19,
    code: "9",
  },
  {
    id: 20,
    code: "10",
  },
];
const Asignatura = () => {

  //Carga el código del usuario registrado, esto para cargar la información de la asignatura que le incluye.
  const { userCode } = useUserCode();
  const route = useRoute();

  //ID del usuario.
  const user_id = userCode[0].User_Id;

  //Busca y recopila el NRC de dicha asignatura.
  const  nrc  = route.params?.codigo_materia;
  console.log("AQUI ESTA EL PASO POR PARAMETROS: ",nrc);
  //Aquí se realiza una petición para obtener la información de dicho NRC.
  const dataNRC = NRC_Query(user_id);
  let valorNRC = '';

  if (dataNRC && dataNRC.length > 0) {
    valorNRC = dataNRC[0].NRC;
    console.log("NRC INTENTO: ", valorNRC);
  } else {
    console.log("dataNRC is undefined or empty");
  }

  //Valor para el NRC de la asignatura.
  const [NRC, setNRC] = useState(valorNRC);

  //Valores para obtener los estudiantes que pertenecen a dicha asignatura.
  const Alumniados = Subject_Student_Query(NRC);
  console.log("Alumnos en la materia: ", Alumniados);
  const nrcToFetch = nrc;

  //Importar navigation, dado que este permite que la app se desplace entre pantallas correctamente.
  const navigation = useNavigation();

  //Gesto para poder establecer el NRC al que se le van a agregar más clases.
  const handleAddClass = (nrc) => {
    navigation.navigate('Añadir clase', { codigo_materia: nrc });
  };

  //Valor para refrescar las consultas de dicho NRC.
  const [refreshing, setRefreshing] = React.useState(false);

  const onRefresh = React.useCallback(() => {
    setRefreshing(true);
    setTimeout(() => {
      setRefreshing(false);
    }, 2000);
  }, []);

  return (
    <View>
      <View style={styles.topBox}>
        <View style={styles.topLeft}>
          <View style={styles.container}>

            <Text
              style={{                        //Titulo del primer campo - Asignatura.
                color: 'black',
                fontSize: 17,
                fontFamily: "Riot-Regular",
                marginVertical: -4,
                marginLeft: 7,
              }}>
              Asignatura
            </Text>
            <View style={styles.textBox}>
              <ScrollView>
                <Subjects_Query
                  tableName="Subject"
                  fieldName="NRC"
                  fieldValue={nrcToFetch}
                  WantedValue="Name"
                />
              </ScrollView>
            </View>
          </View>
          <View style={styles.container}>
            <Text
              style={{                        //Titulo del primer campo - Asignatura.
                color: 'black',
                fontSize: 17,
                fontFamily: "Riot-Regular",
                marginVertical: -6,
                marginLeft: 11,
              }}>
              Descripción
            </Text>
            <View style={styles.textBox}>
              <ScrollView>
                <Subjects_Query
                  tableName="Subject"
                  fieldName="NRC"
                  fieldValue={nrcToFetch}
                  WantedValue="Description"
                />
              </ScrollView>
            </View>
          </View>
        </View>
        <View style={styles.topRight}>
          <View style={styles.container}>
            <Text
              style={{                        //Titulo del primer campo - Asignatura.
                color: 'black',
                fontSize: 17,
                fontFamily: "Riot-Regular",
                marginVertical: -2,
                marginLeft: 9,
              }}>
                Inicia:
            </Text>
            <View style={styles.textBoxRow}>
              <Subjects_Query
                tableName="Subject"
                fieldName="NRC"
                fieldValue={nrcToFetch}
                WantedValue="Start_Date"
              />
            </View>
          </View>
          <View style={styles.container}>
            <Text
                style={{                        //Titulo del primer campo - Asignatura.
                  color: 'black',
                  fontSize: 17,
                  fontFamily: "Riot-Regular",
                  marginVertical: -2,
                  marginLeft: 2,
                }}>
              Termina:
            </Text>
            <View style={styles.textBoxRow}>
              <Subjects_Query
                tableName="Subject"
                fieldName="NRC"
                fieldValue={nrcToFetch}
                WantedValue="End_Date"
              />
            </View>
          </View>
          <View style={styles.container}>
            <Text
              style={{                        //Titulo del primer campo - Asignatura.
                color: 'black',
                fontSize: 17,
                fontFamily: "Riot-Regular",
                marginVertical: -2,
                marginLeft: 7,
              }}>
              Estatus:
            </Text>
            <View style={styles.textBoxRow}>{
              //Añadir funcion para detectar el valor y poner el texto que sea necesario
            }
              <Text 
                style={{
                  fontFamily: "Inter-Regular",
                  fontSize: 16,
                  textAlign: "center",
                  marginVertical: "3.5%",
                }}>
                  En curso
              </Text>
            </View>
          </View>
        </View>
      </View>
      <View style={styles.midBox}>
        <View style={styles.middle}>
          <Text 
            style={{
              fontSize: 17,
              fontFamily: "Riot-Regular",
              marginLeft: "7%",
              marginTop: "1%",
            }}>
              Alumnos
          </Text>
          <View 
            style={{
              backgroundColor: "white",
              height: "2%",
              width: "90%",
              marginTop: "1%",
              marginLeft: "5%",
              marginRight: "5%",
            }}/>
          <View 
            style={{
              height: "75%",
              marginLeft: "5%",
              width: "90%",
              marginVertical: 4,
              flexDirection: "column",
            }}>
            <FlatList
            data = {Students}
            renderItem={({item}) => <Inscritos students={item}/>}
            keyExtractor={item=>item.id}
            />
          </View>
        </View>
      </View>
      <View style={styles.botBox}>
        <View style={styles.bottom}>
          <View 
            style={{
              flexDirection: "row",
              marginBottom: "4%",
            }}>
            <Text 
              style={{
                fontSize: 17,
                fontFamily: "Riot-Regular",
                marginLeft: "6%",
                marginTop: "3%",
              }}>
                Lista de clases
            </Text>
            <View 
              style={{
                marginLeft: "30%",  //Boton 'añadir clase'
                marginTop: "2%",
                borderRadius: 20,
                height: "85%",
                width: "30%",
                backgroundColor: "white",
              }}>
              <TouchableOpacity 
                onPress={() => handleAddClass(nrcToFetch)}
              >
                <Text 
                  style={{
                    fontSize: 14,
                    fontFamily: "Riot-Regular",
                    marginTop: "3.2%",
                    marginLeft: "7.5%",
                  }}> 
                  + Añadir clase 
                </Text>
              </TouchableOpacity>
            </View>
          </View>
          <View 
            style={{
              backgroundColor: "white", //Linea de adorno.
              height: "1.2%",
              width: "90%",
              marginLeft: "5%",
              marginTop: "-1%",
              marginRight: "5%",
            }}/>
          <View style={styles.columna}>
            <Text 
              style={{
                marginLeft: "4%",
                marginTop: "2%",
                fontSize: 13.5,
                fontFamily: "Riot-Regular",
              }}> 
                Estatus
            </Text>
            <Text 
              style={{
                marginLeft: "12%",
                fontSize: 13.5,
                fontFamily: "Riot-Regular",
                marginTop: "2%",
              }}>
                Clase
            </Text>
            <Text 
              style={{
                marginLeft: "22.5%",
                fontSize: 13.5,
                fontFamily: "Riot-Regular",
                marginTop: "2%",
              }}> 
              Descripción
            </Text>
            <Text 
              style={{
                fontFamily: "Riot-Regular",
                fontSize: 13.5,
                marginLeft: "10%",
                marginTop: "2%",
              }}>
              Acción
            </Text>
          </View>
          <View style={styles.StudentsBox}>
            <Class_Query NRC={nrcToFetch}/>
          </View>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  columna:{
    flexDirection: "row",
  },
  StudentsBox: {
    height: "69%",
    marginLeft: "0.5%",
    width: "99%",
    marginVertical: '-1%',
    flexDirection: "column",
    borderRadius: 20,
  },
  topBox: {
    backgroundColor: "white",
    height: "32%",
    flexDirection: "row",
  },
  topLeft: {
    backgroundColor: PALETADECOLORES.RojoMamey,
    flexDirection: "column",
    marginVertical: "3%",
    marginLeft: "6%",
    width: "52%",
    borderRadius: 20,
  },
  container: {
    flex: 1,
    marginVertical: "5%",
    marginHorizontal : "2%",
    height: "90%",
    alignContent: "center",
    alignItems: "center",
  },
  containerRow: {
    flex: 1,
    marginVertical: "5%",
    marginLeft : "4%",
    flexDirection: "row",
  },
  textBox: {
    backgroundColor: "white",
    width: "95%",
    marginVertical: "3%",
    borderRadius: 20,
    alignContent: "center",
    alignItems: "center",
    height: "80%",
    overflow: "auto",
  },
  textBoxRow: {
    backgroundColor: "white",
    width: "90%",
    borderRadius: 15,
    marginVertical: "2%",
    alignContent: "center",
    alignItems: "center",
    height: "55%",
  },
  leftBottom: {
    backgroundColor: "blue",
    marginVertical : "5%",
  },
  topRight: {
    backgroundColor: PALETADECOLORES.Azul,
    flexDirection: "column",
    marginVertical: "3%",
    marginRight: "6%",
    marginLeft: "6%",
    width: "30%",
    borderRadius: 20,
  },
  midBox: {
    backgroundColor: "white",
    height: "25%",
  },
  middle: {
    backgroundColor: PALETADECOLORES.Azul,
    flexDirection: "column",
    marginVertical: "3%",
    marginRight: "6%",
    marginLeft: "6%",
    width: "88%",
    height: "88%",
    borderRadius: 20,
  },
  botBox: {
    backgroundColor: "white",
    height: "43%",
  },
  bottom: {
    backgroundColor: PALETADECOLORES.AmarilloPatito,
    flexDirection: "column",
    marginVertical: "3%",
    marginRight: "6%",
    marginLeft: "6%",
    width: "88%",
    height: "88%",
    borderRadius: 20,
  },
});

export default Asignatura;