// Pantalla general del dashboard.
// ------------------------------- DEPENDENCIAS ---------------------------------
import React, { useState, useEffect } from 'react';
import { View,
  StyleSheet,
  Text,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
// ------------------------------- COMPONENTES ----------------------------
import  {PALETADECOLORES} from '../../components';
// ------------------------------- BACK -----------------------------------
import All_Subject_Query from '../../backend/Querys/All_Subject_Query';
import Count_Subjects from '../../backend/Querys/Count_Subjects';
import Count_Class from '../../backend/Querys/Count_Class';
import { useUserCode } from '../auth/UserCodeProvider';

const DashboardGeneral = () => {

  //Valores para recopilar la información de dicho usuario.
  const { userCode } = useUserCode();
  const nrcToFetch = userCode[0].User_Id;

  //Valor para contabilizar las asignaturas totales.
  const AsignaturasTotales = Count_Subjects(nrcToFetch);
  console.log(AsignaturasTotales);

  //Valor para contabilizar las clases totales.
  const ClasesTotales = Count_Class(nrcToFetch);

  //Importar navigation, dado que este permite que la app se desplace entre pantallas correctamente.
  const navigation = useNavigation();

  return (
    <View style={{alignItems: 'center', width: 400}}>
        <View
          style={{
            backgroundColor: 'white',                 //Fondo de la pantalla en general.
            height: 800,
            width: 460,
            paddingTop: 100,
            alignItems: 'center',
          }}>
          <View
            style={{
              backgroundColor: PALETADECOLORES.Azul, // Fondo del primer bloque de datos (Avance del semestre).
              height: 300,
              width: 350,
              paddingTop: 10,
              borderRadius: 20,
              marginVertical: -50,
            }}>
            <Text                                     //Titulo del campo clase.
              style={{
                color: 'black',
                fontSize: 18,
                fontFamily: "Riot-Regular",
                marginVertical: -1,
                marginLeft: 20,
              }}>
              Avance del semestre :
            </Text>
            <View style={styles.underline}/>
              <View style={styles.columna}>
                <Text style={styles.status}> Asignatura</Text>
                <Text style={styles.status2}> Descripción</Text>
                <Text style={styles.status3}> Acción</Text>
              </View>
              <View style={styles.bottom}>
                <View style={styles.StudentsBox}>
                  <All_Subject_Query NRC={nrcToFetch}/>
              </View>
            </View>
          </View>
          <View
            style={{                                    // Fondo del segundo bloque de datos (Asignaturas).
              backgroundColor: PALETADECOLORES.RojoMamey, 
              height: 110,
              width: 215,
              paddingTop: 10,
              borderRadius: 20,
              marginVertical: 110,
              marginLeft: -130,
              justifyContent: 'center',
            }}
          >
            <Text                                        //Titulo del campo - asignaturas totales.
              style={{
                color: 'black',
                fontSize: 16,
                fontFamily: "Inter-Bold",
                marginVertical: -1,
                marginLeft: 9,
              }}>
              Asignaturas
            </Text>
            <Text                                       //Titulo del campo - asignaturas totales.
              style={{
                color: 'black',
                fontSize: 16,
                fontFamily: "Inter-Bold",
                marginVertical: -1,
                marginLeft: 30,
              }}>
              totales
            </Text>
          </View>
          <View
            style={{
              borderRadius: 20, color: "black", 
              paddingHorizontal: 9, 
              height: '13%', width: '20%', 
              backgroundColor: 'white', 
              marginVertical: -210,
              borderColor: "black",
              borderWidth: 3,
              borderRadius: 10,
              marginLeft: -30,
              alignItems: 'center',
            }}
          >
            <Text
              style={{
                fontFamily: "Riot-Regular",
                fontSize: 60,
                marginVertical: -9,
                textAlign: 'center'
              }}
            >
              {AsignaturasTotales}
            </Text>
          </View>
          <View
            style={{                              // Fondo del tercer bloque de datos (Clases totales).
              backgroundColor: PALETADECOLORES.AmarilloPatito, 
              height: 110,
              width: 205,
              paddingTop: 10,
              borderRadius: 20,
              marginVertical: 250,
              marginLeft: -140,
              justifyContent: 'center',
            }}
          >
            <Text                                   //Titulo del campo - clases totales.
              style={{
                color: 'black',
                fontSize: 16,
                fontFamily: "Inter-Bold",
                marginVertical: -9,
                marginLeft: 25,
              }}>
              Clases
            </Text>
            <Text
              style={{
                color: 'black',
                fontSize: 16,
                fontFamily: "Inter-Bold",
                marginVertical: 6,
                marginLeft: 25,
              }}>
              totales
            </Text>
          </View>
          <View
            style={{
              borderRadius: 20, color: "black",             //Campo de ingreso - Código.
              paddingHorizontal: 9, 
              height: '13%', width: '20%', 
              backgroundColor: 'white', 
              marginVertical: -350,
              borderColor: "black",
              borderWidth: 3,
              borderRadius: 10,
              marginLeft: -50,
              alignItems: 'center',
            }}
          >
            <Text
              style={{
                fontFamily: "Riot-Regular",
                fontSize: 60,
                marginVertical: -8,
                textAlign: 'center'
              }}
            >
              {ClasesTotales}
            </Text>
          </View>
        </View>
    </View>
  );
};

const styles = StyleSheet.create({
    underline:{
    backgroundColor: "white",
    height: "2%",
    width: "90%",
    marginLeft: "5%",
    marginRight: "5%",
  },
  StudentsBox: {
    height: "300",
    marginLeft: "-5%",
    width: "110%",
    marginVertical: '-6%',
    flexDirection: "column",
    borderRadius: 20,
  },
  status:{
    marginLeft: "12%",
    fontFamily: "Riot-Regular",
  },
  status2:{
    marginLeft: "16.5%",
    marginRight: "3%",
    fontFamily: "Riot-Regular",
  },
  status3:{
    marginLeft: "9.6%",
    fontFamily: "Riot-Regular",
  },
  columna:{
    flexDirection: "row",
    marginVertical: "2%",
  },
  bottom: {
    backgroundColor: PALETADECOLORES.Azul,
    flexDirection: "column",
    marginVertical: "2%",
    marginRight: "6%",
    marginLeft: "5%",
    width: "90%",
    height: "70%",
    borderRadius: 20,
  },
});

export default DashboardGeneral;
