//Pantalla para las condiciones de uso de ClassGenda.
// --------------------------- DEPENDENCIAS ---------------------------
import React, { useState, useEffect, useRef } from 'react';
import { View,
  Text,
  TouchableOpacity,
  ScrollView,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
// ----------------------- COMPONENTES --------------------------------
import  { ROUTES, PALETADECOLORES} from '../../components';
// --------------------------- ICONOS ---------------------------
import {
    FontAwesome,
  } from "@expo/vector-icons";

const Condiciones = () => {

    //Importar navigation, dado que este permite que la app se desplace entre pantallas correctamente.
    const navigation = useNavigation();

    // Información de las condiciones de uso de ClassGenda (Alt + Z para ajustar el texto y que sea legible a la vista).
    const inicio = "Estos términos reflejan la forma de trabajar de ClassGenda, definiendo la relación que tiene contigo cuando interactúas con nuestros servicios. Por ejemplo, estos términos incluyen lo siguiente.";
    const TituloTermino1 = "¿Qué puedes esperar de nosotros?";
    const TituloTermino2 = "¿Qué esperamos del usuario?";
    const TituloTermino3 = "Contenido de los servicios:";

    const Termino1 = "Nuestros servicios están diseñados para funcionar como una herramienta que facilite la generación de evidencia de tus clases, así como la organización de de asignaturas y que con las funciones disponibles puedas simplificar tus actividades escolares.";
    
    const Termino2_1 = "- No hacer uso inadecuado de los servicios ni dañarlos; por ejemplo, usándolos o accediendo a ellos de forma fraudulenta o engañosa.";
    const Termino2_2 = "- No abusar o causar daños a otras personas ni a uno mismo; por ejemplo, a través del engaño, la estafa, la suplantación de identidad ilegal, la difamación y el acoso.";
    const Termino2_3 = "- Respetar los derechos de los demás, incluidos los de privacidad y propiedad intelectual.";
    const Termino2_4 = "- Permiso para usar tu contenido: algunos de nuestros servicios se han diseñado para que puedas subir, compartir y enviar tu contenido, pese a ello no tienes la obligación de proporcionar más que los datos necesarios para facilitar el servicio.";

    const Termino3 = "Nuestros servicios permite solamente que tu contenido o información, esté público solo para aquellos con los que compartas una clase, asignatura.";
    const Termino3_1 = "- Si crees que alguien está infringiendo tus derechos, puedes notificarlo desde Configuración > Contacto.";

    const final = "Es importante y esencial que comprendas estos términos, dado que al utilizar nuestros servicios implica que estas de acuerdo con ello y los aceptas.";

    return (
        <View style={{alignItems: 'center', width: 400}}>
            <View
                style={{
                    backgroundColor: 'white', //Fondo de la pantalla en general.
                    height: 800,
                    width: 460,
                    alignItems: 'center',
                  }}> 
                
                <View
                    style={{
                        backgroundColor: PALETADECOLORES.Azul, // Fondo principal.
                        height: 600,
                        width: 350,
                        borderRadius: 20,
                        marginVertical: 50,
                        marginLeft: 10,
                    }}>
                    <Text 
                        style={{                            //Titulo.
                            fontFamily: "Inter-Extra-Bold",
                            fontSize: 20,
                            width: "80%",
                            height: "60%",
                            marginLeft: "20%",
                            marginVertical: "2%",
                        }}
                    >
                        Términos del servicio
                    </Text>
                    <View
                        style={{
                            backgroundColor: "white", //Linea de adorno.
                            height: "1.2%",
                            width: "90%",
                            marginLeft: "5%",
                            marginVertical: "-94%",
                            marginRight: "5%",
                        }}
                    >
                    </View>
                    <View
                        style={{
                            backgroundColor: PALETADECOLORES.AzulPatito, // Fondo del texto general. 
                            height: 510,
                            width: 330,
                            borderRadius: 10,
                            marginVertical: 345,
                            marginLeft: 10,
                        }}
                    >
                        <ScrollView>
                        <Text
                            style={{
                                fontFamily: "Inter-Regular",
                                fontSize: 15,
                                color: "black",
                                marginLeft: "5%",
                                marginRight: "5%",
                                marginVertical: "0%",
                                textAlign: "justify",
                            }}
                        >
                            {inicio}
                            {"\n"}
                        </Text>
                        <Text
                            style={{
                                fontFamily: "Inter-Bold",
                                fontSize: 15,
                                color: "black",
                                marginLeft: "5%",
                                marginRight: "5%",
                                marginVertical: "0%",
                                textAlign: "justify",
                            }}
                        >
                            {"\n"}
                            {TituloTermino1}
                        </Text>
                        <Text
                            style={{
                                fontFamily: "Inter-Regular",
                                fontSize: 15,
                                color: "black",
                                marginLeft: "5%",
                                marginRight: "5%",
                                marginVertical: "0%",
                                textAlign: "justify",
                            }}
                        >
                            {Termino1}
                        </Text>
                        <Text
                            style={{
                                fontFamily: "Inter-Bold",
                                fontSize: 15,
                                color: "black",
                                marginLeft: "5%",
                                marginRight: "5%",
                                marginVertical: "0%",
                                textAlign: "justify",
                            }}
                        >
                            {"\n"}
                            {"\n"}
                            {TituloTermino2}
                        </Text>
                        <Text
                            style={{
                                fontFamily: "Inter-Regular",
                                fontSize: 15,
                                color: "black",
                                marginLeft: "5%",
                                marginRight: "5%",
                                marginVertical: "0%",
                                textAlign: "justify",
                            }}
                        >
                            {Termino2_1}
                            {"\n"}
                            {"\n"}
                            {Termino2_2}
                            {"\n"}
                            {"\n"}
                            {Termino2_3}
                            {"\n"}
                            {"\n"}
                            {Termino2_4}
                        </Text>
                        <Text
                            style={{
                                fontFamily: "Inter-Bold",
                                fontSize: 15,
                                color: "black",
                                marginLeft: "5%",
                                marginRight: "5%",
                                marginVertical: "0%",
                                textAlign: "justify",
                            }}
                        >
                            {"\n"}
                            {"\n"}
                            {TituloTermino3}
                        </Text>
                        <Text
                            style={{
                                fontFamily: "Inter-Regular",
                                fontSize: 15,
                                color: "black",
                                marginLeft: "5%",
                                marginRight: "5%",
                                marginVertical: "0%",
                                textAlign: "justify",
                            }}
                        >
                            {Termino3}
                            {"\n"}
                            {"\n"}
                            {Termino3_1}
                            {"\n"}
                        </Text>
                        <Text
                            style={{
                                fontFamily: "Inter-Bold",
                                fontSize: 15,
                                color: "black",
                                marginLeft: "6%",
                                marginRight: "6%",
                                marginVertical: "0%",
                                textAlign: "center",
                            }}
                        >
                            {"\n"}
                            {"\n"}
                            {final}
                            {"\n"}
                        </Text>
                        </ScrollView>
                    </View>
                </View>
            </View>
            <TouchableOpacity 
              onPressIn={() => navigation.navigate(ROUTES.MENU_CONFIG)}
              style={{
                backgroundColor: PALETADECOLORES.Azul,
                borderRadius: 30,
                //borderColor: "black",
                marginVertical: "-30%",
                marginBottom: '20%',
                marginLeft: "3%",
                marginRight: "-30%",
                width: 190,
                height: 70,
                borderRadius: 50,
                //borderWidth: 3,
              }}>
              <Text 
                style={{
                  color: "black",
                  fontFamily: "Inter-Extra-Bold",
                  fontSize: 17,
                  marginTop: "12%",
                  marginLeft: "45%"}}
              >
                Regresar
              </Text>
              <FontAwesome 
                  style={{
                    marginTop: "-21%",
                    marginLeft: "10%",
                  }}
                  name="arrow-circle-left" 
                  size={55} 
                  color="black" 
                />
            </TouchableOpacity> 
        </View>
    );
};

export default Condiciones;