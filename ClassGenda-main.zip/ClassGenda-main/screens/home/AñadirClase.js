// Pantalla de añadir clase.
// -------------------------- DEPENDENCIAS ------------------------------------
import React, { useState, useRef } from 'react';
import { View,
  TextInput,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { useRoute } from '@react-navigation/native';
import {Picker as SelectPicker } from '@react-native-picker/picker';
import {DateTimePickerAndroid} from '@react-native-community/datetimepicker';
import LottieView from 'lottie-react-native';
// ---------------------- SUPABASE ---------------------------------------------
import { supabase } from '../../lib/supabase';
// ----------------------- COMPONENTES ----------------------------------------
import  {ROUTES, IMAGENES, PALETADECOLORES} from '../../components';
// ------------------------- ICONOS --------------------------------------------
import {
  AntDesign,
  FontAwesome,
} from "@expo/vector-icons";

const AñadirClase = (props) => {

  //Importar navigation, dado que este permite que la app se desplace entre pantallas correctamente.
  const navigation = useNavigation();

  const route = useRoute();
  const nrc = route.params?.codigo_materia;
  console.log("AQUI ESTA EL PASO POR PARAMETROS a añadir: ",nrc);
  
  //Valor para guardar una clase.
  const [guardado, setGuardado] = useState(false);
  
  //Gesto para guardar una clase nueva.
  const handleGuardado = async() => {
    setGuardado(true);
    const { data, error } = await supabase
    .from('Classes')
    .insert([
        { //Valores que se guarda en la BD.
        NRC: nrc,
        Name: nombreclase,
        Description: descripcion,
        Status: 0,
        Date: date,
        },
    ])
    .select();
    if (error) {
    console.error('Error al insertar datos:', error);
    } else {
    console.log('Datos insertados con éxito:', data);
    }
  };

  //Valores al momento de haber guardado: añadir otra clase y regresar a pantalla principal.
  const handleOtraClase = () => {
    setGuardado(false);
  };

  //Picker fecha:
  const [date, setDate] = useState(new Date());
  
  const onChange = (event, selectedDate) => {
    const currentDate = selectedDate;
    setDate(currentDate);
  };

  const showMode = () => {
    DateTimePickerAndroid.open({
      value: date,
      onChange,
      mode: "date",
      is24Hour: true,

      //Rango de fecha para el picker.
      minimumDate: new Date('2023-01-01'),
      maximumDate: new Date('2051-12-31'),
    });
  };

  //Modo en que se presenta la fecha o información.
  const showDatePicker = () => {
    showMode("date");
  };

  //Valores para el picker: Estatus.
  const [estatusValueClass, setestatusValueClass] = useState();

  const pickerRefEstatus = useRef();

  function open() {
    pickerRefEstatus.current.focus();
  }

  function close() {
    pickerRefEstatus.current.blur();
  }

  //Valores para añadir una clase.
  const [nombreclase, setnombreclase] = useState('');
  const [descripcion, setdescripcion] = useState('');

  const handleLogin = () => {
    //Autentificacion para los valores de añadir clase.
    console.log('Nombre de asignatura:', nombreAsignatura);
    console.log('Descripcion:', descripcion);
  };

  return (
    <ScrollView>
      <View style={{alignItems: 'center', width: 400}}>
        {!guardado ? (
          <View
            style={{                  //Fondo de la pantalla en general.
              backgroundColor: 'white', 
              height: 800,
              width: 460,
              paddingTop: 100,
              alignItems: 'center',
            }}>
            <View
              style={{                 // Fondo del primer bloque de datos (Clase).
                backgroundColor: PALETADECOLORES.Azul,
                height: 100,
                width: 350,
                paddingTop: 10,
                borderRadius: 20,
                marginVertical: -26,
                marginLeft: 10,
              }}>
              <Text                //Titulo del campo clase.
                style={{
                  color: 'black',
                  fontSize: 15,
                  fontFamily: "Inter-Bold",
                  marginVertical: 2,
                  marginLeft: 20,
                }}>
                Clase :
              </Text>
              <TextInput
                style={{          //Primer campo de ingreso - clase.
                  borderRadius: 20, color: "black", 
                  paddingHorizontal: 9, 
                  height: '50%', width: '88%', 
                  backgroundColor: 'white', 
                  marginVertical: 3,
                  borderColor: "black",
                  borderWidth: 3,
                  borderRadius: 10,
                  marginLeft: 20,
                  fontFamily: "Riot-Regular",
                }}
                placeholder="Historia de la Algoritmia" onChangeText={text => setnombreclase(text)}
                value={nombreclase}
                >
              </TextInput>
            </View>
            <View
              style={{                  // Fondo para el campo de descripción.
                backgroundColor: PALETADECOLORES.AmarilloPatito, 
                height: 250,
                width: 350,
                paddingTop: 10,
                borderRadius: 20,
                marginVertical: 50,
                marginLeft: 10,
              }}>
              <Text                     //Titulo del campo - descripción.
                style={{
                  color: 'black',
                  fontSize: 15,
                  fontFamily: "Inter-Bold",
                  marginVertical: 7,
                  marginLeft: 20,
                }}>
                Descripción de la clase :
              </Text>
              <TextInput
                style={{                    //Primer campo de ingreso - descripción.
                  borderRadius: 20, color: "black", 
                  paddingHorizontal: 9, 
                  height: '72%', width: '88%', 
                  backgroundColor: 'white', 
                  marginVertical: 7,
                  borderColor: "black",
                  borderWidth: 3,
                  borderRadius: 10,
                  marginLeft: 20,
                  fontFamily: "Riot-Regular",
                }}
                multiline numberOfLines={4}
                placeholder="La asignatura consta de..." onChangeText={text => setdescripcion(text)}
                value={descripcion}
                >
              </TextInput>
            </View>
            <View
              style={{                      // Fondo para la fecha.
                backgroundColor: PALETADECOLORES.Azul, 
                height: 140,
                width: 140,
                paddingTop: 10,
                borderRadius: 20,
                marginVertical: -25,
                marginLeft: 10,
                marginRight: "3%",
                marginLeft: "-40%",
              }}>
              <Text                       //Titulo del campo - fecha.
                style={{
                  color: 'black',
                  fontSize: 15,
                  fontFamily: "Inter-Bold",
                  marginVertical: 2,
                  marginLeft: 45,
                }}>
                Fecha
              </Text>
              <TouchableOpacity           //Picker date.
                onPress={showDatePicker}
                style={styles.buttonPickerDate}>        
                <Text style={{
                  fontSize: 14.5,
                  marginVertical: '8%',
                  marginLeft: '4%',
                }}>Select date</Text>
              </TouchableOpacity>
              <View
                style={{
                  backgroundColor: 'white',
                  borderRadius: 10,
                  height: 30,
                  width: 120,
                  marginVertical: '8%',
                  marginLeft: '7%',
                }}
              >
                <Text
                  style={{
                    fontFamily: 'Riot-Regular',
                    fontSize: 17.5,
                    marginVertical: '-0.5%',
                    textAlign: 'center',
                  }}
                >
                  {date.toLocaleDateString()}
                </Text>
              </View>
            </View>
            <View
              style={{                          // Fondo para el estatus.
                backgroundColor: PALETADECOLORES.Azul, 
                height: 100,
                width: 180,
                paddingTop: 10,
                borderRadius: 20,
                marginVertical: -93,
                marginLeft: 10,
                marginRight: "3%",
                marginLeft: "41%",
              }}>
              <Text                             //Titulo del campo - estatus.
                style={{
                  color: 'black',
                  fontSize: 15,
                  fontFamily: "Inter-Bold",
                  marginVertical: 2,
                  marginLeft: 60,
                }}>
                Estatus
              </Text>
              <View
                style={{
                  backgroundColor: 'white',             //Fondo del picker.
                  borderRadius: 10,
                  borderWidth: 3,
                  height: 50,
                  width: 155,
                  marginVertical: '2%',
                  marginLeft: '7%',
                }}
              >
                <SelectPicker                          //Estatus picker.
                  ref={pickerRefEstatus}
                  style={{
                    marginVertical: '-3%',
                    marginLeft: '-7%',
                  }}
                  selectedValue={estatusValueClass}
                  onValueChange={
                    (itemValue, itemIndex) => setestatusValueClass(itemValue)
                  }
                >
                  <SelectPicker.Item 
                    label='Select'
                    enabled={false} 
                  />
                  <SelectPicker.Item 
                    label="En proceso" 
                    value="proceso" 
                  />
                  <SelectPicker.Item 
                    label="Terminado" 
                    value="terminado"
                  />
                </SelectPicker>
              </View>
            </View>
            <TouchableOpacity           //Botón para guardar la clase nueva.
              onPress={handleGuardado}
              style={styles.buttonGuardar}>        
              <Text style={styles.buttonTextGuardar}>Guardar</Text>
            </TouchableOpacity> 
            <TouchableOpacity
              onPress={() => props.navigation.navigate(ROUTES.ASIGNATURA)}
              style={styles.buttonCancelar}>        
              <Text style={styles.buttonTextCancelar}>Cancelar</Text>
            </TouchableOpacity> 
          </View>
        ) : (
          //Pantalla una vez se da clic en el bótón 'guardar'.
          <View style={{alignItems: 'center', width: 400, height: 800}}>
            <Text 
              style={{
                marginVertical: "14%", 
                fontSize: 36, 
                fontFamily: 'Riot-Regular',
                textAlign: 'center', 
                }}
            > 
              ¡Clase guardada!
            </Text>
            <LottieView
              source={IMAGENES.Done}
              autoPlay
              loop={true}
              style={{
                  flexGrow: 1,
                  marginVertical: "-20%",
                  marginLeft: '-13%',
                  width: 1000,
                  height: 500,
              }}
            />
            <TouchableOpacity                //Boton para agregar otra clase.
              onPressIn={() => props.navigation.navigate(ROUTES.AÑADIR_CLASE)}
              onPressOut={handleOtraClase}  //Aquí se cambia el estado.
              style={{
                backgroundColor: PALETADECOLORES.AmarilloPatito,
                borderRadius: 30,
                borderColor: "black",
                marginVertical: "15%",
                marginRight: "-30%",
                marginLeft: "3%",
                width: 190,
                marginBottom: '20%',
                height: 70,
                borderRadius: 50,
                borderWidth: 3,
              }}>
              <Text 
                style={{
                  color: "black",
                  fontFamily: "Inter-Bold",
                  fontSize: 17,
                  marginTop: "5%",
                  marginLeft: "39%"}}
              >
                Añadir otra
              </Text>
              <Text 
                style={{
                  color: "black",
                  fontFamily: "Inter-Bold",
                  fontSize: 17,
                  marginTop: "-1%",
                  marginLeft: "52%"}}
              >
                clase
              </Text>
              <AntDesign 
                  style={{
                    marginTop: "-27%",
                    marginLeft: "11%",
                  }}
                  name="addfile" 
                  size={46} 
                  color="black" 
                />
            </TouchableOpacity>
            <TouchableOpacity               //Boton que te regresa a la pantalla principal.
              onPressIn={() => props.navigation.navigate(ROUTES.PAGINA_PRINCIPAL)}
              onPressOut={handleOtraClase}  //Aquí se cambia el estado.
              style={{
                backgroundColor: PALETADECOLORES.RojoMamey,
                borderRadius: 30,
                borderColor: "black",
                marginVertical: "-12%",
                marginBottom: '20%',
                marginLeft: "3%",
                marginRight: "-30%",
                width: 190,
                height: 70,
                borderRadius: 50,
                borderWidth: 3,
              }}>
              <Text 
                style={{
                  color: "black",
                  fontFamily: "Inter-Bold",
                  fontSize: 17,
                  marginTop: "10%",
                  marginLeft: "45%"}}
              >
                Regresar
              </Text>
              <FontAwesome 
                  style={{
                    marginTop: "-21%",
                    marginLeft: "10%",
                  }}
                  name="arrow-circle-left" 
                  size={55} 
                  color="black" 
                />
            </TouchableOpacity>
          </View>
        )}
          
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  input: {
    width: '77%',
    height: "8%",
    borderRadius: 10,
    marginLeft: "20%",
  },
  inputDescripcion: {
    width: '80%',
    height: "60%",
    borderRadius: 10,
    marginLeft: "20%",
  },
  buttonTextGuardar: {
    color: "black",
    fontFamily: "Inter-Bold",
    fontSize: 17,
    marginTop: "0%",
    marginLeft: "16%",
  },
  buttonTextCancelar: {
    color: "black",
    fontFamily: "Inter-Bold",
    fontSize: 17,
    marginTop: "4%",
    marginLeft: "14%",
  },
  buttonGuardar: {
    backgroundColor: PALETADECOLORES.Azul,
    borderRadius: 30,
    borderColor: "black",
    marginVertical: "35%",
    marginRight: "3%",
    marginLeft: "-24%",
    width: 110,
    height: 40,
    borderRadius: 50,
    paddingVertical: 5, 
    borderWidth: 3,
  },
  buttonCancelar: {
    backgroundColor: PALETADECOLORES.RojoMamey,
    borderRadius: 30,
    borderColor: "black",
    marginVertical: "-44%",
    marginRight: "-28%",
    marginLeft: "3%",
    width: 110,
    height: 40,
    borderRadius: 50,
    borderWidth: 3,
  },
  buttonPickerDate: {
    borderRadius: 20, color: "white", //Primer campo - fecha.
    paddingHorizontal: 9, 
    height: '30%', width: '75%', 
    backgroundColor: 'white', 
    marginVertical: 4,
    borderColor: "black",
    borderWidth: 3,
    borderRadius: 10,
    marginLeft: 17,
  },
  pickerEstatus: {
    width: 80,
    height: 35,
    backgroundColor: 'white',
    borderColor: 'black',
    borderRadius: 30,
    borderWidth: 3,
  },
});

export default AñadirClase;
