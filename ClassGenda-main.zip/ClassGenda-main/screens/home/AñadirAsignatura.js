// Pantalla  de añadir asignatura
// ----------------------------------------- DEPENDENCIAS ------------------------------------
import React, { useState, useEffect, useRef } from 'react';
import { View,
  TextInput,
  //ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
} from 'react-native';
import {Picker as SelectPicker} from '@react-native-picker/picker';
import { useNavigation } from '@react-navigation/native';
import {DateTimePickerAndroid} from '@react-native-community/datetimepicker';
import LottieView from 'lottie-react-native';
import DropDownPicker from 'react-native-dropdown-picker';
import { ScrollView } from 'react-native-gesture-handler';
// ----------------------------------------- COMPONENTES ------------------------------------
import  {ROUTES, IMAGENES, PALETADECOLORES} from '../../components';
import { useUserCode } from '../auth/UserCodeProvider';
// ------------------------------- SUPABASE --------------------------------------------------
import { supabase } from '../../lib/supabase';
import Students_Query from '../../backend/Querys/Students_Query';
import Teachers_Query from '../../backend/Querys/Teachers_Querys';
// ------------------------- ICONOS -----------------------------------------------------
import {
  AntDesign,
  FontAwesome,
} from "@expo/vector-icons";

const Students = [
  {
    id: 1,
    code: "1",
  },
  {
    id: 2,
    code: "2",
  },
  {
    id: 3,
    code: "3",
  },
  {
    id: 4,
    code: "4",
  },
  {
    id: 5,
    code: "5",
  },
  {
    id: 6,
    code: "6",
  },
  {
    id: 7,
    code: "7",
  },
  {
    id: 8,
    code: "8",
  },
  {
    id: 9,
    code: "9",
  },
  {
    id: 10,
    code: "10",
  },
  {
    id: 11,
    code: "1",
  },
  {
    id: 12,
    code: "2",
  },
  {
    id: 13,
    code: "3",
  },
  {
    id: 14,
    code: "4",
  },
  {
    id: 15,
    code: "5",
  },
  {
    id: 16,
    code: "6",
  },
  {
    id: 17,
    code: "7",
  },
  {
    id: 18,
    code: "8",
  },
  {
    id: 19,
    code: "9",
  },
  {
    id: 20,
    code: "10",
  },
];

const AñadirAsignatura = (props) => {

  const { userCode } = useUserCode();

  //Importar navigation, dado que este permite que la app se desplace entre pantallas correctamente.
  const navigation = useNavigation();

  const codigoMaestro = userCode[0].User_Id;
  
   // Valor de bandera para asignaturas creadas.
  const [guardado, setGuardado] = useState(false);
  
// Gesto para guardar la asignatura y continuar.
  const handleGuardado = async() => {
    setGuardado(true);
    const { data, error } =  await supabase
    .from('Subject')
    .insert([
        { //Valores a guardar en la BD.
        NRC: valorNrc,
        Teacher_ID: codigoMaestro,
        Name: nombreAsignatura,
        Status: 0,
        Start_Date: dateInicio,
        End_Date: dateFinal,
        Description: descripcion,
        Students_IDs: Students,
        },
    ])
    .select();
    if (error) {
    console.error('Error al insertar datos:', error);
    } else {
    console.log('Datos insertados con éxito:', data, error);
    }
  };

  //Valores al momento de haber guardado: añadir otra asignatura y regresar a pantalla principal.
  const handleOtraAsignatura = () => {
    setGuardado(false);
  };
  
  //Picker fecha:
  const [dateInicio, setDateInicio] = useState(new Date());
  const [dateFinal, setDateFinal] = useState(new Date());

  const onChangeInicio = (event1, selectedDate) => {
    const currentDate1 = selectedDate;
    setDateInicio(currentDate1);
  };

  const onChangeFinal = (event2, selectedDate) => {
    const currentDate2 = selectedDate;
    setDateFinal(currentDate2);
  };

  const showModeInicio = () => {
    DateTimePickerAndroid.open({
      value: dateInicio,
      onChange: onChangeInicio,
      mode: "date",
      is24Hour: true,

      //Rango de fechas del picker para fecha inicial.
      minimumDate: new Date('2023-01-01'),
      maximumDate: new Date('2051-12-31'),
    });
  };

  const scrollview = useRef(null);

  const showModeFinal = () => {
    DateTimePickerAndroid.open({
      value: dateFinal,
      onChange: onChangeFinal,
      mode: "date",
      is24Hour: true,

      //Rango de fecha del picker para fecha final.
      minimumDate: new Date('2023-01-01'),
      maximumDate: new Date('2051-12-31'),
    });
  };

  //Modo en que se presenta la fecha o información inicial.
  const showDateInicio = () => {
    showModeInicio("date");
  };
  //Modo en que se presenta la fecha o información final.
  const showDateFinal = () => {
    showModeFinal("date");
  };

  //Valores para los pickers.
  const [estatusValueAsig, setestatusValueAsig] = useState(); //ESTATUS.
  const pickerRefEstatus = useRef();
  function open() {
    pickerRefEstatus.current.focus();
  }
  function close() {
    pickerRefEstatus.current.blur();
  }
  const [openDrop2, setOpenDrop2] = useState(false);  //ALUMNOS
  const [ProfesorValue, setProfesorValue] = useState(); //PROFESORES.
  const pickerRefProfesor = useRef();
  const codes2 = Teachers_Query();
  const ProfItems = codes2.users;
  function open() {
    pickerRefProfesor.current.focus();
  }
  function close() {
    pickerRefProfesor.current.blur();
  }

  const [openDrop, setOpenDrop] = useState(false);  //ALUMNOS
  const [CurrentAlumno, setCurrentAlumno] = useState([]);
  const codes = Students_Query();
  const items = codes.users;

  //Valores para añadir asignatura.
  const [nombreAsignatura, setnombreAsignatura] = useState('');
  const [descripcion, setdescripcion] = useState('');
  
  const handleLogin = () => {
    //Autentificacion de valores para añadir asignatura.
    console.log('Nombre de asignatura:', nombreAsignatura);
    console.log('Descripcion:', descripcion);
  };

  //Valor del NRC
  const [valorNrc, setValorNrc] = useState('');

  return (
    <ScrollView>
      <View style={{alignItems: 'center', width: 400}}>
        {!guardado ? (
          <View
            style={{
              backgroundColor: 'white', //Fondo de la pantalla en general.
              height: 800,
              width: 460,
              paddingTop: 100,
              alignItems: 'center',
            }}>
            <View
              style={{                // Fondo del primer bloque de datos (Nombre de asignatura).
                backgroundColor: PALETADECOLORES.RojoMamey, 
                height: 90,
                width: 350,
                paddingTop: 10,
                borderRadius: 20,
                marginVertical: -80,
                marginLeft: 10,
              }}>
              <Text                    //Titulo del campo de asignatura.
                style={{
                  color: 'black',
                  fontSize: 15,
                  fontFamily: "Inter-Bold",
                  marginVertical: -2,
                  marginLeft: 16,
                }}>
                Nombre de asignatura :
              </Text>
              <TextInput
                style={{                  //Primer campo de ingreso - asignatura.
                  borderRadius: 20, color: "black", 
                  paddingHorizontal: 9, 
                  height: '50%', width: '94%', 
                  backgroundColor: 'white', 
                  marginVertical: 9,
                  borderColor: "black",
                  borderWidth: 3,
                  borderRadius: 10,
                  marginLeft: 10,
                  fontFamily: "Riot-Regular",
                  fontSize: 16,
                }}
                placeholder="Algoritmia" onChangeText={text => setnombreAsignatura(text)}
                value={nombreAsignatura}
                >
              </TextInput>
            </View>
            <View
              style={{                // Fondo para la fecha (incluye inicio y termina).
                backgroundColor: PALETADECOLORES.AmarilloPatito, 
                height: 200,
                width: 170,
                paddingTop: 10,
                borderRadius: 20,
                marginVertical: 95,
                marginLeft: 10,
                marginRight: "3%",
                marginLeft: "-31%",
              }}>
              <Text                     //Titulo del campo - fecha de inicio.
                style={{
                  color: 'black',
                  fontSize: 15,
                  fontFamily: "Inter-Bold",
                  marginVertical: -6,
                  marginLeft: 65,
                }}>
                Inicia:
              </Text>
              <Text                       //Fecha de inicio ingresada por el usuario.
                  style={{
                    fontFamily: 'Kod-Regular',
                    fontSize: 14.5,
                    marginVertical: '2%',
                    marginLeft: '25%',
                  }}
              >
                {dateInicio.toLocaleDateString()}
              </Text>
              <TouchableOpacity           //Boton picker de fecha de inicio.
                onPress={showDateInicio}
                style={styles.buttonPickerDateInicio}>        
                <Text style={{
                  fontSize: 14.5,
                  marginVertical: '5%',
                  textAlign: 'center',
                }}>Select date</Text>
              </TouchableOpacity>
              <View 
                style={{
                  backgroundColor: "white", //Linea de adorno.
                  height: "1.2%",
                  width: "90%",
                  marginLeft: "5%",
                  marginTop: "9%",
                  marginRight: "5%",
                }}/>
              <Text                         //Titulo del campo - fecha inicio.
                style={{
                  color: 'black',
                  fontSize: 15,
                  fontFamily: "Inter-Bold",
                  marginVertical: 5,
                  marginLeft: 53,
                }}>
                Termina:
              </Text>
              <Text                          //Fecha inicio ingresada por el usuario.
                  style={{
                    fontFamily: 'Kod-Regular',
                    fontSize: 14.5,
                    marginVertical: '-6%',
                    marginLeft: '27%',
                  }}
              >
                {dateFinal.toLocaleDateString()}
              </Text>
              <TouchableOpacity             //Boton picker de fecha final.
                onPress={showDateFinal}
                style={styles.buttonPickerDateFinal}>        
                <Text style={{
                  fontSize: 14.5,
                  marginVertical: '5%',
                  textAlign: 'center',
                }}>Select date</Text>
              </TouchableOpacity>
            </View>
            <View
              style={{                     // Fondo para el NRC.
                backgroundColor: PALETADECOLORES.AmarilloPatito,
                height: 95,
                width: 165,
                paddingTop: 10,
                borderRadius: 20,
                marginVertical: -294,
                marginLeft: 10,
                marginRight: "3%",
                marginLeft: "45%",
              }}>
                <Text                     //Titulo del campo - nrc.
                style={{
                  color: 'black',
                  fontSize: 15,
                  fontFamily: "Inter-Bold",
                  marginVertical: -3,
                  marginLeft: "39%"
                }}>
                NRC
              </Text>
              <TextInput
                style={{                  //Primer campo de ingreso - asignatura.
                  borderRadius: 20, color: "black", 
                  paddingHorizontal: 9, 
                  height: '50%', width: '88%', 
                  backgroundColor: 'white', 
                  marginVertical: 9,
                  borderColor: "black",
                  borderWidth: 3,
                  borderRadius: 10,
                  marginLeft: 10,
                  fontFamily: "Riot-Regular",
                  fontSize: 16,
                  textAlign: 'center',
                }}
                placeholder="I7034" onChangeText={text => setValorNrc(text)}
                value={valorNrc}
                >
              </TextInput>
            </View>
            <View
              style={{
                backgroundColor: PALETADECOLORES.AmarilloPatito, // Fondo para el estatus.
                height: 95,
                width: 165,
                paddingTop: 10,
                borderRadius: 20,
                marginVertical: 305,
                marginLeft: 10,
                marginRight: "3%",
                marginLeft: "45%",
              }}>
              <Text                     //Titulo del campo - estatus.
                style={{
                  color: 'black',
                  fontSize: 15,
                  fontFamily: "Inter-Bold",
                  marginVertical: -3,
                  marginLeft: 50,
                }}>
                Estatus
              </Text>
              <View
                style={{
                  backgroundColor: 'white', //Fondo del picker.
                  borderRadius: 10,
                  borderWidth: 3,
                  height: 50,
                  width: 142,
                  marginVertical: '5%',
                  marginLeft: '7%',
                }}
              >
                <SelectPicker                //Estatus picker.
                  ref={pickerRefEstatus}
                  style={{
                    marginVertical: '-3%',
                    marginLeft: '-9%',
                  }}
                  selectedValue={estatusValueAsig}
                  onValueChange={
                    (itemValue, itemIndex) => setestatusValueAsig(itemValue)
                  }
                >
                  <SelectPicker.Item 
                    label='Select'
                    enabled={false} 
                  />
                  <SelectPicker.Item 
                    label="En proceso" 
                    value="proceso" 
                  />
                  <SelectPicker.Item 
                    label="Terminado" 
                    value="terminado"
                  />
                </SelectPicker>
              </View>
            </View>
            <View
              style={{
                backgroundColor: PALETADECOLORES.RojoMamey, // Fondo para el campo de descripción.
                height: 170,
                width: 350,
                paddingTop: 10,
                borderRadius: 20,
                marginVertical: -290,
                marginLeft: 10,
              }}>
              <Text                     //Titulo del campo - descripción.
                style={{
                  color: 'black',
                  fontSize: 15,
                  fontFamily: "Inter-Bold",
                  marginVertical: -3,
                  marginLeft: 20,
                }}>
                Descripción de la asignatura:
              </Text>
              <TextInput
                style={{
                  borderRadius: 20, color: "black", //Primer campo de ingreso - descripción.
                  paddingHorizontal: 9, 
                  height: '77%', width: '88%', 
                  backgroundColor: 'white', 
                  marginVertical: 8,
                  borderColor: "black",
                  borderWidth: 3,
                  borderRadius: 10,
                  marginLeft: 20,
                  fontFamily: "Riot-Regular",
                  fontSize: 16,
                }}
                multiline numberOfLines={4}
                placeholder="La asignatura consta de..." onChangeText={text => setdescripcion(text)}
                value={descripcion}
                >
              </TextInput>
            </View>
            <View
              style={{
                backgroundColor: PALETADECOLORES.AmarilloPatito, // Fondo del primer bloque de seleccion (Profesor y alumnos).
                height: 185,
                width: 350,
                paddingTop: 10,
                borderRadius: 20,
                marginVertical: 310,
                marginLeft: 10,
              }}>
              <Text
                style={{                        //Titulo del primer campo.
                  color: 'black',
                  fontSize: 15,
                  fontFamily: "Inter-Bold",
                  marginVertical: -2,
                  marginLeft: 20,
                }}>
                Selección del profesor:
              </Text>
              <View
                style={{
                  //Fondo del picker - PROFESORES.
                  borderRadius: 10,
                  height: 44,
                  width: 325,
                  marginVertical: '1%',
                  marginLeft: '3.9%',
                }}
              >
                <DropDownPicker
                  items={ProfItems}
                  open={openDrop2}
                  setOpen={() => setOpenDrop2(!openDrop2)}
                  value={ProfesorValue}
                  setValue={(val) => setProfesorValue(val)}
                  
                  maxHeight={200}
                  listMode="SCROLLVIEW" 
                  scrollViewProps={{
                    nestedScrollEnabled: true,
                  }}

                  placeholder='Select'
                  placeholderStyle={{
                    fontSize: 14
                  }}

                  showTickIcon={true}
                  showArrowIcon={true}

                  //theme="DARK"
                  multiple={false}
                  min={1}

                  searchable={true}
                  searchPlaceholder="Search..."
                  searchTextInputStyle={{
                    color: "#000"
                  }}

                  itemSeparator={true}
                  itemStyle={{ 
                    borderColor: 'black',
                    borderWidth: 3,
                  }}

                  mode="BADGE"
                  badgeColors={[PALETADECOLORES.RojoMamey]}
                  badgeDotColors={["white"]}

                  style={{
                    borderColor: 'black',
                    borderWidth: 3,
                  }}
                />
              </View>
              <Text
                style={{                            //Titulo del segundo campo.
                  color: 'black',
                  fontSize: 15,
                  fontFamily: "Inter-Bold",
                  marginVertical: 10,
                  marginLeft: 20,
                }}>
                Selección de alumnos:
              </Text>
              <View
                style={{
                  //Fondo del picker - ALUMNOS.
                  borderRadius: 10,
                  height: 54.2,
                  width: 324.5,
                  marginVertical: '-2.2%',
                  marginLeft: '3.9%',
                }}
              >
                <DropDownPicker
                  items={items}
                  open={openDrop}
                  setOpen={() => setOpenDrop(!openDrop)}
                  value={CurrentAlumno}
                  setValue={(val) => setCurrentAlumno(val)}
                  
                  maxHeight={200}
                  listMode="SCROLLVIEW" 


                  placeholder='Select'
                  placeholderStyle={{
                    fontSize: 14
                  }}

                  showTickIcon={true}
                  showArrowIcon={true}

                  //theme="DARK"
                  multiple={true}
                  min={1}

                  searchable={true}
                  searchPlaceholder="Search..."
                  searchTextInputStyle={{
                    color: "#000"
                  }}

                  itemSeparator={true}
                  itemStyle={{ 
                    borderColor: 'black',
                    borderWidth: 3,
                  }}

                  mode="BADGE"
                  badgeColors={[PALETADECOLORES.RojoMamey]}
                  badgeDotColors={["white"]}

                  style={{
                    borderColor: 'black',
                    borderWidth: 3,
                  }}
                />
              </View>
            </View>
            <TouchableOpacity           //Botón para guardar la asignatura creada.
              onPress={handleGuardado}
              style={styles.buttonGuardar}>        
              <Text style={styles.buttonTextGuardar}>Guardar</Text>
            </TouchableOpacity>  
            <TouchableOpacity
              onPress={() => props.navigation.navigate(ROUTES.PAGINA_PRINCIPAL)}
              style={styles.buttonCancelar}>        
              <Text style={styles.buttonTextCancelar}>Cancelar</Text>
            </TouchableOpacity>       
          </View>
        ) : (
          //Pantalla una vez se da clic en el bótón 'guardar'.
          <View style={{alignItems: 'center', width: 400, height: 800}}>
            <Text 
              style={{
                marginVertical: "20%", 
                fontSize: 25, 
                fontFamily: 'Inter-Bold',
                textAlign: 'center', 
                }}
            > 
              ¡Asignatura guardada!
            </Text>
            <LottieView
              source={IMAGENES.Done}
              autoPlay
              loop={true}
              style={{
                  flexGrow: 1,
                  marginVertical: "-20%",
                  marginLeft: '-13%',
                  width: 1000,
                  height: 500,
              }}
            />
            <TouchableOpacity               //Boton para agregar otra clase.
              onPressIn={() => props.navigation.navigate(ROUTES.AÑADIR_ASIGNATURA)}
              onPressOut={handleOtraAsignatura}  //Aquí se cambia el estado.
              style={{
                backgroundColor: PALETADECOLORES.AmarilloPatito,
                borderRadius: 30,
                borderColor: "black",
                marginVertical: "15%",
                marginRight: "-30%",
                marginLeft: "3%",
                width: 200,
                marginBottom: '20%',
                height: 70,
                borderRadius: 50,
                borderWidth: 3,
              }}>
              <Text 
                style={{
                  color: "black",
                  fontFamily: "Inter-Bold",
                  fontSize: 17,
                  marginTop: "5%",
                  marginLeft: "44%"}}
              >
                Añadir otra
              </Text>
              <Text 
                style={{
                  color: "black",
                  fontFamily: "Inter-Bold",
                  fontSize: 17,
                  marginTop: "-1%",
                  marginLeft: "44.5%"}}
              >
                asignatura
              </Text>
              <AntDesign 
                  style={{
                    marginTop: "-25%",
                    marginLeft: "12%",
                  }}
                  name="addfolder" 
                  size={49} 
                  color="black" 
                />
            </TouchableOpacity>
            <TouchableOpacity             //Boton que te regresa a la pantalla principal.
              onPressIn={() => props.navigation.navigate(ROUTES.PAGINA_PRINCIPAL)}
              onPressOut={handleOtraAsignatura}  //Aquí se cambia el estado.
              style={{
                backgroundColor: PALETADECOLORES.RojoMamey,
                borderRadius: 30,
                borderColor: "black",
                marginVertical: "-12%",
                marginBottom: '20%',
                marginLeft: "3%",
                marginRight: "-30%",
                width: 190,
                height: 70,
                borderRadius: 50,
                borderWidth: 3,
              }}>
              <Text 
                style={{
                  color: "black",
                  fontFamily: "Inter-Bold",
                  fontSize: 17,
                  marginTop: "10%",
                  marginLeft: "45%"}}
              >
                Regresar
              </Text>
              <FontAwesome 
                  style={{
                    marginTop: "-21%",
                    marginLeft: "10%",
                  }}
                  name="arrow-circle-left" 
                  size={55} 
                  color="black" 
                />
            </TouchableOpacity>
          </View>
        )}
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  input: {
    width: '77%',
    height: "8%",
    borderRadius: 10,
    marginLeft: "20%",
  },
  inputDescripcion: {
    width: '80%',
    height: "50%",
    borderRadius: 10,
    marginLeft: "13%",
  },
  buttonTextGuardar: {
    color: "black",
    fontFamily: "Inter-Bold",
    fontSize: 17,
    marginTop: "0%",
    marginLeft: "17%",
  },
  buttonTextCancelar: {
    color: "black",
    fontFamily: "Inter-Bold",
    fontSize: 17,
    marginTop: "4%",
    marginLeft: "14%",
  },
  buttonGuardar: {
    backgroundColor: PALETADECOLORES.Azul,
    borderRadius: 30,
    borderColor: "black",
    marginVertical: "-63%",
    marginRight: "3%",
    marginLeft: "-24%",
    width: 110,
    height: 40,
    borderRadius: 50,
    paddingVertical: 5, 
    borderWidth: 3,
  },
  buttonCancelar: {
    backgroundColor: PALETADECOLORES.RojoMamey,
    borderRadius: 30,
    borderColor: "black",
    marginVertical: "54.4%",
    marginRight: "-30%",
    marginLeft: "3%",
    width: 110,
    height: 40,
    borderRadius: 50,
    borderWidth: 3,
  },
  buttonPickerDateInicio: {
    borderRadius: 20, color: "black", //Primer campo - fecha de inicio.
    paddingHorizontal: 9, 
    height: '20%', width: '75%', 
    backgroundColor: 'white', 
    marginVertical: -3,
    borderColor: "black",
    borderWidth: 3,
    borderRadius: 10,
    marginLeft: 20,
    fontFamily: "Kod-Bold",
  },
  buttonPickerDateFinal: {
    borderRadius: 20, color: "black", //Primer campo - fecha de termino.
    paddingHorizontal: 9, 
    height: '20%', width: '75%', 
    backgroundColor: 'white', 
    marginVertical: 10,
    borderColor: "black",
    borderWidth: 3,
    borderRadius: 10,
    marginLeft: 23,
    fontFamily: "Kod-Bold",
  },
});

export default AñadirAsignatura;
