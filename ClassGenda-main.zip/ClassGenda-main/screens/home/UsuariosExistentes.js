// Pantalla del administrador - usuarios existentes.
// ---------------------------- DEPENDENCIAS ---------------------------------
import React, { useState, useEffect } from 'react';
import { View,
  StyleSheet,
  Text,
  FlatList,
} from 'react-native';
// ------------------------------ COMPONENTES --------------------------------
import  {PALETADECOLORES} from '../../components';
import Inscritos from "../../components/Inscritos";
import Inscritos_Teachers from "../../components/Inscritos_Teachers";
// ---------------------------- BACK ----------------------------------------
import UsersByLevel_Query from '../../backend/Querys/UsersByLevel_Query';
import Login from '../auth/Login';
import Pfp_Query from '../../backend/Querys/Pfp_Query';

const UsuariosExistentes = ( ) => {
  /*
  const JSON = Pfp_Query("217537881");
  const Foto =  JSON[0].User_Picture;
  const Foto2 = Foto[0].image.name;
  */
   /*
  const Foto2 =  Foto[0];
  console.log(Foto);
   
    if(Foto!=0){
      const imageUrl = Foto[0].image.name; // Aquí se asume que el JSON es un arreglo de objetos
    }
  }
  */

  //Valores para mostrar a los usuarios (tanto profesores como alumnos) registrados en la aplicación.
  const Maestros = UsersByLevel_Query(1);
  const Students = UsersByLevel_Query(2);

  return (
    <View style={{alignItems: 'center', width: 400}} >
        <View
          style={{
            backgroundColor: 'white',                         //Fondo de la pantalla en general.
            height: 800,
            width: 460,
            paddingTop: 100,
            alignItems: 'center',
          }}>
          <View
            style={{                                         // Fondo del primer bloque de datos (Lista de profesores).
              backgroundColor: PALETADECOLORES.AmarilloPatito, 
              height: 250,
              width: 350,
              paddingTop: 10,
              borderRadius: 20,
              marginVertical: -50,
              marginLeft: 10,
            }}>
            <Text                                            //Titulo del campo - profesores listado.
              style={{
                color: 'black',
                fontSize: 17,
                fontFamily: "Riot-Regular",
                marginVertical: 2,
                marginLeft: 20,
              }}>
              Lista de profesores :
            </Text>
            <View style={styles.underline}/>
            <View style={styles.ListBox}>
              <FlatList
              data = {Maestros}
              renderItem={({item}) => <Inscritos_Teachers teachers={item}/>}
              keyExtractor={item=>item.User_Id}
              />
            </View>
          </View>
          <View
              style={{                                // Fondo del segundo bloque de datos (Lista de alumnos).
                backgroundColor: PALETADECOLORES.RojoMamey, 
                height: 250,
                width: 350,
                paddingTop: 10,
                borderRadius: 20,
                marginVertical: 80,
                marginLeft: 7,
              }}>
              <Text                                         //Titulo del campo - alumnos listado.
                style={{
                  color: 'black',
                  fontSize: 17,
                  fontFamily: "Riot-Regular",
                  marginVertical: 2,
                  marginLeft: 20,
                }}>
                Lista de alumnos :
              </Text>
              <View style={styles.underline}/>
              <View style={styles.ListBox}>
                <FlatList
                  data = {Students}
                  renderItem={({item}) => <Inscritos_Teachers teachers={item}/>}
                  keyExtractor={item=>item.User_Id}
                />
              </View>
            </View>
        </View>
    </View>
  );
};

const styles = StyleSheet.create({
  underline:{
    backgroundColor: "white",
    height: "2%",
    width: "90%",
    marginLeft: "5%",
    marginRight: "5%",
  },
  ListBox: {
    height: "80%",
    marginLeft: "4%",
    width: "90%",
    marginVertical: 7,
    flexDirection: "column",
  },
});

export default UsuariosExistentes;
