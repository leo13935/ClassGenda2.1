import React, { useState, useEffect } from 'react';
import { View,
  StyleSheet,
  Text,
  TouchableOpacity,
  ScrollView,
} from 'react-native';
// ------------------------------- DEPENDENCIAS ---------------------------------
import { useNavigation } from '@react-navigation/native';
// ------------------------------- COMPONENTES ----------------------------
import  {ROUTES, PALETADECOLORES} from '../../components';
// ------------------------- ICONOS -----------------------------------------------------
import {
    MaterialIcons,
    MaterialCommunityIcons,
    FontAwesome,
    FontAwesome5,
    Ionicons,
  } from "@expo/vector-icons";

  
  




  const Mallas = (props) => {
    const navigation = useNavigation();
  
    const renderFaculty = (acronym, fullName, route) => (
      <TouchableOpacity style={styles.opt} onPress={() => navigation.navigate(route)}>
        <MaterialIcons name="engineering" size={40} color="#000000" style={{ padding: "3%" }} />
        <View style={{ flexDirection: "column", alignItems: "flex-start" }}>
          <Text style={styles.textopt }>{acronym}</Text>
          <Text style={styles.textCarrera}>{fullName}</Text>
        </View>
      </TouchableOpacity>
    );
  
    return (
      <View style={{ alignItems: 'center', width: 400 }}>
        <View style={styles.container}>
          <Text style={styles.textTitle}>Mallas curriculares:</Text>
          <ScrollView contentContainerStyle={styles.contopc}>
            {renderFaculty("ICOM", "Ingeniería en Computación", ROUTES.MALLA_ICOM)}
            {renderFaculty("INNI", "Ingeniería en Informática", ROUTES.MALLA_INNI)}  
            {renderFaculty("LCMA", "Licenciatura en Ciencia de Materiales", ROUTES.MALLA_LCMA)}       
            {renderFaculty("LIFI", "Licenciatura en Física", ROUTES.MALLA_LIFI)}   
            {renderFaculty("INBI", "Ingeniería Biomédica", ROUTES.MALLA_INBI)}   
            {renderFaculty("ICIV", "Ingeniería Civil", ROUTES.MALLA_ICIV)}       
            {renderFaculty("LIAB", "Ingeniería en Alimentos y Biotecnología", ROUTES.MALLA_LIAB)} 
            {renderFaculty("INCE", "Ingeniería en Comunicaciones y Electrónica", ROUTES.MALLA_INCE)} 
            {renderFaculty("Topografía", "Ingeniería Topografía Geomática", ROUTES.MALLA_TOPO)}  
            {renderFaculty("IGFO", "Ingeniería Fotónica", ROUTES.MALLA_IGFO)}
            {renderFaculty("INDU", "Ingeniería Industrial", ROUTES.MALLA_INDU)}  
            {renderFaculty("IME", "Ingeniería Mecánica Eléctrica", ROUTES.MALLA_IME)}  
            {renderFaculty("INRO", "Ingeniería Robótica", ROUTES.MALLA_INRO)}      
            {renderFaculty("Matemáticas", "Licenciatura en Matemáticas", ROUTES.MALLA_MATE)}         
            {renderFaculty("QUI", "Ingeniería Química", ROUTES.MALLA_QUI)}
            {renderFaculty("LQUI", "Licenciatura en Química", ROUTES.MALLA_LQUI)}
            {renderFaculty("QFB", "Químico Farmacéutico Biólogo", ROUTES.MALLA_QFB)}
            {renderFaculty("ILOT", "Ingeniería Logística y Transporte", ROUTES.MALLA_ILOT)}

            
            
          </ScrollView>
        </View>
      </View>
    );
  };
  
 

const styles = StyleSheet.create({
    contopc:{
        //Styles of container faculties 
        flexDirection: 'column', 
        alignItems: 'center',
        justifyContent: 'space-between',
        //padding: 3,
        //paddingBottom: 60,

    },
    textTitle:{
        //Styles of container Tittle
        fontSize: 19,
        fontFamily: 'Inter-Bold',
        marginVertical: 17,
        marginLeft: 25,
    },
    opt:{
        //Styles of buttom faculty
        backgroundColor: PALETADECOLORES.Azul,
        height: 80,
        width: 270,
        borderRadius: 20,
        borderWidth: 3,
        flexDirection:"row",
        alignItems: "center",
        marginBottom: 8,
    },
    textopt:{
        //Styles of text acronyms falcuties
        fontSize: 16,
        fontFamily: 'Lilita',
        marginLeft: 7,
        marginVertical: 1,
        marginTop: 1,
    },
    textCarrera:{
        //Styles text of complete name falcuties
        fontSize: 14.7,
        width: 209,
        flexShrink: 1,
        marginLeft: 7,
    }, 
    touchopt:{
        //Styles of touchopacity falcuties
        margin: '5%',
        flexShrink: 1,
    },

});

export default Mallas;