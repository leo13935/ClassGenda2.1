//-------Pantalla de Horarios, los usuarios pueden acceder a las clases que tienen registradas y al seleccionar una clase, se expande para que obtenga informacion adicional

// ----------------------------------------- DEPENDENCIAS ------------------------------------
import React, { useState } from "react";
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  FlatList,
  Alert,
} from "react-native";
import { useNavigation } from "@react-navigation/native";

// ----------------------------------------- ICONOS ------------------------------------
import { FontAwesome } from "@expo/vector-icons";
// ----------------------------------------- COMPONENTES ------------------------------------
import PaletaDeColores from "../../components/PaletaDeColores";

import Animated, {
  useAnimatedStyle,
  withSpring,
} from "react-native-reanimated";
import { Button } from "react-native-elements";

const scheduleData = [
  //Arreglo de objetos, se crearon como prueba para el funcionamiento de esta ventana. Falta obtener los datos de los horarios de los usuarios
  {
    day: "Lunes",
    time: "08:00 AM - 09:00 AM",
    subject: "Matemáticas",
    classroom: "101",
    build: "Edificio A",
    teacher_name: "Juan Perez",
    section: "D01",
  },
  {
    day: "Lunes",
    time: "09:00 AM - 10:00 AM",
    subject: "Historia",
    classroom: "203",
    build: "Edificio C",
    teacher_name: "Maria Gomez",
    section: "D02",
  },
  {
    day: "Martes",
    time: "10:00 AM - 11:00 AM",
    subject: "Ciencias",
    classroom: "305",
    build: "Edificio E",
    teacher_name: "Pedro Rodriguez",
    section: "D01",
  },
  {
    day: "Martes",
    time: "11:00 AM - 12:00 PM",
    subject: "Inglés",
    classroom: "102",
    build: "Edificio A",
    teacher_name: "Laura Sanchez",
    section: "D02",
  },
  {
    day: "Miércoles",
    time: "08:00 AM - 09:00 AM",
    subject: "Educación Física",
    classroom: "Gimnasio",
    build: "Edificio B",
    teacher_name: "Carlos Lopez",
    section: "D01",
  },
  {
    day: "Miércoles",
    time: "09:00 AM - 10:00 AM",
    subject: "Artes",
    classroom: "304",
    build: "Edificio E",
    teacher_name: "Ana Torres",
    section: "D02",
  },
  {
    day: "Jueves",
    time: "10:00 AM - 11:00 AM",
    subject: "Química",
    classroom: "202",
    build: "Edificio C",
    teacher_name: "Raul Ramirez",
    section: "D01",
  },
  {
    day: "Jueves",
    time: "11:00 AM - 12:00 PM",
    subject: "Geografía",
    classroom: "307",
    build: "Edificio E",
    teacher_name: "Sofia Castro",
    section: "D02",
  },
  {
    day: "Viernes",
    time: "08:00 AM - 09:00 AM",
    subject: "Biología",
    classroom: "203",
    build: "Edificio C",
    teacher_name: "Luisa Martinez",
    section: "D01",
  },
  {
    day: "Viernes",
    time: "09:00 AM - 10:00 AM",
    subject: "Matemáticas",
    classroom: "101",
    build: "Edificio A",
    teacher_name: "Juan Perez",
    section: "D02",
  },
];

const Horario = () => {
  const navigation = useNavigation();
  const [expandedIndex, setExpandedIndex] = useState(-1);

  // Funcion para la crecion de la animacion de las tarjetas desplegables
  const animatedStyles = scheduleData.map((_, index) =>
    useAnimatedStyle(() => {
      return {
        height:
          expandedIndex === index
            ? withSpring(150, { damping: 20, stiffness: 100 })
            : withSpring(0, { damping: 20, stiffness: 100 }),
        overflow: "hidden",
      };
    })
  );

  //Funcion para el manejo de la expansion de las tarjetas de informacion
  const handleActions = (index) => {
    setExpandedIndex(expandedIndex === index ? -1 : index);
  };

  //Aqui es donde se renderizan  el elemento para mandarlo a la flatList, encargada de mostrar los datos en la ventana
  const renderScheduleItem = ({ item, index }) => {
    return (
      <View style={styles.renderBox}>
        <TouchableOpacity onPress={() => handleActions(index)}>
          <View style={styles.headInfo}>
            <Text style={styles.cellDay}>{item.day}</Text>
            <Text style={styles.cell}>{item.time}</Text>
            <Text style={styles.cell}>{item.subject}</Text>
          </View>
        </TouchableOpacity>
        <View style={{ alignItems: "center" }}>
          <Animated.View style={[animatedStyles[index], styles.infoBody]}>
            <Text style={styles.cell}>{item.build}</Text>
            <Text style={styles.cell}>Salon: {item.classroom}</Text>
            <Text style={styles.cell}>Seccion: {item.section}</Text>
            <Text style={styles.cell}>Profesor: {item.teacher_name}</Text>
          </Animated.View>
        </View>
      </View>
    );
  };

  //Esto es lo que se muestra en la ventana
  return (
    <View style={styles.fondo}>
      <View style={styles.containerSchedule}>
        <Text style={styles.titleContainerSchedule}>Clases de la semana</Text>
        <View style={styles.underlineTitleSchedule} />
        <View styles={styles.flatListStyle}>
          <FlatList
            data={scheduleData}
            renderItem={renderScheduleItem}
            keyExtractor={(item, index) => index.toString()}
          />
        </View>
      </View>
    </View>
  );
};

//Estilos de todos los componentes y elementos de la ventana
const styles = StyleSheet.create({
  fondo: {
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#FFFFFF",
    flex: 1,
  },
  containerSchedule: {
    backgroundColor: PaletaDeColores.RojoMamey,
    width: "85%",
    height: "95%",
    borderRadius: 15,
    padding: 20,
  },
  titleContainerSchedule: {
    alignItems: "center",
    fontSize: 20,
    fontFamily: "Riot-Regular",
  },
  underlineTitleSchedule: {
    backgroundColor: "#FFFFFF",
    width: "100%",
    height: 3,
    marginTop: 4,
  },
  flatListStyle: {
    flex: 2,
  },
  row: {
    flexDirection: "column",
  },
  headInfo: {
    flexDirection: "row",
    justifyContent: "space-between",
    paddingVertical: 10,
  },
  infoBody: {
    borderRadius: 15,
    width: "70%",
  },
  cell: {
    flex: 1,
    textAlign: "center",
  },
  cellDay: {
    flex: 1,
    textAlign: "center",
    fontWeight: "bold",
  },
  renderBox: {
    backgroundColor: PaletaDeColores.Azul,
    width: "100%",
    borderRadius: 15,
    marginTop: 10,
    //alignItems: "center",
  },
});

export default Horario;
