//Menu de configuraciones de la aplicación.
// ------------------------------- DEPENDENCIAS ---------------------------------
import React from 'react';
import { View,
  Text,
  TouchableOpacity,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import {
  FontAwesome5,
  Entypo,
  MaterialIcons,
} from "@expo/vector-icons";
// ------------------------------- COMPONENTES ----------------------------
import  {ROUTES, PALETADECOLORES} from '../../components';

const MenuConfig = (props) => {
  return (
    <View style={{alignItems: 'center', width: 400}}>
      <TouchableOpacity         //Boton para editar perfil del usuario.
          onPress={() => props.navigation.navigate(ROUTES.EDITAR_PERFIL)} 
          style={{
            marginVertical: "10%",
            backgroundColor: PALETADECOLORES.AzulPatito,
            height: 65,
            width: 250,
            borderRadius: 20,
            borderWidth: 3,
          }}>
          <View 
              style={{    //Dirección de la posición de los botones u opciones en la configuración.
                  flexDirection: 'row', 
                  alignItems: 'center',
              }}>
              <FontAwesome5 name="user-edit" size={30} marginLeft="16%" marginTop="-1%"/>
              <Text
                  style={{
                    fontSize: 18,
                    fontFamily: 'Riot-Regular',
                    marginLeft: "11%",
                    marginVertical: 15,
                }}>
                  Editar perfil
              </Text>
          </View>
      </TouchableOpacity>
      <TouchableOpacity       //Boton para conocer las condiciones de uso de ClassGenda.
          onPress={() => props.navigation.navigate(ROUTES.CONDICIONES_USO)} 
          style={{
            marginVertical: "-4%",
            backgroundColor: PALETADECOLORES.AzulPatito,
            height: 65,
            width: 250,
            borderRadius: 20,
            borderWidth: 3,
          }}>
          <View 
              style={{    //Dirección de la posición de los botones u opciones en la configuración.
                  flexDirection: 'row', 
                  alignItems: 'center'
              }}>
              <FontAwesome5 name="atlas" size={34} marginLeft="16%" marginTop="4.5%"/>
          </View>
          <View>
            <Text
                  style={{
                    fontSize: 18,
                    fontFamily: 'Riot-Regular',
                    marginLeft: "43%",
                    marginVertical: -41,
                  }}>
                  Términos y 
            </Text>
          </View>
          <View>
              <Text
                  style={{
                      fontSize: 18,
                      fontFamily: 'Riot-Regular',
                      marginLeft: "41%",
                      marginVertical: -22,
                  }}>
                  condiciones
              </Text>
          </View>
      </TouchableOpacity>
      <TouchableOpacity       //Boton para conocer la declaración de privacidad de ClassGenda.
          onPress={() => props.navigation.navigate(ROUTES.DECLARACIONES_PRIVACIDAD)} 
          style={{
            marginVertical: "10%",
            backgroundColor: PALETADECOLORES.AzulPatito,
            height: 65,
            width: 250,
            borderRadius: 20,
            borderWidth: 3,
          }}>
          <View 
              style={{    //Dirección de la posición de los botones u opciones en la configuración.
                flexDirection: 'row', 
                alignItems: 'center'
            }}>
              <MaterialIcons name="privacy-tip" size={40} marginLeft="15%" marginTop="4%"/>
          </View>
          <View>
            <Text
                  style={{
                    fontSize: 18,
                    fontFamily: 'Riot-Regular',
                    marginLeft: "43%",
                    marginVertical: -44,
                  }}>
                  Políticas de
            </Text>
          </View>
          <View>
              <Text
                  style={{
                      fontSize: 18,
                      fontFamily: 'Riot-Regular',
                      marginLeft: "45%",
                      marginVertical: -25,
                  }}>
                  privacidad
              </Text>
          </View>
      </TouchableOpacity>
      <TouchableOpacity       //Boton para conocer acerca de ClassGenda, incluye algunas especificaciones de uso.
          onPress={() => props.navigation.navigate(ROUTES.ACERCA_DE)} 
          style={{
            marginVertical: "-4%",
            backgroundColor: PALETADECOLORES.AzulPatito,
            height: 65,
            width: 250,
            borderRadius: 20,
            borderWidth: 3,
          }}>
          <View 
              style={{    //Dirección de la posición de los botones u opciones en la configuración.
                  flexDirection: 'row', 
                  alignItems: 'center'
              }}>
              <Entypo name="info-with-circle" size={35} marginLeft="16%" marginTop="5%"/>
          </View>
          <View>
            <Text
                  style={{
                    fontSize: 18,
                    fontFamily: 'Riot-Regular',
                    marginLeft: "45%",
                    marginVertical: -33,
                  }}>
                  Acerca de
              </Text>
          </View>
      </TouchableOpacity>
    </View>
  );
};

export default MenuConfig;