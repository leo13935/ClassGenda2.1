// Pantalla para editar perfil
// --------------------------- DEPENDENCIAS ---------------------------
import React, { useState, useEffect, useRef } from 'react';
import { View,
  TextInput,
  StyleSheet,
  Text,
  TouchableOpacity,
  Image,
  ScrollView,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import {Picker as SelectPicker } from '@react-native-picker/picker';
import * as ImagePicker from 'expo-image-picker';
import LottieView from 'lottie-react-native';
// ----------------------- COMPONENTES --------------------------------
import  {IMAGENES, ROUTES, PALETADECOLORES} from '../../components';
// ------------------------- ICONOS ------------------------------------
import {
  FontAwesome,
} from "@expo/vector-icons";
// --------------------------- Backend ---------------------------
import Profile_Insert from '../../backend/Inserts/Profile_Insert';
import { useUserCode } from '../auth/UserCodeProvider';

const EditarPerfil = (props) => {

  const { userCode } = useUserCode();
  const user_id = userCode[0].User_Id;

  //Importar navigation, dado que este permite que la app se desplace entre pantallas correctamente.
  const navigation = useNavigation();

  //Valores para almacenar la imagen.
  const [image, setImage] = useState(null);

  //Valor para guardar registro.
  const [guardado, setGuardado] = useState(false);

  //Gesto que incluye el proceso para insertar la foto de perfil, así como activar la bandera de guardado.
  const  handleGuardado = () => {
    Profile_Insert(image);
    setGuardado(true);
  };

  const handleOtroUsuario = () => {
    setGuardado(false);
  };

  const pickImage = async () => {
    // No permissions request is necessary for launching the image library
    let result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.All,
      allowsEditing: true,
      aspect: [4, 3],
      quality: 1,
    });

    console.log(result.assets[0].uri);

    if (!result.canceled) {
      setImage(result.assets[0].uri);
    }
  };

  //Valores para los select pickers.
  const [rolValue, setRolValue] = useState(); //ROL.
  const pickerRefRol = useRef();

  function open() {
    pickerRefRol.current.focus();
  }

  function close() {
    pickerRefRol.current.blur();
  }
  
  //Valores para editar la información del perfil de usuario.
  const [nombreUsuario, setnombreUsuario] = useState('');
  const [apellidoUsuario, setapellidoUsuario] = useState('');
  const [emailUsuario, setemailUsuario] = useState('');
  const [passwordUsuario, setpasswordUsuario] = useState('');
  const [codigoUsuario, setcodigoUsuario] =  useState('');

  const handleLogin = () => {
    //Autentificacion para los valores para editar la información del usuario.
    console.log('Nombre:', nombreUsuario);
    console.log('Apellido:', apellidoUsuario);
    console.log('Email:', emailUsuario);
    console.log('Password:', passwordUsuario);
    console.log('Codigo:', codigoUsuario);
  };

  return (
    <ScrollView>
      <View style={{alignItems: 'center', width: 400}}>
        {!guardado ? (
          <View
            style={{    //Fondo de la pantalla en general.
              backgroundColor: 'white', 
              height: 800,
              width: 460,
              paddingTop: 100,
              alignItems: 'center',
            }}>
            <View
              style={{    // Fondo del primer bloque de datos (Nombre y apellido).
                backgroundColor: PALETADECOLORES.Azul, 
                height: 190,
                width: 350,
                paddingTop: 10,
                borderRadius: 20,
                marginVertical: -70,
                marginLeft: 10,
              }}>
              <Text
                style={{     //Titulo del primer campo - Nombre del usuario.
                  color: 'black',
                  fontSize: 15,
                  fontFamily: "Inter-Bold",
                  marginVertical: 2,
                  marginLeft: 20,
                }}>
                Nombre:
              </Text>
              <TextInput
                style={{    //Entrada para editar el nombre.
                  borderRadius: 20, color: "black", 
                  paddingHorizontal: 9, 
                  height: '22%', width: '88%', 
                  backgroundColor: 'white', 
                  marginVertical: 3,
                  borderColor: "black",
                  borderWidth: 3,
                  borderRadius: 10,
                  marginLeft: 20,
                  fontSize: 15,
                  fontFamily: "Riot-Regular",
                }}
                placeholder="Elizabeth..." onChangeText={text => setnombreUsuario(text)}
                value={nombreUsuario}
                >
              </TextInput>
              <Text
                style={{    //Titulo del segundo campo - Apellido.                            
                  color: 'black',
                  fontSize: 15,
                  fontFamily: "Inter-Bold",
                  marginVertical: 20,
                  marginLeft: 20,
                }}>
                Apellido:
              </Text>
              <TextInput
                style={{    //Entrada de edición para el apellido.
                  borderRadius: 20, color: "black", 
                  paddingHorizontal: 9, 
                  height: '22%', width: '88%', 
                  backgroundColor: 'white', 
                  marginVertical: -11,
                  borderColor: "black",
                  borderWidth: 3,
                  borderRadius: 10,
                  marginLeft: 20,
                  fontSize: 15,
                  fontFamily: "Riot-Regular",
                }}
                placeholder="Macias..." onChangeText={text => setapellidoUsuario(text)}
                value={apellidoUsuario}>
              </TextInput> 
            </View>
            <View
              style={{    // Fondo para agregar la fotografia de perfil.
                backgroundColor: PALETADECOLORES.RojoMamey, 
                height: 210,
                width: 180,
                paddingTop: 10,
                borderRadius: 20,
                marginVertical: 102,
                marginRight: "3%",
                marginLeft: "-30%",
              }}>
              <Text
                style={{    //Titulo del campo - foto de perfil.
                  color: 'black', 
                  fontSize: 15,
                  fontFamily: "Inter-Bold",
                  marginVertical: 2,
                  marginLeft: 5,
                  textAlign: 'center',
                }}>
                Foto de perfil
              </Text>
              {image &&
                <Image    //Foto de perfil del usuario (default: user.png).
                    source={{uri: image}}
                    style={{
                      height: 115,
                      width: 115,
                      borderRadius: 60,
                      marginLeft: 34,
                      marginVertical: 2,
                      borderColor: "black",
                      borderWidth: 3,
                    }}
                />
              }
              <TouchableOpacity
                onPress={pickImage}
                style={{    //Botón para seleccionar y subir la foto de perfil.
                  borderRadius: 20, color: "black", 
                  paddingHorizontal: 9, 
                  height: '20%', width: '80%', 
                  backgroundColor: 'white', 
                  marginVertical: 3,
                  borderColor: "black",
                  borderWidth: 3,
                  borderRadius: 10,
                  marginLeft: 18,

                }}
              >
                <Text
                  style={{    //Titulo del botón.
                    color: 'black',
                    fontSize: 15,
                    marginVertical: 6,
                    marginLeft: 4,
                    textAlign: 'center',
                  }}>
                    Select image
                </Text>
              </TouchableOpacity>
            </View>
            <View
              style={{    // Fondo para el código.
                backgroundColor: PALETADECOLORES.AmarilloPatito, 
                height: 90,
                width: 140,
                paddingTop: 10,
                borderRadius: 20,
                marginVertical: -314,
                marginLeft: 10,
                marginRight: "25%",
                marginLeft: "70%",
              }}>
              <Text
                style={{    //Titulo del campo - Código de estudiante/docente.
                  color: 'black',
                  fontSize: 15,
                  fontFamily: "Inter-Bold",
                  marginVertical: 1,
                  marginLeft: 43,
                }}>
                Código
              </Text>
              <TextInput
                style={{    //Campo de edición del código.
                  borderRadius: 20, color: "black", 
                  paddingHorizontal: 9, 
                  height: '50%', width: '86%', 
                  backgroundColor: 'white', 
                  marginVertical: 4,
                  borderColor: "black",
                  borderWidth: 3,
                  borderRadius: 10,
                  marginLeft: 10,
                  alignItems: 'center',
                  fontSize: 15,
                  fontFamily: "Riot-Regular",
                  textAlign: 'center'
                }}
                placeholder="217864273" onChangeText={text => setcodigoUsuario(text)}
                value={codigoUsuario}
                >
              </TextInput>
            </View>
            <View
              style={{    // Fondo para el rol.
                backgroundColor: PALETADECOLORES.AmarilloPatito, 
                height: 100,
                width: 150,
                paddingTop: 10,
                borderRadius: 20,
                marginVertical: 342,
                marginLeft: 10,
                marginRight: "25%",
                marginLeft: "70%",
              }}>
              <Text
                style={{    //Titulo del campo - Rol.
                  color: 'black',
                  fontSize: 15,
                  fontFamily: "Inter-Bold",
                  marginVertical: 0,
                  marginLeft: 59,
                }}>
                Rol
              </Text>
              <View
                style={{    //Fondo del picker para cambiar tu Rol.
                  backgroundColor: 'white', 
                  borderRadius: 10,
                  borderWidth: 3,
                  height: 50,
                  width: 130,
                  marginVertical: '2%',
                  marginLeft: '7%',
                }}
              >
                <SelectPicker     //Estatus picker.
                  ref={pickerRefRol}
                  style={{
                    marginVertical: '-3%',
                    marginLeft: '-9%',
                  }}
                  selectedValue={rolValue}
                  onValueChange={
                    (itemValue, itemIndex) => setRolValue(itemValue)
                  }
                >
                  <SelectPicker.Item //Default label.
                    label='Select'
                    enabled={false} 
                  />
                  <SelectPicker.Item 
                    label="Alumno" 
                    value="alumno" 
                  />
                  <SelectPicker.Item 
                    label="Profesor" 
                    value="profesor"
                  />
                </SelectPicker>
              </View>
            </View>
            <View
              style={{    // Fondo para el campo de datos de contraseña.
                backgroundColor: PALETADECOLORES.Azul, 
                height: 190,
                width: 350,
                paddingTop: 10,
                borderRadius: 20,
                marginVertical: -314,
                marginLeft: 10,
              }}>
              <Text
                style={{         //Titulo del campo - Email.
                  color: 'black',
                  fontSize: 15,
                  fontFamily: "Inter-Bold",
                  marginVertical: 2,
                  marginLeft: 20,
                }}>
                Email:
              </Text>
              <TextInput
                style={{    //Campo de edición del email.
                  borderRadius: 20, color: "black",
                  paddingHorizontal: 9, 
                  height: '22%', width: '88%', 
                  backgroundColor: 'white', 
                  marginVertical: 3,
                  borderColor: "black",
                  borderWidth: 3,
                  borderRadius: 10,
                  marginLeft: 20,
                  fontSize: 15,
                  fontFamily: "Riot-Regular",
                }}
                placeholder="Hey@alumnos.udg.mx" onChangeText={text => setemailUsuario(text)}
                value={emailUsuario}
                >
              </TextInput>
              <Text                           
                style={{    //Titulo del campo - Password.
                  color: 'black',
                  fontSize: 15,
                  fontFamily: "Inter-Bold",
                  marginVertical: 20,
                  marginLeft: 20,
                }}>
                Password:
              </Text>
              <TextInput
                style={{    //Campo de edición del password.
                  borderRadius: 20, color: "black", 
                  paddingHorizontal: 9, 
                  height: '22%', width: '88%', 
                  backgroundColor: 'white', 
                  marginVertical: -11,
                  borderColor: "black",
                  borderWidth: 3,
                  borderRadius: 10,
                  marginLeft: 20,
                  fontFamily: "Riot-Regular",
                  fontSize: 15,
                }}
                placeholder="************" onChangeText={text => setpasswordUsuario(text)}
                value={passwordUsuario}
                secureTextEntry={true}
                >
              </TextInput>
            </View>
            <TouchableOpacity   //Botón guardar los cambios (se tiene una condición).
              onPress={handleGuardado}
              style={styles.buttonGuardar}>        
              <Text style={styles.buttonTextGuardar}>Guardar</Text>
            </TouchableOpacity>  
            <TouchableOpacity   //Botón cancelar edición.
              onPress={() => props.navigation.navigate(ROUTES.MENU_CONFIG)}
              style={styles.buttonCancelar}>        
              <Text style={styles.buttonTextCancelar}>Cancelar</Text>
            </TouchableOpacity> 
          </View>
        ) : ( //Pantalla una vez se da clic en el bótón 'guardar'.
          <View style={{alignItems: 'center', width: 400, height: 800}}>
            <Text 
              style={{
                marginVertical: "20%", 
                fontSize: 25, 
                fontFamily: 'Riot-Regular',
                textAlign: 'center', 
                }}
            > 
              ¡Usuario editado!
            </Text>
            <LottieView   //Animación.
              source={IMAGENES.Done}
              autoPlay
              loop={true}
              style={{
                  flexGrow: 1,
                  marginVertical: "-20%",
                  top: -15,
                  marginLeft: '-14%',
                  width: 1000,
                  height: 500,
              }}
            />
            <TouchableOpacity //Boton que te regresa a la pantalla principal.
              onPressIn={() => props.navigation.navigate(ROUTES.PAGINA_PRINCIPAL)}
              onPressOut={handleOtroUsuario}  //Aquí se cambia el estado.
              style={{
                backgroundColor: PALETADECOLORES.RojoMamey,
                borderRadius: 30,
                borderColor: "black",
                marginVertical: "-2%",
                marginBottom: '20%',
                marginLeft: "3%",
                marginRight: "-30%",
                width: 190,
                height: 70,
                borderRadius: 50,
                borderWidth: 3,
              }}>
              <Text 
                style={{
                  color: "black",
                  fontFamily: "Inter-Bold",
                  fontSize: 17,
                  marginTop: "10%",
                  marginLeft: "45%"}}
              >
                Regresar
              </Text>
              <FontAwesome 
                  style={{
                    marginTop: "-21%",
                    marginLeft: "10%",
                  }}
                  name="arrow-circle-left" 
                  size={55} 
                  color="black" 
                />
            </TouchableOpacity>
          </View>         
        )}
      </View>
    </ScrollView>
  );
};


const styles = StyleSheet.create({
  input: {    //Estilo de las entradas o campos de ingreso de datos.
    width: '77%',
    height: "8%",
    borderRadius: 10,
    marginLeft: "20%",
  },
  buttonTextGuardar: {  //Estilo y diseño de los botones a partir de aquí.
    color: "black",
    fontFamily: "Inter-Bold",
    fontSize: 17,
    marginTop: "0%",
    marginLeft: "18%",
  },
  buttonTextCancelar: {
    color: "black",
    fontFamily: "Inter-Bold",
    fontSize: 17,
    marginTop: "4%",
    marginLeft: "14%",
  },
  buttonGuardar: {
    backgroundColor: PALETADECOLORES.AmarilloPatito,
    borderRadius: 30,
    borderColor: "black",
    marginVertical: "75%",
    marginRight: "3%",
    marginLeft: "-24%",
    width: 110,
    height: 40,
    borderRadius: 50,
    paddingVertical: 5, 
    borderWidth: 3,
  },
  buttonCancelar: {
    backgroundColor: PALETADECOLORES.RojoMamey,
    borderRadius: 30,
    borderColor: "black",
    marginVertical: "-83.5%",
    marginRight: "-30%",
    marginLeft: "3%",
    width: 110,
    height: 40,
    borderRadius: 50,
    borderWidth: 3,
  },
});

export default EditarPerfil;