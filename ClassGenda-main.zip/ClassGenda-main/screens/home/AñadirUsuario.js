// Pantalla de añadir usuarios.
// --------------------------- DEPENDENCIAS ------------------------------------
import React, { useState, useEffect, useRef } from 'react';
import { View,
  TextInput,
  StyleSheet,
  Text,
  TouchableOpacity,
  Image,
  ScrollView,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import {Picker as SelectPicker } from '@react-native-picker/picker';
import * as ImagePicker from 'expo-image-picker';
import LottieView from 'lottie-react-native';
// ----------------------- COMPONENTES --------------------------------
import  {IMAGENES, ROUTES, PALETADECOLORES} from '../../components';
// ------------------------- ICONOS -----------------------------------------------------
import {
  MaterialIcons,
  FontAwesome,
} from "@expo/vector-icons";
// --------------------------- BACKEND ------------------------------------
//import Profile_Insert from '../../backend/Inserts/Profile_Insert';
import { useUserCode } from '../auth/UserCodeProvider';
// --------------------------- SUPABASE ------------------------------------
import { supabase } from '../../lib/supabase';

const AñadirUsuario = (props) => {

  const { userCode } = useUserCode();
  const user_id = userCode[0].User_Id;
  
  //Importar navigation, dado que este permite que la app se desplace entre pantallas correctamente.
  const navigation = useNavigation();

  //Valores para agregar la foto de perfil del usuario nuevo y para guardarlo.
  const [image, setImage] = useState(null);
  const [guardado, setGuardado] = useState(false);

  //Función para agregar la foto al perfil del usuario.
  async function Profile_Insert(user_id, image) {
    console.log("CODIGO DEL USUARIO: ", user_id);
    const { data, error } = await supabase.storage
      .from('avatars')
      .upload(`profile_${user_id}`, image);
    if (error) {
      console.error('Error al subir la foto de perfil:', error);
    } else {
      console.log('La foto de perfil se ha subido con éxito', data);
    }
    return null;
  }

  //Gesto para guardar la imagen del usuario como fotografía del perfil.
  const handleGuardado = () => {
    if (image) {
      Profile_Insert(user_id, image);
      setGuardado(true);
    } else {
      console.error('La variable image es nula o indefinida');
    }
  };

  //Valores al momento de haber guardado: añadir otro usuario y regresar a pantalla principal.
  const handleOtroUsuario = () => {
    setGuardado(false);
  };

  const pickImage = async () => {
    // No permissions request is necessary for launching the image library
    let result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.All,
      allowsEditing: true,
      aspect: [4, 3],
      quality: 1,
    });

    console.log(result.assets[0].uri);

    if (!result.canceled) {
      setImage(result.assets[0].uri);
    }
  };

  //Valores para los select pickers.
  const [rolValue, setRolValue] = useState(); //ROL.
  const pickerRefRol = useRef();

  function open() {
    pickerRefRol.current.focus();
  }

  function close() {
    pickerRefRol.current.blur();
  }
  //Valores para añadir un nuevo usuario.
  const [nombreUsuario, setnombreUsuario] = useState('');
  const [apellidoUsuario, setapellidoUsuario] = useState('');
  const [emailUsuario, setemailUsuario] = useState('');
  const [passwordUsuario, setpasswordUsuario] = useState('');
  const [codigoUsuario, setcodigoUsuario] =  useState('');

  const handleLogin = () => {
    //Autentificacion para los valores de añadir usuario.
    console.log('Nombre:', nombreUsuario);
    console.log('Apellido:', apellidoUsuario);
    console.log('Email:', emailUsuario);
    console.log('Password:', passwordUsuario);
    console.log('Codigo:', codigoUsuario);
  };

  return (
    <ScrollView>
      <View style={{alignItems: 'center', width: 400}}>
        {!guardado ? (
          <View
            style={{
              backgroundColor: 'white', //Fondo de la pantalla en general.
              height: 800,
              width: 460,
              paddingTop: 100,
              alignItems: 'center',
            }}>
            <View
              style={{                // Fondo del primer bloque de datos (Nombre y apellido).
                backgroundColor: PALETADECOLORES.Azul, 
                height: 190,
                width: 350,
                paddingTop: 10,
                borderRadius: 20,
                marginVertical: -70,
                marginLeft: 10,
              }}>
              <Text
                style={{                 //Titulo del primer campo.
                  color: 'black',
                  fontSize: 15,
                  fontFamily: "Inter-Bold",
                  marginVertical: 2,
                  marginLeft: 20,
                }}>
                Nombre:
              </Text>
              <TextInput
                style={{                //Primer campo de ingreso - nombre.
                  borderRadius: 20, color: "black", 
                  paddingHorizontal: 9, 
                  height: '23%', width: '88%', 
                  backgroundColor: 'white', 
                  marginVertical: 3,
                  borderColor: "black",
                  borderWidth: 3,
                  borderRadius: 10,
                  marginLeft: 20,
                  fontFamily: "Riot-Regular",
                  fontSize: 16,
                }}
                placeholder="Elizabeth..." onChangeText={text => setnombreUsuario(text)}
                value={nombreUsuario}
                >
              </TextInput>
              <Text
                style={{                  //Titulo del segundo campo.
                  color: 'black',
                  fontSize: 15,
                  fontFamily: "Inter-Bold",
                  marginVertical: 19,
                  marginLeft: 20,
                }}>
                Apellido:
              </Text>
              <TextInput
                style={{                  //Segundo campo de ingreso - apellido.
                  borderRadius: 20, color: "black", 
                  paddingHorizontal: 9, 
                  height: '23%', width: '88%', 
                  backgroundColor: 'white', 
                  marginVertical: -14,
                  borderColor: "black",
                  borderWidth: 3,
                  borderRadius: 10,
                  marginLeft: 20,
                  fontFamily: "Riot-Regular",
                  fontSize: 16,
                }}
                placeholder="Macias..." onChangeText={text => setapellidoUsuario(text)}
                value={apellidoUsuario}>
              </TextInput> 
            </View>
            <View
              style={{                    // Fondo para la fotografia.
                backgroundColor: PALETADECOLORES.RojoMamey, 
                height: 210,
                width: 180,
                paddingTop: 10,
                borderRadius: 20,
                marginVertical: 102,
                marginRight: "3%",
                marginLeft: "-30%",
              }}>
              <Text
                style={{                  //Titulo del campo - foto de perfil.
                  color: 'black', 
                  fontSize: 15,
                  fontFamily: "Inter-Bold",
                  marginVertical: 2,
                  marginLeft: 5,
                  textAlign: 'center',
                }}>
                Foto de perfil
              </Text>
              {image &&
                <Image             //Foto de perfil del usuario (default: user.png).
                    source={{uri: image}}
                    style={{
                      height: 115,
                      width: 115,
                      borderRadius: 60,
                      marginLeft: 34,
                      marginVertical: 2,
                      borderColor: "black",
                      borderWidth: 3,
                    }}
                />
              }
              <TouchableOpacity
                onPress={pickImage}
                style={{                    //Campo de ingreso - Título.
                  borderRadius: 20, color: "black", 
                  paddingHorizontal: 9, 
                  height: '20%', width: '80%', 
                  backgroundColor: 'white', 
                  marginVertical: 3,
                  borderColor: "black",
                  borderWidth: 3,
                  borderRadius: 10,
                  marginLeft: 18,

                }}
              >
                <Text           
                  style={{              //seleccionar imagen.          
                    color: 'black',
                    fontSize: 15,
                    marginVertical: 6,
                    marginLeft: 4,
                    textAlign: 'center',
                  }}>
                    Select image
                </Text>
              </TouchableOpacity>
            </View>
            <View
              style={{                    // Fondo para el código.
                backgroundColor: PALETADECOLORES.AmarilloPatito, 
                height: 90,
                width: 140,
                paddingTop: 10,
                borderRadius: 20,
                marginVertical: -314,
                marginLeft: 10,
                marginRight: "25%",
                marginLeft: "70%",
              }}>
              <Text
                style={{                //Titulo del campo.
                  color: 'black',
                  fontSize: 15,
                  fontFamily: "Inter-Bold",
                  marginVertical: 1,
                  marginLeft: 43,
                }}>
                Código
              </Text>
              <TextInput
                style={{                    //Campo de ingreso - Código.
                  borderRadius: 20, color: "black", 
                  paddingHorizontal: 9, 
                  height: '50%', width: '86%', 
                  backgroundColor: 'white', 
                  marginVertical: 4,
                  borderColor: "black",
                  borderWidth: 3,
                  borderRadius: 10,
                  marginLeft: 10,
                  alignItems: 'center',
                  fontFamily: "Riot-Regular",
                  fontSize: 16,
                  textAlign: 'center'
                }}
                placeholder="217864273" onChangeText={text => setcodigoUsuario(text)}
                value={codigoUsuario}
                >
              </TextInput>
            </View>
            <View
              style={{                // Fondo para el rol.
                backgroundColor: PALETADECOLORES.AmarilloPatito, 
                height: 100,
                width: 150,
                paddingTop: 10,
                borderRadius: 20,
                marginVertical: 342,
                marginLeft: 10,
                marginRight: "25%",
                marginLeft: "70%",
              }}>
              <Text
                style={{             //Titulo del campo.
                  color: 'black',
                  fontSize: 15,
                  fontFamily: "Inter-Bold",
                  marginVertical: 0,
                  marginLeft: 59,
                }}>
                Rol
              </Text>
              <View
                style={{
                  backgroundColor: 'white', //Fondo del picker.
                  borderRadius: 10,
                  borderWidth: 3,
                  height: 50,
                  width: 130,
                  marginVertical: '2%',
                  marginLeft: '7%',
                }}
              >
                <SelectPicker               //Estatus picker.
                  ref={pickerRefRol}
                  style={{
                    marginVertical: '-3%',
                    marginLeft: '-9%',
                  }}
                  selectedValue={rolValue}
                  onValueChange={
                    (itemValue, itemIndex) => setRolValue(itemValue)
                  }
                >
                  <SelectPicker.Item        //Default label.
                    label='Select'
                    enabled={false} 
                  />
                  <SelectPicker.Item 
                    label="Alumno" 
                    value="alumno" 
                  />
                  <SelectPicker.Item 
                    label="Profesor" 
                    value="profesor"
                  />
                </SelectPicker>
              </View>
            </View>
            <View
              style={{                    // Fondo para el campo de datos de contraseña.
                backgroundColor: PALETADECOLORES.Azul, 
                height: 190,
                width: 350,
                paddingTop: 10,
                borderRadius: 20,
                marginVertical: -314,
                marginLeft: 10,
              }}>
              <Text                       //Titulo del campo - Email.
                style={{
                  color: 'black',
                  fontSize: 15,
                  fontFamily: "Inter-Bold",
                  marginVertical: 2,
                  marginLeft: 20,
                }}>
                Email:
              </Text>
              <TextInput
                style={{                  //Primer campo de ingreso - Email.
                  borderRadius: 20, color: "black", 
                  paddingHorizontal: 9, 
                  height: '23%', width: '88%', 
                  backgroundColor: 'white', 
                  marginVertical: 3,
                  borderColor: "black",
                  borderWidth: 3,
                  borderRadius: 10,
                  marginLeft: 20,
                  fontFamily: "Riot-Regular",
                  fontSize: 16,
                }}
                placeholder="Hey@alumnos.udg.mx" onChangeText={text => setemailUsuario(text)}
                value={emailUsuario}
                >
              </TextInput>
              <Text                           //Titulo del campo - Password.
                style={{
                  color: 'black',
                  fontSize: 15,
                  fontFamily: "Inter-Bold",
                  marginVertical: 20,
                  marginLeft: 20,
                }}>
                Password:
              </Text>
              <TextInput
                style={{                      //Segundo campo de ingreso - Password.
                  borderRadius: 20, color: "black", 
                  paddingHorizontal: 9, 
                  height: '23%', width: '88%', 
                  backgroundColor: 'white', 
                  marginVertical: -13,
                  borderColor: "black",
                  borderWidth: 3,
                  borderRadius: 10,
                  marginLeft: 20,
                  fontFamily: "Riot-Regular",
                  fontSize: 16,
                }}
                placeholder="************" onChangeText={text => setpasswordUsuario(text)}
                value={passwordUsuario}
                secureTextEntry={true}
                >
              </TextInput>
            </View>
            <TouchableOpacity              //Botón para guardar el usuario registrado.
              onPress={handleGuardado}
              style={styles.buttonGuardar}>        
              <Text style={styles.buttonTextGuardar}>Guardar</Text>
            </TouchableOpacity>  
            <TouchableOpacity
              onPress={() => props.navigation.navigate(ROUTES.PAGINA_PRINCIPAL)}
              style={styles.buttonCancelar}>        
              <Text style={styles.buttonTextCancelar}>Cancelar</Text>
            </TouchableOpacity> 
          </View>
        ) : ( //Pantalla una vez se da clic en el bótón 'guardar'.
          <View style={{alignItems: 'center', width: 400, height: 800}}>
            <Text 
              style={{
                marginVertical: "20%", 
                fontSize: 25, 
                fontFamily: 'Inter-Bold',
                textAlign: 'center', 
                }}
            > 
              ¡Usuario guardado!
            </Text>
            <LottieView
              source={IMAGENES.Done}
              autoPlay
              loop={true}
              style={{
                  flexGrow: 1,
                  marginVertical: "-20%",
                  marginLeft: '-13%',
                  width: 1000,
                  height: 500,
              }}
            />
            <TouchableOpacity                 //Boton para agregar otro usuario.
              onPressIn={() => props.navigation.navigate(ROUTES.AÑADIR_USUARIO)}
              onPressOut={handleOtroUsuario}  //Aquí se cambia el estado.
              style={{
                backgroundColor: PALETADECOLORES.AmarilloPatito,
                borderRadius: 30,
                borderColor: "black",
                marginVertical: "15%",
                marginRight: "-30%",
                marginLeft: "3%",
                width: 190,
                marginBottom: '20%',
                height: 70,
                borderRadius: 50,
                borderWidth: 3,
              }}>
              <Text 
                style={{
                  color: "black",
                  fontFamily: "Riot-Regular",
                  fontSize: 17,
                  marginTop: "5%",
                  marginLeft: "39%"}}
              >
                Añadir otro
              </Text>
              <Text 
                style={{
                  color: "black",
                  fontFamily: "Riot-Regular",
                  fontSize: 17,
                  marginTop: "-1%",
                  marginLeft: "48%"}}
              >
                usuario
              </Text>
              <MaterialIcons 
                  style={{
                    marginTop: "-27%",
                    marginLeft: "6%",
                  }}
                  name="group-add" 
                  size={55} 
                  color="black" 
                />
            </TouchableOpacity>
            <TouchableOpacity                 //Boton que te regresa a la pantalla principal.
              onPressIn={() => props.navigation.navigate(ROUTES.PAGINA_PRINCIPAL)}
              onPressOut={handleOtroUsuario}  //Aquí se cambia el estado.
              style={{
                backgroundColor: PALETADECOLORES.RojoMamey,
                borderRadius: 30,
                borderColor: "black",
                marginVertical: "-12%",
                marginBottom: '20%',
                marginLeft: "3%",
                marginRight: "-30%",
                width: 190,
                height: 70,
                borderRadius: 50,
                borderWidth: 3,
              }}>
              <Text 
                style={{
                  color: "black",
                  fontFamily: "Inter-Bold",
                  fontSize: 17,
                  marginTop: "10%",
                  marginLeft: "45%"}}
              >
                Regresar
              </Text>
              <FontAwesome 
                  style={{
                    marginTop: "-21%",
                    marginLeft: "10%",
                  }}
                  name="arrow-circle-left" 
                  size={55} 
                  color="black" 
                />
            </TouchableOpacity>
          </View>         
        )}
      </View>
    </ScrollView>
  );
};


const styles = StyleSheet.create({
  input: {
    width: '77%',
    height: "8%",
    borderRadius: 10,
    marginLeft: "20%",
  },
  buttonTextGuardar: {
    color: "black",
    fontFamily: "Inter-Bold",
    fontSize: 17,
    marginTop: "0%",
    marginLeft: "18%",
  },
  buttonTextCancelar: {
    color: "black",
    fontFamily: "Inter-Bold",
    fontSize: 17,
    marginTop: "4%",
    marginLeft: "14%",
  },
  buttonGuardar: {
    backgroundColor: PALETADECOLORES.AmarilloPatito,
    borderRadius: 30,
    borderColor: "black",
    marginVertical: "75%",
    marginRight: "3%",
    marginLeft: "-24%",
    width: 110,
    height: 40,
    borderRadius: 50,
    paddingVertical: 5, 
    borderWidth: 3,
  },
  buttonCancelar: {
    backgroundColor: PALETADECOLORES.RojoMamey,
    borderRadius: 30,
    borderColor: "black",
    marginVertical: "-83.5%",
    marginRight: "-30%",
    marginLeft: "3%",
    width: 110,
    height: 40,
    borderRadius: 50,
    borderWidth: 3,
  },
});

export default AñadirUsuario;