//Pantalla de "Acerca de" ClassGenda.
// --------------------------- DEPENDENCIAS ---------------------------
import React from 'react';
import { 
  View,
  Text,
  TouchableOpacity,
  ScrollView,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
// ----------------------- COMPONENTES --------------------------------
import  { ROUTES, PALETADECOLORES} from '../../components';
// ----------------------- ICONOS ------------------------------------
import {
    FontAwesome,
  } from "@expo/vector-icons";

const AcercaDe = () => {

    //Importar navigation, dado que este permite que la app se desplace entre pantallas correctamente.
    const navigation = useNavigation();

    // Información acerca de ClassGenda, incluso se explican algunas pestañas (Alt + Z para ajustar el texto y que sea legible a la vista).
    const inicio = "ClassGenda está pensada y diseñada para ser la herramienta que facilite la generación y obtención de evidencia de tus cursos.";
    const inicio2 = "Ya sea una asignatura o una clase, ClassGenda te permite aplicar un seguimiento adecuado y conciso tanto como para lograr validar, como para mantener actualizado ya sea a tus alumnos o supervisores sobre lo que se está impartiendo. Nuestros principales objetivos son los siguientes:";

    const TituloTermino1 = "Objetivo 1";
    const TituloTermino2 = "Objetivo 2";

    const Termino1 = "Facilitar la creación y obtención de evidencia de clases para docentes y alumnos.";
    const Termino2 = "Brindar una herramienta óptima para el  seguimiento de clases.";

    const ExplicacionTitulo = "Más información:";

    const Explicacion1 = "Dashboard";
    const Explicacion1_1 = "La página principal muestra una tabla de asignaturas creadas, dentro de ella puedes encontrar el nombre, la descripción y un icono de acción que te permitirá ver, editar y eliminar tus asignaturas. Además de ello aparece contadores por asignaturas y clases totales.";

    const Explicacion2 = "Ver asignatura"
    const Explicacion2_1 = "En caso de haber seleccionado la opción de ver asignatura, podrás acceder a la página con la información detallada de dicha asignatura (esto incluye además, las fechas de inicio y termino, así como los alumnos inscritos y la lista de clases que engloban el curso, en ella podrás encontrar su estatus, el nombre, descripción y un icono de acción (dicho icono te permitirá editar o eliminar la clase seleccionada). Además de esto, podrás añadir clases nuevas cada que sea necesario crearlas.";

    const final = "De parte del equipo de ClassGenda, agradecemos su preferencia.";

  return (
      <View style={{alignItems: 'center', width: 400}}>
          <View
              style={{
                  backgroundColor: 'white', //Fondo de la pantalla en general.
                  height: 800,
                  width: 460,
                  alignItems: 'center',
                }}> 
              
              <View             // FONDO CUADRO UNO.
                  style={{
                      backgroundColor: PALETADECOLORES.AmarilloPatito, 
                      height: 600,
                      width: 350,
                      borderRadius: 20,
                      marginVertical: 50,
                      marginLeft: 10,
                  }}>
                  <Text         // Titulo del bloque.
                      style={{
                          fontFamily: "Inter-Extra-Bold",
                          fontSize: 20,
                          width: "80%",
                          height: "60%",
                          marginLeft: "32%",
                          marginVertical: "2%",
                      }}
                  >
                      ClassGenda
                  </Text>
                  <View
                      style={{
                          backgroundColor: "white", //Linea de adorno.
                          height: "1.2%",
                          width: "90%",
                          marginLeft: "5%",
                          marginVertical: "-94%",
                          marginRight: "5%",
                      }}
                  >
                  </View>
                  <View             // FONDO INTERIOR - contraste con el principal.
                      style={{
                          backgroundColor: PALETADECOLORES.AmarilloDeslavado,
                          height: 510,
                          width: 330,
                          borderRadius: 10,
                          marginVertical: 345,
                          marginLeft: 10,
                      }}
                  >
                      <ScrollView>
                      <Text             // Primer bloque de información.
                          style={{
                              fontFamily: "Inter-Regular",
                              fontSize: 15,
                              color: "black",
                              marginLeft: "5%",
                              marginRight: "5%",
                              marginVertical: "0%",
                              textAlign: "justify",
                          }}
                      >
                          {inicio}
                          {"\n"}
                          {"\n"}
                          {inicio2}
                      </Text>
                      <Text         // Titulo del primer objetivo.
                          style={{
                              fontFamily: "Inter-Bold",
                              fontSize: 15,
                              color: "black",
                              marginLeft: "5%",
                              marginRight: "5%",
                              marginVertical: "0%",
                              textAlign: "justify",
                          }}
                      >
                          {"\n"}
                          {"\n"}
                          {TituloTermino1}
                      </Text>
                      <Text         // Información del primer objetivo.
                          style={{
                              fontFamily: "Inter-Regular",
                              fontSize: 15,
                              color: "black",
                              marginLeft: "5%",
                              marginRight: "5%",
                              marginVertical: "0%",
                              textAlign: "justify",
                          }}
                      >
                          {Termino1}
                      </Text>
                      <Text             // Titulo del segundo objetivo.
                          style={{
                              fontFamily: "Inter-Bold",
                              fontSize: 15,
                              color: "black",
                              marginLeft: "5%",
                              marginRight: "5%",
                              marginVertical: "0%",
                              textAlign: "justify",
                          }}
                      >
                          {"\n"}
                          {TituloTermino2}
                      </Text>
                      <Text         // Información del segundo objetivo.
                          style={{
                              fontFamily: "Inter-Regular",
                              fontSize: 15,
                              color: "black",
                              marginLeft: "5%",
                              marginRight: "5%",
                              marginVertical: "0%",
                              textAlign: "justify",
                          }}
                      >
                          {Termino2}
                      </Text>
                      <Text
                          style={{
                              fontFamily: "Inter-Bold",
                              fontSize: 15,
                              color: "black",
                              marginLeft: "5%",
                              marginRight: "5%",
                              marginVertical: "0%",
                              textAlign: "center",
                          }}
                      >
                          {"\n"}
                          {"\n"}
                          {"\n"}
                          {ExplicacionTitulo}
                      </Text>
                      <Text
                          style={{
                              fontFamily: "Inter-Bold",
                              fontSize: 15,
                              color: "black",
                              marginLeft: "5%",
                              marginRight: "5%",
                              marginVertical: "0%",
                              textAlign: "justify",
                          }}
                      >
                        {"\n"}
                          {Explicacion1}
                      </Text>
                      <Text
                          style={{
                              fontFamily: "Inter-Regular",
                              fontSize: 15,
                              color: "black",
                              marginLeft: "5%",
                              marginRight: "5%",
                              marginVertical: "0%",
                              textAlign: "justify",
                          }}
                      >
                          {Explicacion1_1}
                      </Text>
                      <Text
                          style={{
                              fontFamily: "Inter-Bold",
                              fontSize: 15,
                              color: "black",
                              marginLeft: "5%",
                              marginRight: "5%",
                              marginVertical: "0%",
                              textAlign: "justify",
                          }}
                      >
                        {"\n"}
                          {Explicacion2}
                      </Text>
                      <Text
                          style={{
                              fontFamily: "Inter-Regular",
                              fontSize: 15,
                              color: "black",
                              marginLeft: "5%",
                              marginRight: "5%",
                              marginVertical: "0%",
                              textAlign: "justify",
                          }}
                      >
                          {Explicacion2_1}
                      </Text>
                      <Text
                          style={{
                              fontFamily: "Inter-Bold",
                              fontSize: 15,
                              color: "black",
                              marginLeft: "6%",
                              marginRight: "6%",
                              marginVertical: "0%",
                              textAlign: "center",
                          }}
                      >
                          {"\n"}
                          {"\n"}
                          {final}
                          {"\n"}
                      </Text>
                      </ScrollView>
                  </View>
              </View>
          </View>
          <TouchableOpacity         // Botón para regresar al menpu de la configuración.
            onPressIn={() => navigation.navigate(ROUTES.MENU_CONFIG)}
            style={{
              backgroundColor: PALETADECOLORES.AmarilloPatito,
              borderRadius: 30,
              marginVertical: "-30%",
              marginBottom: '20%',
              marginLeft: "3%",
              marginRight: "-30%",
              width: 190,
              height: 70,
              borderRadius: 50,
            }}>
            <Text 
              style={{
                color: "black",
                fontFamily: "Inter-Bold",
                fontSize: 17,
                marginTop: "12%",
                marginLeft: "45%"}}
            >
              Regresar
            </Text>
            <FontAwesome 
                style={{
                  marginTop: "-21%",
                  marginLeft: "10%",
                }}
                name="arrow-circle-left" 
                size={55} 
                color="black" 
              />
          </TouchableOpacity> 
      </View>
    );
};

export default AcercaDe;