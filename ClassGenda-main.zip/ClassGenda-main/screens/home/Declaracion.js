//Pantalla para la politicas de privacidad de ClassGenda.
// --------------------------- DEPENDENCIAS ---------------------------
import React, { useState, useEffect, useRef } from 'react';
import { View,
  Text,
  TouchableOpacity,
  ScrollView,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
// ----------------------- COMPONENTES --------------------------------
import  {IMAGENES, ROUTES, PALETADECOLORES} from '../../components';
// --------------------------- ICONOS ---------------------------
import {
    FontAwesome,
  } from "@expo/vector-icons";

const Declaracion = () => {

    //Importar navigation, dado que este permite que la app se desplace entre pantallas correctamente.
    const navigation = useNavigation();

    // Información de las declaración de privacidad de ClassGenda (Alt + Z para ajustar el texto y que sea legible a la vista).
    const inicio = "El objetivo de esta política de privacidad es informarte sobre qué datos se recolectan, el por qué lo hacemos y cómo puedes actualizar, gestionar o eliminar tu información.";
    const TituloTermino1 = "¿Qué datos se obtienen?";
    const TituloTermino2 = "Motivo de la recolección de datos:";
    const TituloTermino3 = "¿Cómo actualizar tus datos?";

    const Termino1 = "ClassGenda solicita que ingreses información tal como nombre, apellido, código de estudiante y una fotografía como identificación (la cual podría ser opcional), además de ello, lo demás se relaciona con datos meramente propios de tus clases y asignaturas.";
    
    const Termino2 = "Para cumplir con nuestro objetivo es necesario que brindes la información verídica y válida de modo que las evidencias sean completas y exactas para tus profesores o dependencias a cargo. ClassGenda no pretende obtener más información tuya más que la necesaria para brindarte un espacio que funcione como organizador, agenda y una plataforma que mantenga actualizadas tus clases.";

    const Termino3_1 = "- Si eres alumno puedes editar tu información de usuario (perfil) ingresando en el menú lateral a la opción Configuración > Editar perfil. Donde puedes editar cualquiera de tus datos tales como el nombre, foto de perfil, contraseña, etc.";
    const Termino3_2 = "- Si eres profesor, por otro lado puedes editar además de tu perfil (Configuración > Editar perfil), la información de tus asignaturas a partir del Dashboard > Acción (toca el ícono de acción y se desplegarán tres opciones: ver asignatura, eliminar y editar).";
 
    const final = "Es importante y esencial que comprendas estas políticas, dado que al utilizar nuestros servicios implica que estas de acuerdo con ello y las aceptas.";

    return (
        <View style={{alignItems: 'center', width: 400}}>
            <View
                style={{
                    backgroundColor: 'white', //Fondo de la pantalla en general.
                    height: 800,
                    width: 460,
                    alignItems: 'center',
                  }}> 
                
                <View
                    style={{
                        backgroundColor: PALETADECOLORES.RojoMamey, // Fondo principal.
                        height: 600,
                        width: 350,
                        borderRadius: 20,
                        marginVertical: 50,
                        marginLeft: 10,
                    }}>
                    <Text 
                        style={{                            //Titulo.
                            fontFamily: "Inter-Extra-Bold",
                            fontSize: 20,
                            width: "80%",
                            height: "60%",
                            marginLeft: "22%",
                            marginVertical: "2%",
                        }}
                    >
                        Políticas del servicio
                    </Text>
                    <View
                        style={{
                            backgroundColor: "white", //Linea de adorno.
                            height: "1.2%",
                            width: "90%",
                            marginLeft: "5%",
                            marginVertical: "-94%",
                            marginRight: "5%",
                        }}
                    >
                    </View>
                    <View
                        style={{
                            backgroundColor: PALETADECOLORES.RosaMamey, // Fondo del texto general. 
                            height: 510,
                            width: 330,
                            borderRadius: 10,
                            marginVertical: 345,
                            marginLeft: 10,
                        }}
                    >
                        <ScrollView>
                        <Text
                            style={{
                                fontFamily: "Inter-Regular",
                                fontSize: 15,
                                color: "black",
                                marginLeft: "5%",
                                marginRight: "5%",
                                marginVertical: "0%",
                                textAlign: "justify",
                            }}
                        >
                            {inicio}
                            {"\n"}
                        </Text>
                        <Text
                            style={{
                                fontFamily: "Inter-Bold",
                                fontSize: 15,
                                color: "black",
                                marginLeft: "5%",
                                marginRight: "5%",
                                marginVertical: "0%",
                                textAlign: "justify",
                            }}
                        >
                            {"\n"}
                            {TituloTermino1}
                        </Text>
                        <Text
                            style={{
                                fontFamily: "Inter-Regular",
                                fontSize: 15,
                                color: "black",
                                marginLeft: "5%",
                                marginRight: "5%",
                                marginVertical: "0%",
                                textAlign: "justify",
                            }}
                        >
                            {Termino1}
                        </Text>
                        <Text
                            style={{
                                fontFamily: "Inter-Bold",
                                fontSize: 15,
                                color: "black",
                                marginLeft: "5%",
                                marginRight: "5%",
                                marginVertical: "0%",
                                textAlign: "justify",
                            }}
                        >
                            {"\n"}
                            {"\n"}
                            {TituloTermino2}
                        </Text>
                        <Text
                            style={{
                                fontFamily: "Inter-Regular",
                                fontSize: 15,
                                color: "black",
                                marginLeft: "5%",
                                marginRight: "5%",
                                marginVertical: "0%",
                                textAlign: "justify",
                            }}
                        >
                            {Termino2}
                        </Text>
                        <Text
                            style={{
                                fontFamily: "Inter-Bold",
                                fontSize: 15,
                                color: "black",
                                marginLeft: "5%",
                                marginRight: "5%",
                                marginVertical: "0%",
                                textAlign: "justify",
                            }}
                        >
                            {"\n"}
                            {"\n"}
                            {TituloTermino3}
                        </Text>
                        <Text
                            style={{
                                fontFamily: "Inter-Regular",
                                fontSize: 15,
                                color: "black",
                                marginLeft: "5%",
                                marginRight: "5%",
                                marginVertical: "0%",
                                textAlign: "justify",
                            }}
                        >
                            {Termino3_1}
                            {"\n"}
                            {"\n"}
                            {Termino3_2}
                        </Text>
                        <Text
                            style={{
                                fontFamily: "Inter-Bold",
                                fontSize: 15,
                                color: "black",
                                marginLeft: "6%",
                                marginRight: "6%",
                                marginVertical: "0%",
                                textAlign: "center",
                            }}
                        >
                            {"\n"}
                            {"\n"}
                            {final}
                            {"\n"}
                        </Text>
                        </ScrollView>
                    </View>
                </View>
            </View>
            <TouchableOpacity 
              onPressIn={() => navigation.navigate(ROUTES.MENU_CONFIG)}
              style={{
                backgroundColor: PALETADECOLORES.RojoMamey,
                borderRadius: 30,
                //borderColor: "black",
                marginVertical: "-30%",
                marginBottom: '20%',
                marginLeft: "3%",
                marginRight: "-30%",
                width: 190,
                height: 70,
                borderRadius: 50,
                //borderWidth: 3,
              }}>
              <Text 
                style={{
                  color: "black",
                  fontFamily: "Inter-Bold",
                  fontSize: 17,
                  marginTop: "12%",
                  marginLeft: "45%"}}
              >
                Regresar
              </Text>
              <FontAwesome 
                  style={{
                    marginTop: "-21%",
                    marginLeft: "10%",
                  }}
                  name="arrow-circle-left" 
                  size={55} 
                  color="black" 
                />
            </TouchableOpacity> 
        </View>
    );
};

export default Declaracion;