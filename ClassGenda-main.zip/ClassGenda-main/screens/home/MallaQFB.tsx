import React, { useState } from 'react';
import { View,
    StyleSheet,
    Text,
    ScrollView, 
    Pressable,
} from 'react-native';
// ------------------------------- DEPENDENCIAS ---------------------------------
import { useNavigation } from '@react-navigation/native';
import Animated, { useAnimatedGestureHandler, useAnimatedStyle, useSharedValue, withSpring } from 'react-native-reanimated';
import { PanGestureHandler, PanGestureHandlerGestureEvent} from 'react-native-gesture-handler';
// ------------------------------- COMPONENTES ----------------------------
import  {ROUTES, PALETADECOLORES} from '../../components';
import  {ClassElement} from '../../components/ClassElement';
// ------------------------- ICONOS -----------------------------------------------------
import {
    MaterialIcons,
    MaterialCommunityIcons,
    FontAwesome,
    FontAwesome5,
    Ionicons,
} from "@expo/vector-icons";

const SIZE = 100.0;
const W_RECTANGULE = SIZE + 5;
const H_RECTANGULE = SIZE * 5;

type ContextType = {
    translateY: number;
    translateX: number;
};

const data = [
    {
        major: 'QFB',
        semesters: 8,
        classes: [
            [
                {
                nombre: 'METODOS MATEMATICOS 1',
                numero_horas: 4,
                numero_creditos: 8,
                modulo: 'Sistemas Inteligentes ' ,
                clave: 'I5893'
                },
                {
                    nombre: 'PROGRAMACION ORIENTADA A OBJETOS',
                    numero_horas: 4,
                    numero_creditos: 8,
                    modulo: 'Sistemas Inteligentes ' ,
                    clave: 'I5892'
                },
                {
                    nombre: 'ALGEBRA LINEA',
                    numero_horas: 4,
                    numero_creditos: 8,
                    modulo: 'Sistemas Inteligentes ' ,
                    clave: 'I5891'
                },
                {
                    nombre: 'OPTATIVA',
                    numero_horas: 4,
                    numero_creditos: 8,
                    modulo: 'Sistemas Inteligentes ' ,
                    clave: 'IL123'
                },
            ],
            [
                {
                nombre: 'METODOS MATEMATICOS 1',
                numero_horas: 4,
                numero_creditos: 8,
                modulo: 'Sistemas Inteligentes ' ,
                clave: 'I5893'
                },
                {
                    nombre: 'PROGRAMACION ORIENTADA A OBJETOS',
                    numero_horas: 4,
                    numero_creditos: 8,
                    modulo: 'Sistemas Inteligentes ' ,
                    clave: 'I5892'
                },
                {
                    nombre: 'ALGEBRA LINEA',
                    numero_horas: 4,
                    numero_creditos: 8,
                    modulo: 'Sistemas Inteligentes ' ,
                    clave: 'I5891'
                },
                {
                    nombre: 'OPTATIVA',
                    numero_horas: 4,
                    numero_creditos: 8,
                    modulo: 'Sistemas Inteligentes ' ,
                    clave: 'IL123'
                },
            ],
        ]
    },
];


const renderSquare = (classIndex: number) => {

    const [isModalOpen, setIsModalOpen] = useState<boolean>(false);

    const translateY = useSharedValue(0);
    const translateX = useSharedValue(0);
    
    const panGestureEvent = useAnimatedGestureHandler<
    PanGestureHandlerGestureEvent, 
    ContextType
    >({
        onStart: (event, context) => {
            context.translateY = translateY.value;
            context.translateX = translateX.value;
        },
        onActive: (event, context) => {
            translateY.value = event.translationY + context.translateY;
            translateX.value = event.translationX + context.translateX;
        },
        onEnd: (event) => {
            // const distance = Math.sqrt(translateY.value ** 2 + translateX.value ** 2)
            // console.log("Distancia: " + distance +" , " + " Higth: " + H_RECTANGULE + " , "+"X: " + translateX.value)
                // if (distance > 200){
                //     translateY.value = withSpring(0);
                //     translateX.value = withSpring(0);
                // }
                if (translateX.value != 0 ){
                    translateX.value = withSpring(0);
                    translateY.value = withSpring(0);
                }
                
        },

    })

    const rStyle = useAnimatedStyle(()=>{
        return {
            transform: [{
                translateY: translateY.value,
            },
            {
                translateX: translateX.value,
            }],
        }; 
    });

    const handlePress = () => {//handle pressing event for class details modal
        setIsModalOpen(() => !isModalOpen);
        console.log(isModalOpen);
    }

    return (
        <PanGestureHandler key={classIndex} onGestureEvent={panGestureEvent}>
            <Animated.View style={[rStyle]}>
                <Pressable onPress={handlePress}>
                    <ClassElement code={data[0].classes[0][classIndex].clave} name={data[0].classes[0][classIndex].nombre}/>
                </Pressable>
            </Animated.View>
        </PanGestureHandler>
    );
};


const MallaQFB = () => {
    const views = [...Array(4).keys()];
    
    return(
        <ScrollView contentContainerStyle={{ alignItems: 'center' }} style={styles.container}>
            <Text style={styles.majorTitle} >Carrera: {data[0].major}</Text>
            
            {/* Starts semester component */}
            <View style={styles.rectangule}>
                <View style={styles.rectanguleHeader}>
                    <Text style={styles.num}>1.</Text>
                    <MaterialIcons  name="edit" size={25}  color="#000000" style={{ marginLeft: 'auto' }}/>
                </View>
                <View style={{marginBottom: 'auto', marginTop: 'auto'}}>
                    {views.map((_, index) => renderSquare(index))} 
                </View>
            </View>
            {/* Ends semester component */}
            
        </ScrollView>
    );
};

const styles = StyleSheet.create({
    container: {
        width: '100%', 
        height: '100%', 
        paddingTop: 25, 
        backgroundColor: 'white'
    },
    majorTitle:{
        //Styles of container Title
        fontSize: 24,
        fontFamily: 'Kod-Bold',
    },
    square:{ //Cuadros de las materias
        width: SIZE*3,
        height: SIZE,
        backgroundColor: 'rgba(217,217,217,50)',
        borderRadius: 20,
        borderColor: 'rgba(0,0,0,100)',
        marginVertical: 3, // Añadido para separar verticalmente las vistas
        borderWidth: 5,
    },
    rectangule:{ //Cuadro donde estan los cuadritos grises que se mueven de materias
        width: (SIZE*3)+15,
        height: H_RECTANGULE,
        borderRadius: 20,
        borderWidth: 5,
        borderColor: 'rgba(0,0,0,100)',
        alignItems: 'center',
    },
    rectanguleHeader: {
        width: '100%',
        height: '8%', 
        paddingLeft: 20,
        paddingRight: 10,
        backgroundColor: 'rgb(255, 62, 42)',
        borderTopLeftRadius: 15,
        borderTopRightRadius: 15,
        alignItems: 'center',
        flexDirection: 'row',
    },
    lineaSuperior: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between', // Espacio uniforme entre los elementos
        width: '100%',
        paddingHorizontal: 10, // Espacio horizontal interno
        borderBottomWidth: 2, // Grosor de la línea
        borderBottomColor: 'black', // Color de la línea
        marginBottom: 470,
    },
    numeroContenedor: {
        backgroundColor: '#F7E114', // Color de fondo del contenedor del número
        paddingHorizontal: 1, // Espacio horizontal interno
        paddingVertical: 1, // Espacio vertical interno
        width: 20,
    },
    num:{
        fontSize: 16,
        fontWeight: 'bold',
    },
    imagen: {
        width: 15, // Tamaño de la imagen
        height: 15, // Tamaño de la imagen
        borderRadius: 2, // Borde redondeado para la imagen
        marginRight: 10, // Espacio a la derecha de la imagen
        backgroundColor: 'yellow',
    },

});
export default MallaQFB;