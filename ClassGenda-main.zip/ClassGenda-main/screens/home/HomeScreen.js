// Pantalla principal de la aplicación.
// ----------------------------------------- DEPENDENCIAS --------------------
import React, { useState, useEffect } from 'react';
import { View,
  StyleSheet,
  Text,
  TouchableOpacity,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
// ----------------------------------------- COMPONENTES ---------------------
import { PALETADECOLORES, ROUTES } from '../../components';
import BackgroundHomeScreen from '../../components/BackgroundHomeScreen';

const HomeScreen = props => {
  //Importar navigation, dado que este permite que la app se desplace entre pantallas correctamente.
  const navigation = useNavigation();

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS == "ios" ? "padding" : "height"}
      style={styles.scrollContainer}
    >

    <BackgroundHomeScreen
      //Aquí se llama ala función del fondo especifico para la pantalla de inicio.
    >
      <View 
        style={styles.maincontainer}>
          <Text 
            style={styles.title}
          >
            ClassGenda
          </Text>
          <TouchableOpacity   //Botón para acceder a la siguiente pantalla (Inicio de sesión).
            onPress={() => navigation.navigate(ROUTES.LOGIN)}
            activeOpacity={0.7}
            style={styles.button}>
              <Text 
                style={styles.buttonText}
              >
                Login
              </Text>
              <Ionicons 
                style={styles.arrow}
                name="arrow-forward-outline" 
                size={50} 
                color="white"
              />
          </TouchableOpacity>
      </View>
    </BackgroundHomeScreen>
  </KeyboardAvoidingView>

  );
};

const styles = StyleSheet.create({
  maincontainer:{     // Contenedor inicial de la pantalla.
    height: "100%",
    width: "100%",
  },
  title: {
    fontFamily: "OpenSans-ExtraBold",
    fontSize: 62,
    width: "80%",
    marginLeft: "13%",
    marginBottom: "10%",
    marginTop: "120%",
  },
  buttonText:{      // Estilos del botón a partir de aquí.
    color: "white",
    fontSize: 22,
    fontFamily: "Lilita",
    marginTop: "14.5%",
    marginLeft: "5%",
  },
  button: {
    flexDirection: 'row',
    justifyContent: 'center',
    backgroundColor: PALETADECOLORES.AmarilloPatito,
    borderRadius: 40,
    marginVertical: "10%",
    marginRight: "12%",
    marginLeft: "45%",
    height: "10%",
    width: "45%",
  },
  arrow: {
    justifyContent: "center",
    marginTop: "7%",
    marginLeft: "6%",
  },
});

export default HomeScreen;