//Pantallas principales + ruta.
export {default as HomeScreen} from './home/HomeScreen';
export {default as Login} from './auth/Login';
export {default as ForgotPassword} from './auth/ForgotPassword';
export {default as SignUp} from './auth/SignUp';

export {default as AñadirAsignatura} from './home/AñadirAsignatura';
export {default as AñadirClase} from './home/AñadirClase';
export {default as AñadirUsuario} from './home/AñadirUsuario';
export {default as Asignatura} from './home/Asignatura';
export {default as DashboardGeneral} from './home/DashboardGeneral';
export {default as UsuariosExistentes} from './home/UsuariosExistentes';

export {default as Mallas} from './home/Mallas';
export {default as Malla} from './home/Malla';

export {default as EditarAsignatura} from './home/EditarAsignatura';
export {default as EditarPerfil} from './home/EditarPerfil';
export {default as EditarClase} from './home/EditarClase';

export {default as MenuConfig} from './home/MenuConfig';
export {default as AcercaDe} from './home/AcercaDe';
export {default as Condiciones} from './home/Condiciones';
export {default as Declaracion} from './home/Declaracion';