// ------------------ DEPENDENCIAS -----------------------------------------------------
import React, { Component } from "react";
import { useState, useEffect } from 'react';
import { View,
    Text,
    ScrollView,
    StyleSheet,
} from 'react-native';
import { 
    Menu,
    MenuOptions,
    MenuOption,
    MenuTrigger, } from 'react-native-popup-menu';
import { CheckBox } from 'react-native-elements';
import { useNavigation } from '@react-navigation/native';
// ------------------------- ICONOS -----------------------------------------------------
import {
    MaterialIcons,
    FontAwesome5,
    Foundation,
    MaterialCommunityIcons,
  } from "@expo/vector-icons";
  import ROUTES from "./Routes";
import { EditarClase } from '../screens/home/EditarClase';
import { PALETADECOLORES } from '.';
import { supabase } from "../lib/supabase";

export default function Classes ({Name, Description, Status, props}) {

    // Valor para el estatus.
    const [checked, setChecked] = useState(false);

    //Importar navigation, dado que este permite que la app se desplace entre pantallas correctamente.
    const navigation = useNavigation();

    // Variables para el menú de acciones de las clases (ver, eliminar y editar clase).
    const [visible, setVisible] = React.useState(false);
    const openMenu = () => setVisible(true);
    const closeMenu = () => setVisible(false);
    
    return (
        <View style={styles.Student}>
            <View style={styles.ClassStatus}>
                <CheckBox
                    checked={checked}
                    onPress={() => setChecked(!checked)}
                    checkedColor="green"
                    uncheckedColor="black"
                />
            </View>
            <View 
                style={styles.ClassName}>
                <ScrollView nestedScrollEnabled={true}>
                    <Text 
                        style={styles.Names}>
                            {Name}
                    </Text>
                </ScrollView>
            </View>
            <View 
                style={styles.ClassDescrip}>
                <ScrollView nestedScrollEnabled={true}>
                    <Text 
                        style={styles.Names}>
                            {Description}
                    </Text>
                </ScrollView>
            </View>
            <Menu>  
                <MenuTrigger                //POP UP MENU - Acciones.
                    customStyles={{
                        triggerWrapper: {
                          top: 1,
                          marginLeft: 12.5,
                        },
                      }}>
                    <MaterialCommunityIcons  //Icono para seleccionar una acción.
                        name="loupe" 
                        size={40}  
                        color="#000000" 
                    />
                </MenuTrigger>
                    <MenuOptions                    //Primera opcion: ver clase.
                        optionsContainerStyle= {{   
                            borderWidth: 2,
                            borderColor: "black",
                            backgroundColor: PALETADECOLORES.RojoMamey,
                            height: "9%",
                            width: "36%",
                        }}
                    >
                        <MenuOption                 // Segunda opción: Eliminar.
                            customStyles={{
                                optionWrapper: { 
                                    padding: 3,
                                    marginEnd: 5,
                                    width: "100%",
                                    height: "50%",
                                    marginLeft: 1,
                                }
                            }}
                            onSelect={() => alert(`Asignatura eliminada:)`)}  
                        >
                                <FontAwesome5 
                                    name="trash" 
                                    size={20}  
                                    color="#000000"
                                    style={{
                                        marginVertical: "2%",
                                        marginLeft: "17%",
                                    }}
                                 /> 
                                <Text style={{
                                    marginVertical: "-18.5%",
                                    marginLeft: "36%",
                                    fontFamily: "Kod-Bold",
                                    color: "black",
                                }}>
                                    Eliminar
                                </Text>
                        </MenuOption>
                        <MenuOption                 //Tercera opción: Editar Clase.
                            customStyles={{
                                optionWrapper: { 
                                    padding: 3,
                                    marginEnd: 20,
                                    width: "100%",
                                    height: "50%",
                                    marginLeft: 1,
                                }
                            }}
                            onSelect={() => navigation.navigate(EditarClase)}  
                        >
                                <Foundation 
                                    name="page-edit" 
                                    size={25}  
                                    color="#000000"
                                    style={{
                                        marginVertical: "2%",
                                        marginLeft: "19%",
                                    }}
                                 /> 
                                <Text style={{
                                    marginVertical: "-20.5%",
                                    marginLeft: "39%",
                                    fontFamily: "Kod-Bold",
                                    color: "black",
                                }}>
                                    Editar
                                </Text>
                        </MenuOption>
                </MenuOptions>
            </Menu>
        </View>
    );
}

const styles = StyleSheet.create({
    Student:{
      backgroundColor: '#FECF81',
      marginTop: "1%",
      borderRadius: 20,
      flexDirection: "row",
      alignContent: "center",
      alignItems: "center",
      height: 60,
    },
    ClassStatus:{
        marginTop: "1%",
        borderRadius: 10,
        flexDirection: "column",
        marginRight: "7%",
        marginLeft: '1%',
        height: "95%",
        width: "10%",
    },
    ClassName:{
        backgroundColor: "white",
        marginTop: "1%",
        borderRadius: 10,
        borderColor: "black",
        borderWidth: 2,
        flexDirection: "column",
        alignContent: "center",
        alignItems: "center",
        marginLeft: "-0.1%",
        borderColor: "black",
        height: "60%",
        width: "30%",
      },
    ClassDescrip:{
        backgroundColor: "white",
        marginTop: "1%",
        borderRadius: 10,
        flexDirection: "column",
        alignContent: "center",
        alignItems: "center",
        marginLeft: "3%",
        borderColor: "black",
        borderWidth: 2,
        height: "60%",
        width: "32%",
    },
    ClassAction: {
        flex: 1,
        backgroundColor: '#FECF81',
        padding: 9,
    },
    Image:{
        marginLeft: "6%",
        width: 45,
        height: 60,
    },
    Names: {
        fontFamily: "Inter-Regular",
        marginVertical: "2%",
        marginLeft: "3%",
        fontSize: 10,
    },
})