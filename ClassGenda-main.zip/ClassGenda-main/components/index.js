//Index con los archivos generales que van a 
// utilizarse en ClassGenda.
import ROUTES from './Routes';
import PALETADECOLORES from './PaletaDeColores';
import IMAGENES from './imagenes';
//import ClassElement from './ClassElement';

export {IMAGENES, ROUTES, PALETADECOLORES, /*ClassElement*/};