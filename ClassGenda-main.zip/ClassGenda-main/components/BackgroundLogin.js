//Settings generales del background del login.
// -------------------- DEPENDENCIAS ------------------
import React from "react";
import { 
    View, 
    StyleSheet, 
    Dimensions, 
    ImageBackground 
} from "react-native";
import { scale, verticalScale, moderateScale } from 'react-native-size-matters';

const BackgroundLogin = ({children}) => {
    return (
        <View>
            <ImageBackground 
                source= {require('../assets/fondoLogin.png')}  
                style={styles.backgroundImage}
                //resizeMode="stretch" 
            />
            <View style={{ position: "absolute"}}>
                {children}
            </View>
        </View>
    );
}

const styles = StyleSheet.create({
backgroundImage: {
  flex: 1,
  backgroundColor:'white',
  width: moderateScale(550),
  height: verticalScale(800),
  marginVertical: scale(0),
  marginLeft: scale(0),

},
});

export default BackgroundLogin;