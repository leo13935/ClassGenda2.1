//PANTALLAS CLASSGENDA.
export default {
    LOGIN: 'Login',
    HOME: 'Home Screen',
    DRAWER: 'drawer',
    FORGOTPASSWORD: 'ForgotPassword',
    SIGNUP: 'SignUp',

    AÑADIR_ASIGNATURA: 'Añadir Asignatura',
    AÑADIR_CLASE: 'Añadir clase',
    AÑADIR_USUARIO: 'Añadir Usuario',
    ASIGNATURA: 'Asignatura',
    PAGINA_PRINCIPAL: 'Dashboard General',
    USUARIOS: 'Usuarios Existentes',
    MALLAS: 'Licenciaturas',
    /*MALLA: 'Malla curricular',
    MallaINNI: 'Malla INNI',*/
    HORARIO: 'Horario',

    EDITARASIGNATURA: 'Editar Asignatura',
    EDITAR_PERFIL: 'Editar Perfil',
    EDITAR_CLASE: 'Editar Clase',

    MENU_CONFIG: 'Configuración',
    ACERCA_DE: 'Acerca de',
    DECLARACIONES_PRIVACIDAD: 'Políticas de privacidad',
    CONDICIONES_USO: 'Términos y condiciones',

    MALLA_ICOM: 'Malla',
    MALLA_INNI: 'MallaINNI',
    MALLA_LCMA: 'MallaLCMA',
    MALLA_LIFI: 'MallaLIFI',
    MALLA_INBI: 'MallaINBI',
    MALLA_ICIV: 'MallaICIV',
    MALLA_LIAB: 'MallaLIAB',
    MALLA_INCE: 'MallaINCE',
    MALLA_TOPO: 'MallaTOPO',
    MALLA_IGFO: 'MallaIGFO',
    MALLA_INDU: 'MallaINDU',
    MALLA_IME: 'MallaIME',
    MALLA_INRO: 'MallaINRO',
    MALLA_MATE: 'MallaMATE',
    MALLA_QUI: 'MallaQUI',
    MALLA_LQUI: 'MallaLQUI',
    MALLA_QFB: 'MallaQFB',
    MALLA_ILOT: 'MallaILOT',


};