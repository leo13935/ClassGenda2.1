import * as React from 'react';
import { useState, useEffect } from 'react';
import { View,
    Text,
    ScrollView,
    StyleSheet,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { 
    Menu,
    MenuOptions,
    MenuOption,
    MenuTrigger, } from 'react-native-popup-menu';
// ------------------------- ICONOS -----------------------------------------------------
import {
    MaterialIcons,
    FontAwesome5,
    Foundation,
    MaterialCommunityIcons,
  } from "@expo/vector-icons";
import PaletaDeColores from "./PaletaDeColores";
import { EditarAsignatura } from '../screens/home/EditarAsignatura';
import { PALETADECOLORES } from '.';

export default function Subjects ({Name, Description, Nrc}) {
    const [checked, setChecked] = useState(false);
    const nrc = Nrc;
    const [visible, setVisible] = React.useState(false);
    const openMenu = () => setVisible(true);
    const closeMenu = () => setVisible(false);
    const navigation = useNavigation(); // Obtiene el objeto de navegación
    const handleView = (nrc) => {
        // Navega a la vista de detalles y pasa el ID como parámetro
        navigation.navigate('Asignatura', { codigo_materia: nrc });
      };
    return (
        <View style={styles.Student}>
            <View 
                style={styles.ClassName}>
                <ScrollView nestedScrollEnabled={true}>
                    <Text 
                        style={styles.Names}>
                            {Name}
                    </Text>
                </ScrollView>
            </View>
            <View 
                style={styles.ClassDescrip}>
                <ScrollView nestedScrollEnabled={true}>
                    <Text 
                        style={styles.Names}>
                            {Description}
                    </Text>
                </ScrollView>
            </View>
            <Menu>  
                <MenuTrigger    //POP UP MENU - Acciones.
                    customStyles={{
                        triggerWrapper: {
                          top: 1,
                          marginLeft: 19.5,
                        },
                      }}>
                    <MaterialCommunityIcons  //Icono para seleccionar una acción.
                        name="message-draw" 
                        size={40}  
                        color="#000000" 
                    />
                </MenuTrigger>
                    <MenuOptions
                        optionsContainerStyle= {{   //Primera opción: Ver asignatura.
                            borderWidth: 2,
                            borderColor: "black",
                            backgroundColor: PALETADECOLORES.AmarilloPatito,
                            height: "12%",
                            width: "38%",
                        }}
                    >
                        <MenuOption 
                            customStyles={{
                                optionWrapper: { 
                                    padding: 3,
                                    marginEnd: 20,
                                    width: "100%",
                                    height: "33%",
                                }
                            }}

                            onSelect={() => handleView(nrc)}
                        >
                                <MaterialIcons 
                                    name="remove-red-eye" 
                                    size={27}  
                                    color="#000000"
                                    style={{
                                        marginVertical: "0%",
                                        marginLeft: "1%",
                                        marginEnd: "20%",
                                    }}
                                 />        

                                <Text style={{
                                    marginVertical: "-17%",
                                    marginLeft: "25%",
                                    fontFamily: "Inter-Bold",
                                    color: "black",
                                }}>
                                    Ver asignatura
                                </Text>
                        </MenuOption>
                        <MenuOption     // Segunda opción: Eliminar.
                            customStyles={{
                                optionWrapper: { 
                                    padding: 3,
                                    marginEnd: 20,
                                    width: "100%",
                                    height: "33%",
                                }
                            }}
                            onSelect={() => alert(`Asignatura eliminada:)`)}  
                        >
                                <FontAwesome5 
                                    name="trash" 
                                    size={20}  
                                    color="#000000"
                                    style={{
                                        marginVertical: "2%",
                                        marginLeft: "5.5%",
                                    }}
                                 /> 
                                <Text style={{
                                    marginVertical: "-17.5%",
                                    marginLeft: "26%",
                                    fontFamily: "Inter-Bold",
                                    color: "black",
                                }}>
                                    Eliminar
                                </Text>
                        </MenuOption>
                        <MenuOption     //Tercera opción: Editar asignatura.
                            customStyles={{
                                optionWrapper: { 
                                    padding: 3,
                                    marginEnd: 20,
                                    width: "100%",
                                    height: "33%",
                                }
                            }}
                            onSelect={() => navigation.navigate(EditarAsignatura)}  
                        >
                                <Foundation 
                                    name="page-edit" 
                                    size={25}  
                                    color="#000000"
                                    style={{
                                        marginVertical: "1%",
                                        marginLeft: "6%",
                                    }}
                                 /> 
                                <Text style={{
                                    marginVertical: "-16%",
                                    marginLeft: "27%",
                                    fontFamily: "Inter-Bold",
                                    color: "black",
                                }}>
                                    Editar
                                </Text>
                        </MenuOption>
                </MenuOptions>
            </Menu>
        </View>
    );
}

const styles = StyleSheet.create({
    eye:{
        
    },
    Student:{
      backgroundColor: PaletaDeColores.Azul,
      marginTop: "1%",
      borderRadius: 20,
      flexDirection: "row",
      alignContent: "center",
      alignItems: "center",
      height: 60,
    },
    ClassName:{
        backgroundColor: "white",
        marginTop: "1%",
        borderRadius: 10,
        borderColor: "black",
        borderWidth: 2,
        flexDirection: "column",
        alignContent: "center",
        alignItems: "center",
        marginLeft: "5%",
        borderColor: "black",
        height: "60%",
        width: "33%",
      },
    ClassDescrip:{
        backgroundColor: "white",
        marginTop: "1%",
        borderRadius: 10,
        flexDirection: "column",
        alignContent: "center",
        alignItems: "center",
        marginLeft: "3%",
        borderColor: "black",
        borderWidth: 2,
        height: "60%",
        width: "36%",
    },
    Names: {
        fontFamily: "Inter-Bold",
        marginLeft: "3%",
        fontSize: 10,
    },
})