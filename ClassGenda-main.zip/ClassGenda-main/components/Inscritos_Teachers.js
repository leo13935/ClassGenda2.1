//Back Profesores inscritos.
// -------------------- DEPENDENCIAS ------------------
import React from "react";
import {Text, View, StyleSheet, Image} from "react-native";

export default function Teachers ({teachers}) {
    return (
        <View style={styles.Teachers}>
            <Image
                source={require('../assets/User.png')}
                style={styles.Image}
            />
            <Text style={styles.Names}>{teachers.First_Name} {teachers.Last_Name}</Text>
        </View>
    );
}

const styles = StyleSheet.create({
    Teachers:{      //Estilo para los profesores.
      backgroundColor: "white",
      marginTop: "1%",
      borderRadius: 20,
      flexDirection: "row",
      alignContent: "center",
      alignItems: "center",
    },
    Image:{         //Estilo para la foto del profesor.
        marginLeft: "2%",
        width: 50,
        height: 52,
        marginVertical: 4,
        borderRadius: 100,
    },
    Names: {        // Estilo para los nombres.
        fontFamily: "Inter-Bold",
        marginLeft: "3%",
    },
})