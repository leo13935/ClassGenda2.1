//Settings generales del background del homescreen.
// -------------------- DEPENDENCIAS ------------------
import React from "react";
import { 
    View, 
    StyleSheet,  
    ImageBackground,
    Dimensions, 
} from "react-native";
import { scale, verticalScale, moderateScale } from 'react-native-size-matters';

const BackgroundHomeScreen = ({children}) => {
    return (
    <View>
        <ImageBackground 
            source= {require('../assets/fondoHomeScreen.png')}  
            style={styles.backgroundImage}
        />
          <View style={{ position: "absolute", top: -96,}}>
            {children}
        </View>
    </View>
    );
}


const styles = StyleSheet.create({
    backgroundImage: {
      flex: 1,
      backgroundColor:'white',
      width: moderateScale(390),
      height: verticalScale(715),
      marginVertical: scale(0),
      marginLeft: scale(0),
    },
    });

export default BackgroundHomeScreen;