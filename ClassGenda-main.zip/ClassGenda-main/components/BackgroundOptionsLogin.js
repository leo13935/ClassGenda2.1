//Settings generales del background de "forgot password" y "register".
// -------------------- DEPENDENCIAS ------------------
import React from "react";
import { 
    View, 
    StyleSheet, 
    Dimensions, 
    ImageBackground 
} from "react-native";
import { scale, verticalScale, moderateScale } from 'react-native-size-matters';


const BackgroundOptionsLogin = ({children}) => {
    return (
    <View>
        <ImageBackground 
            source= {require('../assets/fondoOptionsLogin.png')}  
            style={styles.backgroundImage}
        />
        <View style={{ position: "absolute"}}>
            {children}
        </View>
    </View>
    );
}

const styles = StyleSheet.create({
backgroundImage: {
  flex: 1,
  backgroundColor:'white',
  width: moderateScale(380),
  height: verticalScale(715),
  marginVertical: scale(0),
  marginLeft: scale(0),
},
});

export default BackgroundOptionsLogin;