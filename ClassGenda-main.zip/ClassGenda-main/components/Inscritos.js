// -------------------- DEPENDENCIAS ------------------
import React from "react";
import {Text, View, StyleSheet, Image} from "react-native";

export default function Inscritos ({students}) {
    return (
        <View style={styles.Student}>
            <Image
                source={require('../assets/User.png')}
                style={styles.Image}
            />
            <Text style={styles.Names}>{students.code}</Text>
        </View>
    );
}

const styles = StyleSheet.create({
    Student:{       //Estilo para los alumnos.
      backgroundColor: "white",
      marginTop: "1%",
      borderRadius: 20,
      flexDirection: "row",
      alignContent: "center",
      alignItems: "center",
    },
    Image:{     //Estilo para la foto de perfil
        marginLeft: "2%",
        width: 50,
        height: 52,
        marginVertical: 4,
        borderRadius: 100,
    },
    Names: {        // Estilo para los nombres.
        fontFamily: "Inter-Regular",
        marginLeft: "3%",
    },
})