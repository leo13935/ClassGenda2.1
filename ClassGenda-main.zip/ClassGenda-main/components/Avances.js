//Avance del semestre caja Azul.
// ------------------------ DEPENDENCIAS -------------------------------
import React from "react";
import { useState, useEffect } from 'react';
import {Text, View, StyleSheet, ScrollView} from "react-native";
import { CheckBox } from 'react-native-elements';
import {PALETADECOLORES} from '.';

export default function Classes ({Name, Description, Status}) {

    // Valor para el estatus.
    const [checked, setChecked] = useState(false);

    console.log(Name);
    return (
        <View style={styles.Student}>
            <View style={styles.ClassStatus}>
            <CheckBox
                checked={checked}
                onPress={() => setChecked(!checked)}
                checkedColor="green"
                uncheckedColor="black"
            />
            </View>
            <View style={styles.ClassName}>
            <ScrollView nestedScrollEnabled={true}>
                <Text style={styles.Names}>{Name}</Text>
            </ScrollView>
            </View>
            <View style={styles.ClassDescrip}>
            <ScrollView nestedScrollEnabled={true}>
                <Text style={styles.Names}>{Description}</Text>
            </ScrollView>
            </View>
            <View style={styles.ClassAction}></View>
        </View>
    );
}

const styles = StyleSheet.create({
    Student:{
      backgroundColor: PALETADECOLORES.Azul,
      marginTop: "1%",
      borderRadius: 20,
      flexDirection: "row",
      alignContent: "center",
      alignItems: "center",
      height: 60,
    },
    ClassStatus:{
        marginTop: "1%",
        borderRadius: 10,
        flexDirection: "column",
        marginRight: "7%",
        height: "95%",
        width: "10%",
    },
    ClassName:{
        backgroundColor: "white",
        marginTop: "1%",
        borderRadius: 10,
        borderColor: "black",
        borderWidth: 2,
        flexDirection: "column",
        alignContent: "center",
        alignItems: "center",
        marginLeft: "1%",
        borderColor: "black",
        height: "60%",
        width: "30%",
      },
    ClassDescrip:{
        backgroundColor: "white",
        marginTop: "1%",
        borderRadius: 10,
        flexDirection: "column",
        alignContent: "center",
        alignItems: "center",
        marginLeft: "1%",
        borderColor: "black",
        borderWidth: 2,
        height: "60%",
        width: "35%",
    },
    ClassAction: {
        backgroundColor: "white",
        marginTop: "1%",
        borderRadius: 10,
        flexDirection: "column",
        alignContent: "center",
        alignItems: "center",
        marginLeft: "1%",
        borderColor: "black",
        borderWidth: 2,
        height: "60%",
        width: "12%",
    },
    Names: {
        fontWeight: "bold",
        marginLeft: "3%",
        fontSize: 10,
    },
})