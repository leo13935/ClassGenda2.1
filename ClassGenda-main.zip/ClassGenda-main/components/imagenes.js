//Archivo que contiene las imagenes generales a usar en el proyecto.
export default {
    //Imagen default user.
    User: require('../assets/User.png'),
    //Imagen default al guardar un registro.
    Done: require('../assets/animation_lmu2y1qg.json'),

    Acerca: require('../assets/supervision.png')
};