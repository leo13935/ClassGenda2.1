//Diseño del drawer navigator.
// -------------------- DEPENDENCIAS ---------------------------------------------------
import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  ImageBackground,
  Image,
  TouchableOpacity,
} from 'react-native';
import {
  DrawerContentScrollView,
  DrawerItemList,
} from '@react-navigation/drawer';
import { useNavigation } from '@react-navigation/native';
// ------------------------- ICONOS -----------------------------------------------------
import {
    AntDesign,
    MaterialIcons,
    FontAwesome,
    Ionicons,
  } from "@expo/vector-icons";
  // --------------------- COMPONENTES ------------------------------------------------------
import {IMAGENES, ROUTES, PALETADECOLORES} from '../components';
// ------------------------- SUPABASE -----------------------------------------------------
import { supabase } from '../lib/supabase';
import { UserCodeProvider, useUserCode } from '../screens/auth/UserCodeProvider';

const CustomDrawer = props => {
    //Importar navigation, dado que este permite que la app se desplace entre pantallas correctamente.
    const navigation = useNavigation();

    const {userCode} = useUserCode();
    const codigo = userCode[0].User_Id;
    const [userInfo, setUserInfo] = useState(null);
    const [profilePicture, setProfilePicture] = useState(null);

    //Función para el cierre de sesión.
    const logout = async () => {
        try {
            const { error } = await supabase.auth.signOut();
        }   catch (error) {
            console.log(error);
        }
            navigation.navigate(ROUTES.HOME); //Regresa al usuario a la pantalla de inicio de la app.
      };

    const avatarFileName = 'profile_217537881.jpg';
    const getAvatarUrl = async () => {
        const { publicURL } = await supabase
            .storage
            .from('avatars')
            .createSignedUrl(avatarFileName, 60); // 60 segundos de validez del enlace firmado
        
        console.log("Foto obtenida con exito, ", publicURL);
        return publicURL;
    };

    useEffect(() => {
    async function fetchUserInfo() {
        const { data, error } = await supabase
        .from('Users')
        .select('First_Name, Last_Name')
        .eq('User_Id', codigo)
        .single();
        if (error) {
        console.error('Error al obtener la información del usuario:', error);
        } else {
        setUserInfo(data);
        }
    }
    const  fetchUserPhoto = async () => {
        const url = await getAvatarUrl();
        setProfilePicture(url);
        /*
        const UrlName = `profile_${codigo}.jpg`;
        // Intenta obtener la URL de descarga de la imagen de perfil
        try {
            const { signedURL, error } = supabase.storage
            .from('avatars')
            .createSignedUrl(UrlName, 60);

            if (error) {
            console.error('Error al obtener la URL de descarga:', error);
            } else {
            console.log("URL NAME: ", UrlName);
            console.log("Foto consultada con exito: ", signedURL);
            setProfilePicture(signedURL);
            }
        } catch (error) {
            console.error('Error al obtener la URL de descarga:', error);
        }
        */
    }
    fetchUserInfo();
    fetchUserPhoto();
    }, [codigo]);

    return (
        <View style={{flex: 1}}>
            <DrawerContentScrollView       //Permite desplazarse en el drawer en caso de un gran número de contenido.
                {...props}
                contentContainerStyle={{
                    backgroundColor: PALETADECOLORES.AmarilloPatito
                }}>
                <ImageBackground           //Fondo del menu lateral - Foto del usuario.
                    source={require('../assets/fondoUser.jpg')} 
                    style={{
                        padding: 20,
                    }}>
                {profilePicture ? (     //En caso de encontrarse una foto de perfil en la BD proporcionada por el usuario se muestra.
                    <Image source={{ uri: profilePicture }} style={{
                        height: 100, 
                        width: 100, 
                        borderRadius: 20, 
                        marginBottom: 10
                        }} />
                ) : (
                    <Image //De locontrario se mostrará en el panel una imagen de default.
                        source={IMAGENES.User}
                        style={{
                            height: 100, 
                            width: 100, 
                            borderRadius: 20, 
                            marginBottom: 10
                        }}/>                )}
                    
                    <FontAwesome name="user" size={23} color="black"/>
                    {userInfo ? (
                        <Text   //Informacion general del usuario registrado.
                                style={{
                                color: 'black',
                                fontSize: 18,
                                fontFamily: 'Lilita',
                                marginLeft: 25,
                                marginVertical: '-11%',
                                }}>
                    {userInfo.First_Name} {userInfo.Last_Name}
                        </Text>
                        ) : (
                        <Text   //Informacion general del usuario registrado.
                        style={{
                        color: 'black',
                        fontSize: 15,
                        fontFamily: 'Kod-Bold',
                        marginLeft: 23,
                        marginVertical: '-11%',
                        }}>
                        Cargando información de usuario...
                        </Text>
                    )}
                    <AntDesign name="barcode" size={23} color="black" marginVertical='14%' marginLeft='-1.5%'/>
                    <Text
                        style={{
                            color: 'black',
                            fontSize: 14,
                            fontFamily: 'Riot-Regular',
                            marginLeft: 27,
                            marginVertical: '-26%',
                            marginBottom: 1,
                        }}>
                        Código: {codigo}
                    </Text>
                </ImageBackground>
                <View //Vista del menu.
                    style={{
                        backgroundColor: PALETADECOLORES.AmarilloPatito, 
                        paddingTop: '10%',
                    }}>
                    <DrawerItemList {...props} />
                </View>
            </DrawerContentScrollView>
            <View 
                style={{
                    padding: 20, 
                    borderTopWidth: 2, 
                    borderTopColor: 'white'
                }}>
                <TouchableOpacity //Boton de configuración de la app.
                    onPress={() => props.navigation.navigate(ROUTES.MENU_CONFIG)} 
                    style={{paddingVertical: 5}}>
                    <View 
                        style={{
                            flexDirection: 'row', 
                            alignItems: 'center'
                        }}>
                        <Ionicons name="settings" size={25} />
                        <Text
                            style={{
                                fontSize: 17,
                                fontFamily: 'Lilita',
                                marginLeft: 8,
                            }}>
                            Configuración
                        </Text>
                    </View>
                </TouchableOpacity>
                <TouchableOpacity //Boton para cerrar sesión y salir a la pantalla de inicio.
                    onPress={(logout)} 
                    style={{paddingVertical: 10}}>
                    <View 
                        style={{
                            flexDirection: 'row', 
                            alignItems: 'center'
                        }}>
                        <MaterialIcons name="logout" size={26} marginLeft='1%'/>
                        <Text
                            style={{
                                fontSize: 17,
                                fontFamily: 'Lilita',
                                marginLeft: 5,
                            }}>
                            Cerrar sesión
                        </Text>
                    </View>
                </TouchableOpacity>
            </View>
        </View>
    );
};

export default CustomDrawer;