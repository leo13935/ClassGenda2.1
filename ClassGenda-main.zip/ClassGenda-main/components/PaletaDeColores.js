//Colores principales de la aplicación.
export default {
    AmarilloPatito: '#FECF81',
    AmarilloDeslavado: '#FFE4B9',
    AzulPatito: "#9EDAED",
    Azul:'#4DBFE4',
    RojoMamey: "#F3898B",
    RosaMamey: "#F6D0D1",
};