import React from 'react';
import { View, StyleSheet, Text } from 'react-native';
import { MaterialIcons } from "@expo/vector-icons";
import { PALETADECOLORES } from '.';

const SIZE = 100.0;

export const ClassElement = ({code = 'IL123', name = 'CLASE'}) => {
    return (
        <View style={styles.topic}>
            <View style={styles.dragSection}>
                <MaterialIcons  name="menu" size={25}  color="#000000" style={{
                    marginTop: 'auto',
                    marginBottom: 'auto',
                    marginLeft: 'auto',
                    marginRight: 'auto',
                }}/>
            </View>
            <View style={styles.infoTopic}>
                <View 
                    style={{
                        height: '30%', 
                        backgroundColor: PALETADECOLORES.AzulPatito,
                        borderTopRightRadius: 15,
                        width: "110%", 
                    }}
                >
                    <Text style={{
                        paddingTop: 7, 
                        textAlign: 'center', 
                        fontFamily: "Lilita",
                        fontSize: 15,
                        marginLeft: -10,
                    }}>{code}</Text>
                </View>
                <View 
                    style={{
                        height: '60%',
                        width: "95%", 
                        //backgroundColor: "white", //para pruebas.
                        marginVertical: 5,
                        marginLeft: 10,
                    }}
                >
                    <Text style={{
                        textAlign: 'center', 
                        marginTop: 'auto', 
                        marginBottom: 'auto',
                        fontFamily: "Inter-Regular",
                    }}>{name}</Text>
                </View>
            </View>
        </View>
    );
};

const styles = StyleSheet.create({
    topic:{
        width: SIZE*3,
        height: SIZE,
        backgroundColor: 'rgba(172, 172, 172, 0.9)',
        borderRadius: 20,
        flexDirection: 'row',
        marginBottom: 5,
        marginTop: 5,
    },
    dragSection: {
        backgroundColor: 'rgb(255, 205, 49)',
        width: '12%',
        borderBottomLeftRadius: 20,
        borderTopLeftRadius: 20,
    },
    infoTopic: {
        width: '80%',
    },
});
