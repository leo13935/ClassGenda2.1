import { supabase } from "../../lib/supabase";
import { useEffect, useState } from "react";
import { useUserCode } from "../../screens/auth/UserCodeProvider";
export default async function ProfileInsert(image) {
  const { userCode } = useUserCode();
  const user_id = userCode[0].User_Id;
  console.log("CODIGO DEL USUARIO: ", user_id);
      const { data, error } = await supabase.storage
          .from('avatars')
          .upload(`profile_${user_id}`, image);
        if (error) {
          console.error('Error al subir la foto de perfil:', error);
        } else {
          console.log('La foto de perfil se ha subido con éxito', data);
        }
    return null; // Puedes devolver cualquier cosa o incluso nada, ya que este componente no renderiza nada visible
  }