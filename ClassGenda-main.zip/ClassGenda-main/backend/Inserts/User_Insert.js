// USER INSERT
import { supabase } from "../../lib/supabase";
import { useEffect } from "react";

const User_Insert = async (codigo, nivel, logged, apellidos, nombre, correo) => {
  try {
        const { data, error } = await supabase
          .from('Users')
          .insert([
            {
              User_Id: codigo,
              Level: nivel,
              log_id: logged,
              Last_Name: apellidos,
              First_Name: nombre,
              Email: correo,
            },
          ])
          .select();
        if (error) {
          console.error('Error al insertar datos:', error);
        } else {
          console.log('Datos insertados con éxito:', data);
        }
      } catch (error) {
        console.error('Error al insertar datos:', error.message);
      }
    };

export default User_Insert;
