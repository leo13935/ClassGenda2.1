import react from "react";
import { View,
    StyleSheet,
    Text,
    FlatList,
} from 'react-native';
import { supabase } from "../../lib/supabase";
import { useEffect, useState } from "react";

export default function Subject_Insert(valorNrc, teacherid,
  nombreAsignatura, status, dateInicio, dateFinal, descripcion, Students) {
  useEffect(() => {
    const Insert_Subject = async (valorNrc, teacherid,
      nombreAsignatura, status, dateInicio, dateFinal, descripcion, Students) => {
        const { data, error } =  await supabase
        .from('Subject')
        .insert([
            {
            NRC: valorNrc,
            Teacher_ID: userCode,
            Name: nombreAsignatura,
            Status: 0,
            Start_Date: dateInicio,
            End_Date: dateFinal,
            Description: descripcion,
            Students_IDs: Students,
            },
        ])
        .select();
        if (error) {
        console.error('Error al insertar datos:', error);
        } else {
        console.log('Datos insertados con éxito:', data, error);
        }
    };
  }, []);
}