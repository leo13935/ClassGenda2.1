import react from "react";
import { View,
    StyleSheet,
    Text,
    FlatList,
} from 'react-native';
import { supabase } from "../../lib/supabase";
import { useEffect, useState } from "react";

export default function Class_Insert(  ) {
  useEffect(() => {
    const Insert_Class = async (nrc, name,
      status, fecha,  inicio , fin ,descripcion) => {
        const { data, error } = await supabase
        .from('Classes')
        .insert([
            {
            NRC: nrc,
            Name: name,
            Description: descripcion,
            Status: status,
            Date: fecha,
            Start_Hour: inicio,
            End_Hour: fin,
            },
        ])
        .select();
        if (error) {
        console.error('Error al insertar datos:', error);
        } else {
        console.log('Datos insertados con éxito:', data);
        }
    };
  }, []);
}