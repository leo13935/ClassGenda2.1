import { supabase } from "../../lib/supabase";
import { useEffect, useState } from "react";

export default function Count_Subjects( rol ) {
    const [error, setError] = useState(null);
    const [userFound, setUserFound] = useState(false);
    const [ID, setID] = useState("0");
  
    useEffect(() => {
      const fetchUserInfo = async () => {
        try {
          const { data, error, status, count} = await supabase
            .from('Subject')
            .select('*', { count: 'exact', head: true})
            .eq("Teacher_ID",rol);
          if (error) {
            setError(error.message);
          } else {
            setID(count);
            setUserFound(true);
          }
        } catch (error) {
          setError('Ocurrió un error al buscar');
          setUserFound(true); // Si ocurre un error, establece el estado en verdadero para evitar búsquedas futuras
          console.error(error);
        }
      };
      if (!userFound) {
        fetchUserInfo();
      }
    }, [rol, userFound]);
    return ID;
  }