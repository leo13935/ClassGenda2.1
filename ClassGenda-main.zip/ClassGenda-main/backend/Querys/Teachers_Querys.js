import React, { useState, useEffect } from 'react';
import { View, StyleSheet, Text } from 'react-native';
import { supabase } from '../../lib/supabase';

export default function Teachers_Query() {
  const [error, setError] = useState(null);
  const [users, setUsers] = useState([]); // Array para almacenar los User_Id

  useEffect(() => {
    const fetchUsers = async () => {
        try {
            const { data, error } = await supabase
              .from('Users')
              .select('First_Name,Last_Name,User_Id')
              .eq('Level', 0);
            if (error) {
              setError(error.message);
            } else {
              setUsers(data.map((user) => ({
                label: user.First_Name + " " + user.Last_Name,
                value: user.User_Id,
              })));
            }
          } catch (error) {
            setError('Ocurrió un error al buscar los usuarios');
            console.error(error);
          }
    };

    fetchUsers();
  }, []);

  return { users }; // Devuelve la lista de códigos
}