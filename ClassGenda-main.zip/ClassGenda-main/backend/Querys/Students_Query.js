import React, { useState, useEffect } from 'react';
import { View, StyleSheet, Text } from 'react-native';
import { supabase } from '../../lib/supabase';

export default function Students_Query() {
  const [error, setError] = useState(null);
  const [users, setUsers] = useState([]); // Array para almacenar los User_Id

  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const { data, error } = await supabase
          .from('Users')
          .select('User_Id')
          .eq('Level', 1);
        if (error) {
          setError(error.message);
        } else {
            setUsers(data.map((user) => ({
                label: user.User_Id,
                value: user.User_Id,
              }))); // Devuelve un array con los User_Id en el formato deseado
            }
      } catch (error) {
        setError('Ocurrió un error al buscar los usuarios');
        console.error(error);
      }
    };

    fetchUsers();
  }, []);

  return { users }; // Devuelve la lista de códigos
}