import { supabase } from "../../lib/supabase";

export default function Pfp_Query(id) {
  return new Promise(async (resolve, reject) => {
    try {
      const { data, error } = await supabase
        .from('Users')
        .select('User_Picture')
        .eq('User_Id', id);

      if (error) {
        reject(error);
      } else {
        resolve(data);
      }
    } catch (error) {
      reject(error);
    }
  });
}
