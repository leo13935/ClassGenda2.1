import { supabase } from "../../lib/supabase";
import { useEffect, useState } from "react";

export default function UsersByLevel_Query( level ) {
  const [error, setError] = useState(null);
  const [userFound, setUserFound] = useState(false);
  const [ID, setID] = useState("0");

  useEffect(() => {
    const fetchUserInfo = async () => {
      try {
        const { data, error } = await supabase
          .from('Users')
          .select('*')
          .eq('Level', level);

        if (error) {
          setError(error.message);
        } else {
          setID(data);
          setUserFound(true);
        }
      } catch (error) {
        setError('Ocurrió un error al buscar los usuarios');
        setUserFound(true); // Si ocurre un error, establece el estado en verdadero para evitar búsquedas futuras
        console.error(error);
      }
    };

    if (!userFound) {
      fetchUserInfo();
    }
  }, [level, userFound]);
  return ID;
}