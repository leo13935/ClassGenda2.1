import react from "react";
import { View,
    StyleSheet,
    Text,
    FlatList,
} from 'react-native';
import { supabase } from "../../lib/supabase";
import { useEffect, useState } from "react";

export default function Suject_Student_Query( nrc ) {
  const [error, setError] = useState(null);
  const [userFound, setUserFound] = useState(false);
  const [ID, setID] = useState("0");

  useEffect(() => {
    const fetchUserInfo = async () => {
      try {
        const { data, error } = await supabase
          .from('Subject')
          .select('Students_IDs')
          .eq('NRC', nrc);
        if (error) {
          setError(error.message);
        } else {
          setID(data);
          setUserFound(true);
        }
      } catch (error) {
        setError('Ocurrió un error al buscar los alumnos');
        setUserFound(true); // Si ocurre un error, establece el estado en verdadero para evitar búsquedas futuras
        console.error(error);
      }
    };

    if (!userFound) {
      fetchUserInfo();
    }
  }, [nrc, userFound]);
  return ID;
}