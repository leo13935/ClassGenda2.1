import react from "react";
import { useState, useEffect } from 'react';
import { View,
    StyleSheet,
    Text,
    FlatList,
} from 'react-native';
import { supabase } from "../../lib/supabase";

//Se recibe la tabla a consultar, el nombre del campo y se pide el nrc de la tabla
export default function Subjects_Query ({tableName, fieldName, fieldValue, WantedValue}) {
        const [Value, setValue] = useState(null);
        useEffect(() => {
          const fetchRowData = async () => {
            const { data, error } = await supabase
              .from(tableName)
              .select(WantedValue)
              .eq(fieldName, fieldValue)
              .single();
            if (error) {
              console.log(error);
            } else {
              if(WantedValue=="Name"){
                setValue(data.Name);
              }else if (WantedValue == "Description"){
                setValue(data.Description);
              }else if(WantedValue == "Start_Date"){
                setValue(data.Start_Date);
              }else if(WantedValue == "End_Date"){
                setValue(data.End_Date);
              }
            }
          };
          fetchRowData();
        }, [supabase, tableName, fieldName, fieldValue]);
        return (
          <View>
            {Value &&
            <Text style={styles.TextOfBox}>{Value}</Text>}
          </View>
        );
};

const styles = StyleSheet.create({
  TextOfBox:{
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    textAlign: "center",
    marginLeft: "2%",
    marginRight: "2%",
    marginVertical: "5.5%",
  },
})