//Back para pantalla de Dashboard.
import * as React from 'react';
import { useState, useEffect } from 'react';
import { View,
    StyleSheet,
    Text,
    FlatList,
} from 'react-native';
import { supabase } from "../../lib/supabase";
//Para los campos dentro de la flatlist
import Subjects from "../../components/Subjects";

import { useNavigation } from '@react-navigation/native';


export default function All_Subject_Query ({NRC}) {
    const [classInfo, setClassInfo] = useState([]);
    useEffect(() => {
      const fetchClassInfo = async () => {
        try {
          const { data, error } = await supabase
            .from('Subject')
            .select('*')
            .eq('Teacher_ID', NRC)
          if (error) {
              console.log(error);
          } else {
              setClassInfo(data);
          }
        } catch (error) {
            console.log(error);
          }
      };
      fetchClassInfo();
    }, [NRC]);
    const navigation = useNavigation();
    return (
      <View>
        <FlatList
            data={classInfo}
            keyExtractor={(item) => item.id.toString()}
            renderItem={({item}) =>(
            <Subjects Name={item.Name} Description={item.Description} Nrc={item.NRC}/>
            )}
        />
      </View>
    );
};
