//Back para pantalla de Asignatura.
import react from "react";
import { useState, useEffect } from 'react';
import { View,
    StyleSheet,
    Text,
    FlatList,
} from 'react-native';
import { supabase } from "../../lib/supabase";
//Para los campos dentro de la flatlist.
import Classes from "../../components/Classes";


export default function Class_Query ({NRC}) {
    const [classInfo, setClassInfo] = useState([]);
    useEffect(() => {
      const fetchClassInfo = async () => {
        try {
          const { data, error } = await supabase
            .from('Classes')
            .select('*')
            .eq('NRC', NRC)
          if (error) {
              console.log(error);
          } else {
              setClassInfo(data);
          }
        } catch (error) {
            console.log(error);
          }
      };
      fetchClassInfo();
    }, [NRC]);
    return (
      <View>
        <FlatList
            data={classInfo}
            keyExtractor={(item) => item.id.toString()}
            renderItem={({item}) =>(
            <Classes Name={item.Name} Description={item.Description} Status={item.Status} />
            )}
        />
      </View>
    );
};
