import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
import { getDatabase, ref, get } from "firebase/database";

const firebaseConfig = {
  apiKey: "AIzaSyDorMnYEW4ngLMrXE9KSdMnparvCYAMVYE",
  authDomain: "classgenda-d2a3b.firebaseapp.com",
  databaseURL: "https://classgenda-d2a3b-default-rtdb.firebaseio.com",
  projectId: "classgenda-d2a3b",
  storageBucket: "classgenda-d2a3b.appspot.com",
  messagingSenderId: "491786331714",
  appId: "1:491786331714:web:bbf6ee046ccde7d14dafdb",
  measurementId: "G-LY7ETP3DH8"
};

const app = initializeApp(firebaseConfig);
getAnalytics(app); // Not necessary for the connection check, but initializing as per your setup
const database = getDatabase(app);

// Function to check database connection by retrieving a test value
export function checkDatabaseConnection(materia) {
  const testRef = ref(database, materia); 
  get(testRef).then((snapshot) => {
    if (snapshot.exists()) {
      console.log('Connection to Firebase is successful:', snapshot.val());
    } else {
      console.log('No test value found, but connection was successful');
    }
  }).catch((error) => {
    console.error('Failed to connect to Firebase:', error);
  });
}

