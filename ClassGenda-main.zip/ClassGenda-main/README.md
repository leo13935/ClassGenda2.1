#ClassGenda

#Creado en React Native y con ayuda de Expo, el cual ofrece ciertas herramientas con las cuales la app puede ser desarrollada mejor en JavaScript.

#Puntos importantes:

#Historial: actividades y evidencia (PDF).

#Calendario: por cada una de las clases.

#Clases: opción de integrar imagen, texto y actividades.

#Evidencia: información general de cada una de las actividades por clase.

#Administrador: lista de profesores y el desglose de los alumnos registrados por el mismo.
Profesor (progreso): se contabiliza de acuerdo al paso de las clases y el estatus de las mismas.

#Link del prototipado en Figma: https://www.figma.com/file/fvhhU7CGJ8IkJ6XRvXF5tm/Login?type=design&node-id=0%3A1&mode=design&t=o4oRF740XLeudg1O-1

#Link de la presentación sobre ClassGenda: https://docs.google.com/presentation/d/1ZLEfqBWshR50hCTkqZYSehVmxwFzRb4Lw1Sjha1_0EM/edit?usp=sharing

#Link del maquetado en Figma: https://www.figma.com/file/l7mmTpM8DBqYWVvxHaTUYP/Maquetado-ClassGenda?type=design&node-id=0%3A1&mode=design&t=jjmnYYzzlqOk9SN2-1