//Menu lateral de la aplicación.
import 'react-native-url-polyfill/auto'
// ----------------------------------------- DEPENDENCIAS ------------------------------------
import React from 'react';
import { createDrawerNavigator } from '@react-navigation/drawer';
import { useNavigation } from '@react-navigation/native';
import CustomDrawer from '../components/CustomDrawer';  //Diseño del menu lateral.
import {
  View, 
  Text,
  Image,
  Pressable,
} from 'react-native';
// ------------------------- ICONOS -----------------------------------------------------
import {
  MaterialIcons,
  FontAwesome,
  FontAwesome5,
} from "@expo/vector-icons";
// ----------------------------------------- PANTALLAS ------------------------------------
import {
  AñadirAsignatura,
  AñadirClase,
  AñadirUsuario,
  Asignatura,
  DashboardGeneral,
  UsuariosExistentes,
  EditarAsignatura,
  EditarPerfil,
  MenuConfig,
  AcercaDe,
  Declaracion,
  Condiciones,
  EditarClase,
  Malla,
  Mallas,
} from '../screens';
// --------------------- COMPONENTES ------------------------------------------------------
import {IMAGENES, ROUTES, PALETADECOLORES} from '../components';
// ------------------------- SUPABASE -----------------------------------------------------
import { supabase } from '../lib/supabase';

//---------------------------MALLAS DE LAS CARRERAS ---------------------------------------
import MallaINNI from '../screens/home/MallaINNI';
import MallaLCMA from '../screens/home/MallaLCMA';
import MallaLIFI from '../screens/home/MallaLIFI';
import MallaINBI from '../screens/home/MallaINBI';
import MallaICIV from '../screens/home/MallaICIV';
import MallaINCE from '../screens/home/MallaINCE';
import MallaTopo from '../screens/home/MallaTopo';
import MallaIGFO from '../screens/home/MallaIGFO';
import MallaIME from '../screens/home/MallaIME';
import MallaINDU from '../screens/home/MallaINDU';
import MallaMATE from '../screens/home/MallaMATE';
import MallaINRO from '../screens/home/MallaINRO';
import MallaQUI from '../screens/home/MallaQUI';
import MallaLQUI from '../screens/home/MallaLQUI';
import MallaQFB from '../screens/home/MallaQFB';
import MallaLIAB from '../screens/home/MallaLIAB';
import MallaILOT from '../screens/home/MallaILOT';
import Horario from '../screens/home/Horario';




const Drawer = createDrawerNavigator();

function DrawerNavigator() {

  //Importar navigation, dado que este permite que la app se desplace entre pantallas correctamente.
  const navigation = useNavigation();

  //Función para el cierre de sesión.
  const logout = async () => {
    try {
      const { error } = await supabase.auth.signOut();
    } catch (error) {
      console.log(error);
    }
    navigation.navigate(ROUTES.HOME); //Regresa al usuario a la pantalla de inicio de la app.
  };

  return (
    <Drawer.Navigator   //Segunda navegación de la app (esta dentro, una vez se inicia sesión).
        drawerContent={ (props) => <CustomDrawer {...props} />} //Se llama el diseño del menu.
        screenOptions={{                  
            drawerStyle: {
              backgroundColor: PALETADECOLORES.AmarilloPatito,
              width: 250, 
            },
            headerStyle: {
              backgroundColor: PALETADECOLORES.AmarilloPatito,
            },
            headerTintColor: "black",
            headerTitleAlign: "center",
            drawerActiveTintColor: "white",
            drawerActiveBackgroundColor: 'white', //Tinta del item seleccionado.
            drawerLabelStyle: {                   //Estilo de los items.
              color: "black",
              marginHorizontal: -20,
              fontFamily: 'Lilita',
              fontSize: 17,
            },
            drawerItemStyle: {
              marginHorizontal: 13,
              marginBottom: '1%',
            },
          }}>
        <Drawer.Screen                                         //----- PANTALLAS PARTE DEL DASHBOARD --------//
          //Atajo del menu a pantalla "Dashboard General".
          name= {ROUTES.PAGINA_PRINCIPAL}
          options={{
            drawerLabel: "  Dashboard",
            Title: "Dashboard",
            headerTitleStyle: {
              fontFamily: "Lilita",
              fontSize: 22,
            },
            drawerIcon: () => (
              <FontAwesome  name="archive" size={20}  color="#000000"/>
            )
          }} 
          component={DashboardGeneral}       
        />
        <Drawer.Screen                                        //Pantalla "Editar Asignatura". 
          name= {ROUTES.EDITARASIGNATURA}
          options={{
          drawerItemStyle: { display: 'none' },  //Permite que no se muestre en el drawer navigation.
          headerTitleStyle: {
            fontFamily: "Lilita",
            fontSize: 22,
          },
        }}
          component={EditarAsignatura}       
        />
        <Drawer.Screen                                         //Pantalla "Ver Asignatura".
          name= {ROUTES.ASIGNATURA}
          options={{
          drawerItemStyle: { display: 'none' },  //Permite que no se muestre en el drawer navigation.
          headerTitleStyle: {
            fontFamily: "Lilita",
            fontSize: 22,
          }
        }}
          component={Asignatura} 
        />                  
        <Drawer.Screen                                        //Pantalla redirigida de 'Asignatura'.
          name= {ROUTES.AÑADIR_CLASE}
          options={{
            drawerItemStyle: { display: 'none' },  //Permite que no se muestre en el drawer navigation.
            headerTitleStyle: {
              fontFamily: "Lilita",
              fontSize: 22,
            },
          }}
          component={AñadirClase}       
        />

        <Drawer.Screen            //Atajo del menu a pantalla "Usuarios Existentes".
          name= {ROUTES.USUARIOS}
          options={{
            drawerLabel: " Usuarios",
            Title: "Usuarios",
            Title: "Dashboard",
            headerTitleStyle: {
              fontFamily: "Lilita",
              fontSize: 22,
            },
            drawerIcon: () => (
              <MaterialIcons  name="people" size={24}  color="#000000"/>
            )
          }} 
          component={UsuariosExistentes} 
        />
        <Drawer.Screen            //Atajo del menu a la pantalla "Añadir Usuario".
          name= {ROUTES.AÑADIR_USUARIO}
          options={{
            drawerLabel: "Añadir Usuario",
            Title: "Añadir Usuario",
            Title: "Dashboard",
            headerTitleStyle: {
              fontFamily: "Lilita",
              fontSize: 22,
            },
            drawerIcon: () => (
              <FontAwesome5  name="user-plus" size={20} color="#000000"/>
            )
          }} 
          component={AñadirUsuario}       
        />
        
        <Drawer.Screen            //Atajo del menu a la pantalla "Añadir Asignatura".
          name= {ROUTES.AÑADIR_ASIGNATURA}
          options={{
            drawerLabel: "Añadir Asignatura",
            Title: "Añadir Asignatura",
            Title: "Dashboard",
            headerTitleStyle: {
              fontFamily: "Lilita",
              fontSize: 22,
            },
            drawerIcon: () => (
              <MaterialIcons  name="dashboard-customize" size={24}  color="#000000"/>
            )
          }} 
          component={AñadirAsignatura}       
        />

        <Drawer.Screen            //Atajo del menu a la pantalla "Mallas".
          name= {ROUTES.MALLAS}
          options={{
            drawerLabel: "Mallas curriculares",
            Title: "Mallas curriculares",
            Title: "Dashboard",
            headerTitleStyle: {
              fontFamily: "Lilita",
              fontSize: 22,
            },
            drawerIcon: () => (
              <FontAwesome  name="table" size={24}  color="#000000"/>
            )
          }} 
          component={Mallas}       
        />

        <Drawer.Screen            //Atajo del menu a la pantalla "Mallas".
          name= {ROUTES.HORARIO}
          options={{
            drawerLabel: "Horario",
            Title: "Horario",
            Title: "Dashboard",
            headerTitleStyle: {
              fontFamily: "Lilita",
              fontSize: 22,
            },
            drawerIcon: () => (
              <FontAwesome  name="calendar" size={24}  color="#000000"/>
            )
          }} 
          component={Horario}       
        />

        <Drawer.Screen            //Atajo del menu a la pantalla "Malla".
          name= {ROUTES.MALLA_ICOM}
          options={{
            drawerItemStyle: { display: 'none' },  //Permite que no se muestre en el drawer navigation.
            headerTitleStyle: {
              fontFamily: "Lilita",
              fontSize: 22,
            },
          }}
          
          component={Malla}       
        />

        <Drawer.Screen            //Atajo del menu a la pantalla "INNI".
          name= {ROUTES.MALLA_INNI}
          options={{
            drawerItemStyle: { display: 'none' }  //Permite que no se muestre en el drawer navigation.
          }}
          component={MallaINNI}       
        />

         <Drawer.Screen            //Atajo del menu a la pantalla "LCMA".
          name= {ROUTES.MALLA_LCMA}
          options={{
            drawerItemStyle: { display: 'none' }  //Permite que no se muestre en el drawer navigation.
          }}
          component={MallaLCMA}       
        />

        <Drawer.Screen            //Atajo del menu a la pantalla "LIFI".
          name= {ROUTES.MALLA_LIFI}
          options={{
            drawerItemStyle: { display: 'none' }  //Permite que no se muestre en el drawer navigation.
          }}
          component={MallaLIFI}       
        />

        <Drawer.Screen            //Atajo del menu a la pantalla "INBI".
          name= {ROUTES.MALLA_INBI}
          options={{
            drawerItemStyle: { display: 'none' }  //Permite que no se muestre en el drawer navigation.
          }}
          component={MallaINBI}       
        />

        <Drawer.Screen            //Atajo del menu a la pantalla "ICIV".
          name= {ROUTES.MALLA_ICIV}
          options={{
            drawerItemStyle: { display: 'none' }  //Permite que no se muestre en el drawer navigation.
          }}
          component={MallaICIV}       
        />

       
        <Drawer.Screen            //Atajo del menu a la pantalla "Malla INCE".
          name= {ROUTES.MALLA_INCE}
          options={{
            drawerItemStyle: { display: 'none' }  //Permite que no se muestre en el drawer navigation.
          }}
          component={MallaINCE}       
        />

        <Drawer.Screen            //Atajo del menu a la pantalla "Malla TOPO".
          name= {ROUTES.MALLA_TOPO}
          options={{
            drawerItemStyle: { display: 'none' }  //Permite que no se muestre en el drawer navigation.
          }}
          component={MallaTopo}       
        />

        <Drawer.Screen            //Atajo del menu a la pantalla "Malla IGFO".
          name= {ROUTES.MALLA_IGFO}
          options={{
            drawerItemStyle: { display: 'none' }  //Permite que no se muestre en el drawer navigation.
          }}
          component={MallaIGFO}       
        />
        

        <Drawer.Screen            //Atajo del menu a la pantalla "Malla INDU".
          name= {ROUTES.MALLA_INDU}
          options={{
            drawerItemStyle: { display: 'none' }  //Permite que no se muestre en el drawer navigation.
          }}
          component={MallaINDU}       
        />

        <Drawer.Screen            //Atajo del menu a la pantalla "Malla IME".
          name= {ROUTES.MALLA_IME}
          options={{
            drawerItemStyle: { display: 'none' }  //Permite que no se muestre en el drawer navigation.
          }}
          component={MallaIME}       
        />
        
        <Drawer.Screen            //Atajo del menu a la pantalla "Malla INRO".
          name= {ROUTES.MALLA_INRO}
          options={{
            drawerItemStyle: { display: 'none' }  //Permite que no se muestre en el drawer navigation.
          }}
          component={MallaINRO}       
        />
        
        <Drawer.Screen            //Atajo del menu a la pantalla "Malla MATE".
          name= {ROUTES.MALLA_MATE}
          options={{
            drawerItemStyle: { display: 'none' }  //Permite que no se muestre en el drawer navigation.
          }}
          component={MallaMATE}       
        />
        
        <Drawer.Screen            //Atajo del menu a la pantalla "Malla QUI".
          name= {ROUTES.MALLA_QUI}
          options={{
            drawerItemStyle: { display: 'none' }  //Permite que no se muestre en el drawer navigation.
          }}
          component={MallaQUI}       
        />
        
        <Drawer.Screen            //Atajo del menu a la pantalla "Malla LQUI".
          name= {ROUTES.MALLA_LQUI}
          options={{
            drawerItemStyle: { display: 'none' }  //Permite que no se muestre en el drawer navigation.
          }}
          component={MallaLQUI}       
        />
        
        <Drawer.Screen            //Atajo del menu a la pantalla "Malla QFB".
          name= {ROUTES.MALLA_QFB}
          options={{
            drawerItemStyle: { display: 'none' }  //Permite que no se muestre en el drawer navigation.
          }}
          component={MallaQFB}       
        />
      
        <Drawer.Screen            //Atajo del menu a la pantalla "Malla LIAB".
          name= {ROUTES.MALLA_LIAB}
          options={{
            drawerItemStyle: { display: 'none' }  //Permite que no se muestre en el drawer navigation.
          }}
          component={MallaLIAB}       
        />

        <Drawer.Screen            //Atajo del menu a la pantalla "Malla LIAB".
          name= {ROUTES.MALLA_ILOT}
          options={{
            drawerItemStyle: { display: 'none' }  //Permite que no se muestre en el drawer navigation.
          }}
          component={MallaILOT}       
        />






        
        <Drawer.Screen                                    //----- PANTALLAS PARTE DE CONFIGURACIÓN --------//
          //Pantalla para la configuración de la app.
          name= {ROUTES.MENU_CONFIG}
          options={{
            drawerItemStyle: { display: 'none' },  //Permite que no se muestre en el drawer navigation.
            headerTitleStyle: {
              fontFamily: "Lilita",
              fontSize: 22,
            },
          }}
          component={MenuConfig}       
        />
        <Drawer.Screen                                    //Pantalla para "Editar perfil"
          name= {ROUTES.EDITAR_PERFIL}
          options={{
            drawerItemStyle: { display: 'none' },  //Permite que no se muestre en el drawer navigation.
            headerTitleStyle: {
              fontFamily: "Lilita",
              fontSize: 22,
            },
          }}
          component={EditarPerfil}       
        />
        <Drawer.Screen                                    //Pantalla para "Editar clase"
          name= {ROUTES.EDITAR_CLASE}
          options={{
            drawerItemStyle: { display: 'none' },  //Permite que no se muestre en el drawer navigation.
            headerTitleStyle: {
              fontFamily: "Lilita",
              fontSize: 22,
            },
          }}
          component={EditarClase}       
        />
        <Drawer.Screen                                    //Pantalla para "Acerca de" ClassGenda.
          name= {ROUTES.ACERCA_DE}
          options={{
            drawerItemStyle: { display: 'none' },  //Permite que no se muestre en el drawer navigation.
            headerTitleStyle: {
              fontFamily: "Lilita",
              fontSize: 22,
            },
          }}
          component={AcercaDe}       
        />
        <Drawer.Screen                                    //Pantalla para "Condiciones de uso" ClassGenda.
          name= {ROUTES.CONDICIONES_USO}
          options={{
            drawerItemStyle: { display: 'none' },  //Permite que no se muestre en el drawer navigation.
            headerTitleStyle: {
              fontFamily: "Lilita",
              fontSize: 22,
            },
          }}
          component={Condiciones}       
        />
        <Drawer.Screen                                    //Pantalla para "Declaración de privacidad" ClassGenda.
          name= {ROUTES.DECLARACIONES_PRIVACIDAD}
          options={{
            drawerItemStyle: { display: 'none' },  //Permite que no se muestre en el drawer navigation.
            headerTitleStyle: {
              fontFamily: "Lilita",
              fontSize: 22,
            },
          }}
          component={Declaracion}       
        />
      </Drawer.Navigator>
  );
};

export default DrawerNavigator;