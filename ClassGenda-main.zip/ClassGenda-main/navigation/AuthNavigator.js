//Inicio de la aplicación con las pantallas principales
// antes de acceder.
// --------------------------------- DEPENDENCIAS -----------------------
import { createStackNavigator } from '@react-navigation/stack';
import { DashboardGeneral, ForgotPassword, HomeScreen, Login, SignUp } from '../screens';
import DrawerNavigator from './DrawerNavigator';
import React, { useState, useEffect, useCallback } from 'react';
// ----------------------------------- COMPONENTES ----------------------
import {PALETADECOLORES, ROUTES} from '../components';

const Stack = createStackNavigator();

function AuthNavigator(){
    console.log(Stack);
    return (
        <Stack.Navigator        //Principal navegación de la app.
            screenOptions={{}} 
            initialRouteName={ROUTES.HOME}          //Home screen principal después de cargar.
        >
            <Stack.Screen
                name={ROUTES.HOME}
                component={HomeScreen}
                options={{headerShown: false}}
            />
            <Stack.Screen
                name={ROUTES.LOGIN}
                component={Login}
                options={{headerShown: false}}
            />
            <Stack.Screen
                name={ROUTES.FORGOTPASSWORD}
                component={ForgotPassword}
                options={{headerShown: false}}
            />
            <Stack.Screen
                name={ROUTES.SIGNUP}
                component={SignUp}
                options={{headerShown: false}}
            />
            <Stack.Screen                       //Se añade la pantalla principal dado que se necesita para ligar el botón de login.
                name={ROUTES.PAGINA_PRINCIPAL}
                component={DashboardGeneral}
                options={{headerShown: false}}
            />
            <Stack.Screen
                name={ROUTES.DRAWER}             //También se añade dado que se encuentra la página principal en el mismo y debe cargarse de igual forma.
                component={DrawerNavigator}
                options={{headerShown: false}}
            />
        </Stack.Navigator>
    );
}

export default AuthNavigator;